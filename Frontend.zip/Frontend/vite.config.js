import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const baseUrl = (env.VITE_API_BASE_URL || 'https://movable-swampland-tinderbox.ngrok-free.dev').trim().replace(/\/+$/, '')
  const secureApiProxy = !/^https:\/\/localhost(?::|\/|$)/i.test(baseUrl)
  return {
  plugins: [tailwindcss(), react()],
  test: {
    environment: 'jsdom',
    pool: 'threads',
    maxWorkers: 2,
    setupFiles: ['./tests/browser-environment.js'],
    include: [
      'src/pages/examinations/**/*.vitest.test.{js,jsx}',
      'src/pages/fees/**/*.vitest.test.{js,jsx}',
      'src/components/**/*.vitest.test.{js,jsx}',
      'src/pages/academic-structure/**/*.vitest.test.{js,jsx}',
      'src/pages/admin-management/**/*.vitest.test.{js,jsx}',
      'src/config/**/*.vitest.test.{js,jsx}',
      'src/features/faculty/**/*.vitest.test.{js,jsx}',
      'src/pages/semester-management/**/*.vitest.test.{js,jsx}',
      'src/pages/section-management/**/*.vitest.test.{js,jsx}',
      'src/auth/**/*.vitest.test.{js,jsx}',
    ],
  },
  resolve: {
    dedupe: ['react', 'react-dom'],
  },
  optimizeDeps: {
    // Prepare the React runtime together before serving the first page.
    include: ['react', 'react-dom', 'react-dom/client', 'react/jsx-runtime', 'react/jsx-dev-runtime'],
  },
  server: {
    proxy: {
      '/postal-lookup': {
        target: 'https://www.pincodesinfo.in/api',
        changeOrigin: true,
        secure: true,
        rewrite: path => path.replace(/^\/postal-lookup/, ''),
      },
      '/api/v1/access-requests': {
        target: baseUrl,
        changeOrigin: true,
        secure: secureApiProxy,
        headers: {
          'ngrok-skip-browser-warning': 'true',
        },
      },
      '/api/college-settings': {
        target: baseUrl,
        changeOrigin: true,
        secure: secureApiProxy,
        headers: {
          'ngrok-skip-browser-warning': 'true',
        },
      },
      '/api/v1/academic-years': {
        target: baseUrl,
        changeOrigin: true,
        secure: secureApiProxy,
        headers: {
          'ngrok-skip-browser-warning': 'true',
        },
      },
      '/api': {
        target: baseUrl,
        changeOrigin: true,
        secure: secureApiProxy,
        headers: {
          'ngrok-skip-browser-warning': 'true',
        },
      },
      '/uploads': {
        target: baseUrl,
        changeOrigin: true,
        secure: secureApiProxy,
        headers: {
          'ngrok-skip-browser-warning': 'true',
        },
      },
      '/images': {
        target: baseUrl,
        changeOrigin: true,
        secure: secureApiProxy,
        headers: { 'ngrok-skip-browser-warning': 'true' },
      },
    },
  },
  }
})
