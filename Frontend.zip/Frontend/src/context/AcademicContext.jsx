import { requestEffectiveAccess } from '../auth/accessRequests.js'
import { canSelectCollege } from '../auth/collegeAuthorization.js'
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react'
import academicService, { filterActiveOnly } from '../services/academicService'
import eventBus, { ERP_EVENTS } from '../services/eventBus'
import { getActiveAcademicYears } from '../utils/academicYearUtils'
import { createCollegeScope, selectedCollegeId as storedCollegeId } from '../utils/collegeScope'
import { getAccessToken, getUserCollegeId, getUserRole } from '../auth/auth'

const CONTEXT_STORAGE_KEY = 'pirnav_academic_context'

const AcademicContext = createContext(null)

const readStoredContext = () => {
  try {
    const assignedCollege = getUserRole() === 'admin' ? '' : getUserCollegeId()
    const raw = localStorage.getItem(CONTEXT_STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw)
      if (parsed && typeof parsed === 'object') {
        return {
          collegeId: assignedCollege || (parsed.collegeId ? String(parsed.collegeId) : ''),
          academicYearId: assignedCollege && String(parsed.collegeId) !== assignedCollege ? '' : (parsed.academicYearId ? String(parsed.academicYearId) : ''),
        }
      }
    }
    // Fallback to legacy single-key storage if available
    const legacyYear = localStorage.getItem('pirnav-selected-academic-year-id')
    const legacyCollege = localStorage.getItem('selected_college_id') || localStorage.getItem('pirnav-selected-college-id')
    return {
      collegeId: assignedCollege || (legacyCollege ? String(legacyCollege) : ''),
      academicYearId: legacyYear ? String(legacyYear) : '',
    }
  } catch {
    return { collegeId: '', academicYearId: '' }
  }
}

const saveStoredContext = (collegeId, academicYearId) => {
  try {
    const payload = {
      collegeId: collegeId ? String(collegeId) : '',
      academicYearId: academicYearId ? String(academicYearId) : '',
    }
    localStorage.setItem(CONTEXT_STORAGE_KEY, JSON.stringify(payload))
    if (collegeId) localStorage.setItem('pirnav-selected-college-id', String(collegeId))
    else {
      localStorage.removeItem('pirnav-selected-college-id')
      localStorage.removeItem('selected_college_id')
    }
    if (academicYearId) localStorage.setItem('pirnav-selected-academic-year-id', String(academicYearId))
    else localStorage.removeItem('pirnav-selected-academic-year-id')
  } catch {}
}

export const AcademicProvider = ({ children }) => {
  const [colleges, setColleges] = useState([])
  const [academicYears, setAcademicYears] = useState([])
  const [departments, setDepartments] = useState([])
  const [courses, setCourses] = useState([])
  const [branches, setBranches] = useState([])
  const [semesters, setSemesters] = useState([])
  const [sections, setSections] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const hierarchyRequest = useRef(0)
  const contextChangeRequest = useRef(0)
  const [collegeAuthorization, setCollegeAuthorization] = useState(null)
  const [collegeAccessSnapshot, setCollegeAccessSnapshot] = useState(null)

  // Stored working context IDs
  const [selectedCollegeId, setSelectedCollegeId] = useState(() => readStoredContext().collegeId)
  const [selectedAcademicYearId, setSelectedAcademicYearId] = useState(() => readStoredContext().academicYearId)

  const loadHierarchy = useCallback(async () => {
    let requestedCollegeId = storedCollegeId()
    const requestId = ++hierarchyRequest.current
    const requestToken = getAccessToken()
    try {
      setLoading(true)
      setError(null)
      setCollegeAccessSnapshot(null)
      setAcademicYears([]); setDepartments([]); setCourses([]); setBranches([]); setSemesters([]); setSections([])
      if (!requestToken) throw new Error('Sign in to load college access.')
      const authorization = await requestEffectiveAccess()
      if (requestId !== hierarchyRequest.current || getAccessToken() !== requestToken) return
      setCollegeAuthorization(authorization)
      // Resolve the college before requesting any college-scoped resources.
      const cols = await academicService.getColleges(false)
      if (requestId !== hierarchyRequest.current || storedCollegeId() !== requestedCollegeId || getAccessToken() !== requestToken) return
      if (cols?.loadError) throw new Error('College details could not be loaded. Please retry.')
      const isAdmin = getUserRole() === 'admin'
      const assignedCollege = isAdmin ? '' : getUserCollegeId()
      const safeColleges = (cols || []).filter(row => canSelectCollege(authorization, row.id ?? row.collegeId, getUserCollegeId()) && (!assignedCollege || String(row.id ?? row.collegeId) === assignedCollege))
      setColleges(safeColleges)
      const available = filterActiveOnly(safeColleges)
      if (!available.length) {
        setSelectedCollegeId('')
        setSelectedAcademicYearId('')
        setError(!(cols || []).length
          ? 'The server returned no colleges for your account. Ask your administrator to check the college records.'
          : !safeColleges.length
            ? 'Your account is not assigned to any of the returned colleges. Ask your administrator to check your college access.'
            : 'No active colleges are available for your account.')
        return
      }
      const college = available.find(row => String(row.id ?? row.collegeId) === requestedCollegeId)
        || available.find(row => String(row.id ?? row.collegeId) === String(getUserCollegeId()))
        || available[0]
      const initialCollegeId = college ? String(college.id ?? college.collegeId) : ''
      if (initialCollegeId !== requestedCollegeId) {
        saveStoredContext(initialCollegeId, '')
        requestedCollegeId = initialCollegeId
        setAcademicYears([])
        setSelectedAcademicYearId('')
      }
      setSelectedCollegeId(initialCollegeId)
      const scopedAccess = initialCollegeId && String(authorization.collegeId ?? '') !== initialCollegeId ? await requestEffectiveAccess(initialCollegeId) : authorization
      if (requestId !== hierarchyRequest.current || storedCollegeId() !== requestedCollegeId || getAccessToken() !== requestToken) return
      setCollegeAccessSnapshot({ token: requestToken, collegeId: initialCollegeId, value: scopedAccess })
      const results = await Promise.allSettled([
        academicService.getAcademicYears(false),
        academicService.getDepartments(false),
        academicService.getCourses({}, false),
        academicService.getBranches(null, false),
        academicService.getSemesters(null, false),
        academicService.getSections({}, false),
      ])
      const [years, depts, crss, brns, sems, secs] = results.map(result =>
        result.status === 'fulfilled' ? result.value : Object.assign([], { loadError: true }))
      if (requestId !== hierarchyRequest.current || getAccessToken() !== requestToken) return

      if (storedCollegeId() !== requestedCollegeId) return

      const failed = ['Academic years', 'Departments', 'Courses', 'Branches', 'Semesters', 'Sections']
        .filter((_, index) => results[index].status === 'rejected' || results[index].value?.loadError)
      if (failed.length) setError(`${failed.join(', ')} could not be loaded. Please retry.`)

      setColleges(safeColleges)
      setDepartments(depts || [])
      setCourses(crss || [])
      setBranches(brns || [])
      setSemesters(sems || [])
      setSections(secs || [])

      // Validate or resolve default College
      const stored = readStoredContext()
      const availableColleges = filterActiveOnly(safeColleges)
      let resolvedColId = ''
      if (stored.collegeId && availableColleges.some(c => String(c.id ?? c.collegeId) === String(stored.collegeId))) {
        resolvedColId = String(stored.collegeId)
      } else {
        const preferredCollege = availableColleges.find(c => String(c.id ?? c.collegeId) === String(getUserCollegeId()))
        const defaultCol = preferredCollege || availableColleges[0]
        resolvedColId = defaultCol ? String(defaultCol.id ?? defaultCol.collegeId) : ''
      }
      setSelectedCollegeId(resolvedColId)
      // The academic-years endpoint may omit CollegeId from its DTO. Filtering
      // by inferred ownership drops every year in that response, leaving the
      // header selector at “Not Configured”. The API is already scoped by the
      // selected college context, so preserve its rows here.
      const yearRows = Array.isArray(years) ? years : []
      const hasOwnership = yearRows.some(row => row.collegeId != null || row.CollegeId != null || row.college_id != null)
      const safeYears = hasOwnership ? createCollegeScope(resolvedColId)(yearRows) : yearRows
      setAcademicYears(safeYears)

      // Validate or resolve default Academic Year
      let resolvedYearId = ''
      if (stored.academicYearId && safeYears.some(y => String(y.id ?? y.academicYearId) === String(stored.academicYearId))) {
        resolvedYearId = String(stored.academicYearId)
      } else {
        const defaultYear = safeYears.find(y => y.isCurrent || String(y.status).toLowerCase() === 'active' || y.isActive) || safeYears[0]
        resolvedYearId = defaultYear ? String(defaultYear.id ?? defaultYear.academicYearId) : ''
      }
      setSelectedAcademicYearId(resolvedYearId)

      // Persist validated context
      saveStoredContext(resolvedColId, resolvedYearId)
    } catch (err) {
      if (getAccessToken() !== requestToken) return
      if (storedCollegeId() !== requestedCollegeId) return
      if (requestId !== hierarchyRequest.current) return
      setError('Academic configuration could not be loaded. Please retry.')
      console.warn('Error loading academic hierarchy context:', err)
    } finally {
      if (requestId === hierarchyRequest.current) setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadHierarchy()
    const unsubscribe = eventBus.subscribe(ERP_EVENTS.ACADEMIC_UPDATED, () => {
      academicService.clearCache()
      loadHierarchy()
    })
    const syncStorage = event => {
      if (event.key && !['pirnav_academic_context', 'pirnav-selected-college-id', 'selected_college_id', 'pirnav-selected-academic-year-id'].includes(event.key)) return
      const stored = readStoredContext()
      setSelectedCollegeId(stored.collegeId); setSelectedAcademicYearId(stored.academicYearId)
      academicService.clearCache()
      loadHierarchy()
    }
    window.addEventListener('storage', syncStorage)
    return () => { hierarchyRequest.current++; contextChangeRequest.current++; unsubscribe(); window.removeEventListener('storage', syncStorage) }
  }, [loadHierarchy])

  const scopeRecords = useMemo(() => {
    const hierarchy = { departments, courses, branches, semesters, sections }
    const filter = createCollegeScope(selectedCollegeId, hierarchy)
    return (rows, related) => related
      ? createCollegeScope(selectedCollegeId, { ...hierarchy, ...related })(rows)
      : filter(rows)
  }, [selectedCollegeId, departments, courses, branches, semesters, sections])

  // Active items helpers
  const activeColleges = filterActiveOnly(colleges)
  const activeAcademicYears = getActiveAcademicYears(academicYears)
  const activeDepartments = filterActiveOnly(scopeRecords(departments))
  const activeCourses = filterActiveOnly(scopeRecords(courses))
  const activeBranches = filterActiveOnly(scopeRecords(branches))
  const activeSemesters = filterActiveOnly(scopeRecords(semesters))
  const activeSections = filterActiveOnly(scopeRecords(sections))

  const currentAcademicYear = useMemo(() => {
    return academicYears.find(y => y.isCurrent) || activeAcademicYears[0] || academicYears[0] || null
  }, [academicYears, activeAcademicYears])

  const selectedCollege = useMemo(() => {
    const availableColleges = filterActiveOnly(colleges)
    return availableColleges.find(c => String(c.id ?? c.collegeId) === String(selectedCollegeId)) || null
  }, [colleges, selectedCollegeId])

  const selectedAcademicYear = useMemo(() => {
    return academicYears.find(y => String(y.id ?? y.academicYearId) === String(selectedAcademicYearId)) || null
  }, [academicYears, selectedAcademicYearId])

  const isHistoricalYear = Boolean(
    currentAcademicYear &&
    selectedAcademicYear &&
    String(selectedAcademicYear.id ?? selectedAcademicYear.academicYearId) !== String(currentAcademicYear.id ?? currentAcademicYear.academicYearId) &&
    (selectedAcademicYear.name || '').replace(/\s+/g, '') !== (currentAcademicYear.name || '').replace(/\s+/g, '')
  )

  const isContextReady = Boolean(selectedCollege && selectedAcademicYear)

  // Atomically apply a new Global Academic Context
  const applyAcademicContext = useCallback(async (newCollegeId, newAcademicYearId) => {
    const isAdmin = getUserRole() === 'admin'
    const assignedCollege = isAdmin ? '' : getUserCollegeId()
    if (assignedCollege && String(newCollegeId) !== assignedCollege) throw new Error('Select the college assigned to your account.')
    const colId = String(newCollegeId ?? '')
    if (!collegeAuthorization || !canSelectCollege(collegeAuthorization, colId, getUserCollegeId()) || !filterActiveOnly(colleges).some(row => String(row.id ?? row.collegeId) === colId)) throw new Error('An active authorized college assignment is required.')
    const changeId = ++contextChangeRequest.current
    const changeToken = getAccessToken()
    const verifiedAccess = await requestEffectiveAccess(colId)
    if (changeId !== contextChangeRequest.current || changeToken !== getAccessToken()) return { success: false, cancelled: true }
    const collegeChanged = colId !== String(readStoredContext().collegeId || '')
    const yrId = collegeChanged ? '' : String(newAcademicYearId ?? '')
    if (yrId && !academicYears.some(row => String(row.id ?? row.academicYearId) === yrId)) throw new Error('Select an academic year belonging to the current college.')

    hierarchyRequest.current++
    setLoading(true)
    setCollegeAccessSnapshot({ token: getAccessToken(), collegeId: colId, value: verifiedAccess })
    setSelectedCollegeId(colId)
    if (collegeChanged) { setAcademicYears([]); setDepartments([]); setCourses([]); setBranches([]); setSemesters([]); setSections([]) }
    setSelectedAcademicYearId(yrId)
    saveStoredContext(colId, yrId)

    const targetCol = colleges.find(c => String(c.id ?? c.collegeId) === colId) || null
    const targetYr = academicYears.find(y => String(y.id ?? y.academicYearId) === yrId) || null

    // Clear stale memory caches if needed
    academicService.clearCache?.()

    // Broadcast change
    eventBus.emit(ERP_EVENTS.ACADEMIC_UPDATED, {
      collegeId: colId,
      college: targetCol,
      academicYearId: yrId,
      academicYear: targetYr,
    })
    eventBus.emit(ERP_EVENTS.ACADEMIC_YEAR_CHANGED, {
      academicYearId: yrId,
      academicYear: targetYr,
    })

    return {
      success: true,
      college: targetCol,
      academicYear: targetYr,
    }
  }, [colleges, academicYears, collegeAuthorization])

  // Context-scoped Cascading helpers
  const getCoursesForDepartment = useCallback((departmentId, activeOnly = true) => {
    const list = activeOnly ? activeCourses : scopeRecords(courses)
    if (!departmentId) return list
    return list.filter(c => String(c.departmentId) === String(departmentId))
  }, [scopeRecords, courses, activeCourses])

  const getBranchesForCourse = useCallback((courseId, activeOnly = true) => {
    const list = activeOnly ? activeBranches : scopeRecords(branches)
    if (!courseId) return list
    return list.filter(b => String(b.courseId) === String(courseId))
  }, [scopeRecords, branches, activeBranches])

  const getSemestersForCourse = useCallback((courseId, activeOnly = true) => {
    const list = activeOnly ? activeSemesters : scopeRecords(semesters)
    const filtered = !courseId ? list : list.filter(s => !s.courseId || String(s.courseId) === String(courseId))
    const map = new Map()
    filtered.forEach(s => {
      const num = Number(s.semesterNumber ?? String(s.semesterName || s.name || s.id).match(/\d+/)?.[0] ?? s.id)
      const name = s.semesterName || s.name || (num ? `Semester ${num}` : `Semester ${s.id}`)
      const key = num || name
      if (!map.has(key)) {
        map.set(key, {
          ...s,
          id: s.id ?? key,
          semesterNumber: num || s.semesterNumber || key,
          semesterName: name,
        })
      }
    })
    return Array.from(map.values()).sort((a, b) => (Number(a.semesterNumber) || 0) - (Number(b.semesterNumber) || 0))
  }, [scopeRecords, semesters, activeSemesters])

  const getSectionsForScope = useCallback((scope = {}, activeOnly = true) => {
    const list = activeOnly ? activeSections : scopeRecords(sections)
    return list.filter(sec => {
      const secYearId = String(sec.academicYearId ?? sec.academicYear ?? '')
      const targetYearId = String(scope.academicYearId || selectedAcademicYearId || '')
      if (targetYearId && secYearId && secYearId !== targetYearId) return false
      if (scope.departmentId && String(sec.departmentId) !== String(scope.departmentId)) return false
      if (scope.courseId && String(sec.courseId) !== String(scope.courseId)) return false
      if (scope.branchId && String(sec.branchId) !== String(scope.branchId)) return false
      if (scope.semesterId && String(sec.semesterId) !== String(scope.semesterId)) return false
      return true
    })
  }, [scopeRecords, sections, activeSections, selectedAcademicYearId])

  const resolveNames = useCallback((ids) => {
    return academicService.resolveHierarchyNames(ids)
  }, [])

  const value = {
    scopeRecords,
    collegeAccess: collegeAccessSnapshot?.token === getAccessToken() && collegeAccessSnapshot?.collegeId === selectedCollegeId ? collegeAccessSnapshot.value : null,
    loading,
    error,
    isContextReady,
    // Colleges
    colleges,
    activeColleges,
    selectedCollegeId,
    selectedCollege,
    college: selectedCollege,
    collegeId: selectedCollegeId,
    // Academic Years
    academicYears,
    activeAcademicYears,
    currentAcademicYear,
    selectedAcademicYear,
    selectedAcademicYearId,
    academicYear: selectedAcademicYear,
    academicYearId: selectedAcademicYearId,
    isHistoricalYear,
    // Actions
    applyAcademicContext,
    setContext: applyAcademicContext,
    setAcademicContext: applyAcademicContext,
    selectAcademicYear: (yearOrId) => {
      const yrId = typeof yearOrId === 'object' ? String(yearOrId?.id ?? yearOrId?.academicYearId ?? '') : String(yearOrId)
      applyAcademicContext(selectedCollegeId, yrId)
    },
    resetToActiveAcademicYear: () => {
      if (currentAcademicYear) {
        const yrId = String(currentAcademicYear.id ?? currentAcademicYear.academicYearId ?? '')
        applyAcademicContext(selectedCollegeId, yrId)
      }
    },
    // Hierarchy Entities
    departments: scopeRecords(departments),
    activeDepartments,
    courses: scopeRecords(courses),
    activeCourses,
    branches: scopeRecords(branches),
    activeBranches,
    semesters: scopeRecords(semesters),
    activeSemesters,
    sections: scopeRecords(sections),
    activeSections,
    // Helpers
    getCoursesForDepartment,
    getBranchesForCourse,
    getSemestersForCourse,
    getSectionsForScope,
    resolveNames,
    refreshHierarchy: loadHierarchy,
  }

  return (
    <AcademicContext.Provider value={value}>
      {children}
    </AcademicContext.Provider>
  )
}

export const useAcademic = () => {
  const context = useContext(AcademicContext)
  if (!context) {
    throw new Error('useAcademic must be used within an AcademicProvider')
  }
  return context
}

export const useAcademicContext = useAcademic

export default AcademicContext
