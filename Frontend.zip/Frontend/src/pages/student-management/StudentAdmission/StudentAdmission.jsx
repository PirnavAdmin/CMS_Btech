import FilterPanel from '../../../components/FilterPanel'
import StudentDocumentActions from '../../../components/StudentDocumentActions'
import { studentIntegrationFees } from '../../../utils/studentIntegrationFees'
import PageHeader from '../../../components/PageHeader'
import ViewDialog from '../../../components/ViewDialog'
import { useScreenAccess } from '../../../auth/ScreenAccess'
import { uploadAdmissionDocuments, admissionDecisionAllowed } from '../../../utils/admissionDocumentWorkflow'
import { ADMISSION_QUOTAS } from '../../../utils/admissionQuotaOptions'
import { ProjectSelect } from '../../../components/SearchableSelect'
import { Link } from 'react-router-dom'

import useCollegeState from '../../../hooks/useCollegeState'
import { admissionPreview } from '../../../utils/admissionPreview'
import { newestFirst, rememberCreated } from '../../../utils/newestFirst'
import { admissionDetailSections } from '../../../utils/recordDetailSections'
import useToastState from '../../../hooks/useToastState'
import { isApiResult } from '../../../utils/exportProvenance'
import ExportMenu, { PrintDetailsButton } from '../../../components/ExportMenu'
import { admissionColumns } from '../../../utils/exportColumns'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { FiAlertCircle, FiArrowLeft, FiArrowRight, FiBookOpen, FiCamera, FiCheck, FiCheckCircle, FiChevronRight, FiClock, FiCreditCard, FiEdit2, FiEye, FiFileText, FiFilter, FiGrid, FiHome, FiInbox, FiPhone, FiPlus, FiSave, FiSearch, FiShield, FiTrash2, FiUploadCloud, FiUser, FiUsers, FiX } from 'react-icons/fi'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import DashboardLayout from '../../../layouts/DashboardLayout'
import TablePagination, { PAGE_SIZE } from '../../../components/TablePagination'
import CompactSummary from '../../../components/CompactSummary'
import StatusBadge from '../../../components/StatusBadge'
import { academicYearApi, admissionFeePlanApi, branchApi, courseApi, lookupIndianPincode, studentAdmissionApi, studentAcademicDetailsApi, studentAdmissionStatusApi, studentDocumentApi, studentFeeApi, studentParentApi, studentPreviousEducationApi } from '../../../api/apiEndpoints'
import { getOperationalAcademicYearOptions } from '../../../utils/academicYearUtils'
import { admissionSemesterOptions, admissionSemesterError, resetAdmissionAcademicDependents } from '../../../utils/admissionAcademicMapping'
import { getColleges, getSemesters } from '../../../auth/collegeApi'
import eventBus, { ERP_EVENTS } from '../../../services/eventBus'
import {
  apiAssetUrl,
  blankAddress,
  createEmptyCanonicalStudent,
  dateInputValue,
  DOCUMENTS_CONFIG,
  formatAddress,
  formatDateTime,
  formatDisplay,
  formatMoney,
  HOSTEL_FEES_DEFAULT,
  normalizeAddressObj,
  normalizeAdmissionStatus,
  normalizeCanonicalStudent,
  readAdmissionPhoto,
  REQUIRED_FIELDS,
  saveAdmissionPhoto,
  studentFullName,
  studentInitials,
  studentQuotaDisplay,
  tenDigitMobile,
} from '../../../utils/studentCanonicalModel'
import { useAcademic } from '../../../context/AcademicContext'
import { readFeeWorkspace, readStructures, readHostelStructures, readTransportStructures, matchingAdmissionFeeStructures, feeTotal, feeMoney } from '../../../services/feeStructureService'
import './StudentAdmission.css'


const STEPS = ['Personal Details', 'Academic Details', 'Parent Details', 'Documents', 'Fee Information', 'Review']
const LEGACY_STEP_TO_MAIN = [0, 1, 2, 0, 1, 1, 4, 3]
const STEP_ICONS = [FiUser, FiPhone, FiUsers, FiBookOpen, FiFileText, FiHome, FiInbox, FiUploadCloud]
const STATUS = { DRAFT: 'Draft', PENDING: 'Pending', SUBMITTED: 'Submitted', APPLICATION_SUBMITTED: 'Submitted', UNDER_REVIEW: 'Under Review', VERIFIED: 'Verified', APPROVED: 'Approved', CORRECTION_REQUIRED: 'Correction Required', REJECTED: 'Rejected' }
const normalizeStatus = raw => normalizeAdmissionStatus(raw)
const formatFeeStatus = value => String(value || 'Pending').trim().toLowerCase().replace(/[_-]+/g, ' ').replace(/\b\w/g, character => character.toUpperCase())
const formatPaymentPreference = value => {
  if (!value) return 'Full Payment'
  const val = String(value).trim().toUpperCase()
  if (val === 'ONE_TIME' || val === 'FULL_PAYMENT' || val === 'ANNUAL') return 'Full Payment'
  if (val === 'TERM_WISE' || val === 'INSTALLMENT' || val === 'SEMESTER_WISE' || val === 'TERM-WISE PAYMENT') return 'Term-wise Payment'
  return String(value).replace(/[_-]+/g, ' ').toLowerCase().replace(/\b\w/g, character => character.toUpperCase())
}
// Activation is owned by the backend. Only surface an email confirmation when
// the approval response explicitly supplies one; never infer delivery.
const approvalNotice = result => {
  const data = result && typeof result === 'object' ? result : {}
  const emailSent = [data.activationEmailSent, data.emailSent, data.activation?.emailSent, data.accountActivation?.emailSent].some(value => value === true)
  return emailSent
    ? 'Admission approved successfully. An account activation email has been sent to the student’s registered email address.'
    : 'Admission approved successfully. Account activation email delivery was not confirmed by the backend.'
}
const FILTERS = [
  ['status', 'Admission Status'], ['course', 'Course'],
  ['branch', 'Branch'], ['admissionType', 'Admission Type'], ['feeStatus', 'Fee Status'],
]
const DETAIL_TABS = [
  ['overview', 'Overview', FiGrid], ['personal', 'Personal & Contact', FiUser],
  ['academic', 'Academic', FiBookOpen], ['education', 'Previous Education', FiFileText],
  ['services', 'Admission & Services', FiHome], ['fees', 'Fees', FiInbox], ['documents', 'Documents', FiFileText], ['activity', 'Activity', FiClock],
]
const DETAIL_TABS_APPROVAL = [
  ...DETAIL_TABS,
  ['decision', 'Decision', FiCheckCircle],
]
const DOCUMENTS = DOCUMENTS_CONFIG
const ADMISSION_TYPES = ['Regular / Counselling','Management','Spot Admission','Lateral Entry','Transfer','Direct Admission','Re-Admission','International Admission']

const HOSTEL_FEES = HOSTEL_FEES_DEFAULT
const TRANSPORT_FEES = { 'Route 1': 18000, 'Route 2': 22000, 'Route 3': 26000, 'Route 4': 30000 }
const normalizeHostelRoomType = value => {
  const label = String(value ?? '').trim().replace(/\s+/g, ' ')
  const key = label.toLowerCase()
  if (key === 'single sharing' || key === 'single') return 'Single Sharing'
  if (key === 'double sharing' || key === 'double') return 'Double Sharing'
  if (key === 'triple sharing' || key === 'triple') return 'Triple Sharing'
  if (key === 'four sharing' || key === 'quadruple sharing' || key === 'four') return 'Four Sharing'
  if (key === 'single room') return 'Single Room'
  if (key === 'double room') return 'Double Room'
  if (key === 'triple room') return 'Triple Room'
  return label
}

const empty = () => { const data = createEmptyCanonicalStudent(); return { ...data, fees: { ...studentIntegrationFees(), paymentPlan:'Full Payment' } } }

const merge = row => {
  const base = empty()
  return normalizeCanonicalStudent({ ...base, ...row })
}

const admissionFromApi = row => {
  if (!row) return empty()
  const normalized = normalizeCanonicalStudent(row)
  return { ...normalized, fees: { ...normalized.fees, ...studentIntegrationFees(row.feeSummary, row.feeStructure) } }
}

const documentsFromApi = rows => {
  const mapped = { ...Object.fromEntries(DOCUMENTS.map(([key]) => [key, null])), otherCertificates: [] }
  for (const row of Array.isArray(rows) ? rows : []) {
    const type = String(row.documentType ?? row.type ?? '').replace(/[^a-z0-9]/gi, '').toLowerCase()
    const key = DOCUMENTS.find(([candidate, label]) => [candidate, label].some(value => String(value).replace(/[^a-z0-9]/gi, '').toLowerCase() === type))?.[0]
    const document = { ...row, id: row.documentId ?? row.id, name: row.fileName ?? row.name ?? row.originalFileName, data: apiAssetUrl(row.data ?? row.fileUrl ?? row.documentUrl ?? row.downloadUrl ?? row.url), uploadedAt: row.uploadedAt ?? row.createdAt, uploaded: true }
    if (key) mapped[key] = document
    else mapped.otherCertificates.push(document)
  }
  return mapped
}
const mergeDocumentStatuses = (savedDocuments, uploadedDocuments) => {
  const uploaded = uploadedDocuments || {}
  const merged = { ...(savedDocuments || {}) }
  DOCUMENTS.forEach(([key]) => {
    if (uploaded[key]) merged[key] = uploaded[key]
  })
  if (Array.isArray(uploaded.otherCertificates) && uploaded.otherCertificates.length) merged.otherCertificates = uploaded.otherCertificates
  return merged
}
const documentStatus = document => {
  const savedStatus = typeof document === 'object' ? document?.status : document
  if (text(savedStatus)) return String(savedStatus)
  return document?.uploaded || document?.file || document?.data || document?.id ? 'Submitted' : 'Not Submitted'
}
const idsFromApi = (row = {}, fallbackAdmissionId = null) => ({
  admissionId: row.admissionId ?? row.studentAdmissionId ?? row.admission?.admissionId ?? row.id ?? fallbackAdmissionId,
  studentId: row.studentId ?? row.student?.studentId ?? row.student?.id ?? row.studentDetails?.studentId ?? row.personalInformation?.studentId ?? null,
  academicId: row.academicId ?? row.academicInformationId ?? row.academicInformation?.academicId ?? row.academicDetails?.academicId ?? null,
})
const read = (object, path) => path.split('.').reduce((value, key) => value?.[key], object)
const setPath = (object, path, value) => { const clone = structuredClone(object); const keys = path.split('.'); let cursor = clone; keys.slice(0, -1).forEach(key => { if (!cursor[key]) cursor[key] = {}; cursor = cursor[key] }); cursor[keys.at(-1)] = value; return clone }
const text = value => String(value ?? '').trim()
const same = (left,right) => String(left ?? '') === String(right ?? '')
const studentName = student => studentFullName(student)
const display = value => formatDisplay(value)
const money = value => formatMoney(value)
const dateTime = value => formatDateTime(value)
const quota = student => studentQuotaDisplay(student)
const matchingFeeStructures = (academic = {}, admission = {}, serverPlans = []) => {
  const collegeId = admission.collegeId || academic.collegeId;
  const candidates = Array.isArray(serverPlans) ? serverPlans : [];

  // Admission uses the same exact scope matcher as fee-plan assignment. The
  // admission wizard stores display names alongside IDs, so pass both forms.
  const scopedAcademic = {
    ...academic,
    academicYear: academic.academicYear || academic.academicYearName,
    course: academic.courseId || academic.course,
    branch: academic.branchId || academic.branch,
    semester: academic.semesterId || academic.semester,
    quota: academic.quota || academic.studentCategory,
  };
  const uniquePlans = [...new Map(candidates.filter(plan => plan?.id != null).map(plan => [String(plan.id), plan])).values()];
  const scope = { ...admission, collegeId }
  const exactMatches = matchingAdmissionFeeStructures(uniquePlans, scopedAcademic, scope)
  return exactMatches
};
const findMatchingFeeStructure = (academic, admission, selectedId) => {
  const plans = matchingFeeStructures(academic, admission);
  return plans.find(plan => String(plan.id) === String(selectedId)) || plans[0] || null;
};

const getResolvedHostelFee = (_admission = {}, fees = {}) => Number(fees.hostelFee ?? 0)
const getResolvedTransportFee = (_admission = {}, fees = {}) => Number(fees.transportFee ?? fees.transportationFee ?? 0)
const normalizeFeeSummary = response => {
  if (!response || typeof response !== 'object') return {}
  const nested = response.feeSummary ?? response.summary ?? response.feeDetails ?? response.feeStructure ?? {}
  const summary = { ...(typeof nested === 'object' ? nested : {}), ...response }
  const componentSource = summary.components ?? summary.feeComponents ?? summary.feeHeads ?? summary.feeHeadDetails ?? summary.feeStructureDetails ?? summary.feeBreakdown ?? summary.breakdown ?? summary.feeItems ?? summary.items ?? summary.fees ?? []
  const components = (Array.isArray(componentSource) ? componentSource : []).map(item => ({ ...item, name: item.name ?? item.feeHeadName ?? item.feeName ?? item.componentName ?? item.description, amount: Number(item.amount ?? item.feeAmount ?? item.amountPayable ?? item.totalAmount ?? item.value ?? item.fee ?? 0) }))
  const componentAmount = pattern => components.filter(item => pattern.test(String(item.name || ''))).reduce((total,item) => total + Number(item.amount || 0),0)
  const componentsTotal = components.reduce((total,item) => total + Number(item.amount || 0),0)
  const tuition = Number(summary.tuitionFee ?? summary.tuitionAmount ?? summary.academicFee) > 0 ? Number(summary.tuitionFee ?? summary.tuitionAmount ?? summary.academicFee) : (componentAmount(/tuition|academic/i) || componentsTotal)
  const admission = Number(summary.admissionFee ?? summary.admissionAmount ?? summary.registrationFee ?? summary.oneTimeFee) > 0 ? Number(summary.admissionFee ?? summary.admissionAmount ?? summary.registrationFee ?? summary.oneTimeFee) : componentAmount(/admission|registration/i)
  const hostel = Number((summary.hostelFee ?? summary.hostelAmount) || 0)
  const transport = Number((summary.transportFee ?? summary.transportationFee ?? summary.transportAmount) || 0)
  const scholarship = Number((summary.scholarshipAmount ?? summary.discountAmount ?? summary.concessionAmount) || 0)
  const computedTotal = Math.max(0, tuition + admission + hostel + transport - scholarship)
  const total = (tuition > 0 || componentsTotal > 0) && computedTotal > 0
    ? computedTotal
    : Number(summary.firstYearTotal ?? summary.totalFee ?? summary.totalAmount ?? summary.grandTotal ?? summary.netPayable ?? summary.totalPayable ?? summary.netAmount ?? summary.payableAmount) > 0
      ? Number(summary.firstYearTotal ?? summary.totalFee ?? summary.totalAmount ?? summary.grandTotal ?? summary.netPayable ?? summary.totalPayable ?? summary.netAmount ?? summary.payableAmount)
      : computedTotal
  const hasConfig = components.length > 0 || tuition > 0 || total > 0;
  return {
    ...summary,
    feeStructureId: summary.feeStructureId ?? summary.structureId ?? summary.feeStructure?.feeStructureId ?? summary.feeStructure?.id ?? '',
    structureId: summary.structureId ?? summary.feeStructureId ?? summary.feeStructure?.id ?? '',
    structureName: summary.structureName ?? summary.name ?? summary.feePlanName ?? '',
    planName: summary.planName ?? summary.structureName ?? summary.name ?? '',
    configured: hasConfig,
    components: Array.isArray(components) ? components : [],
    tuitionFee: tuition,
    admissionFee: admission,
    hostelFee: hostel,
    transportFee: transport,
    scholarshipAmount: scholarship,
    totalFee: total,
    paymentStatus: summary.paymentStatus || 'Pending',
    paymentPlan: summary.paymentPlan || 'Full Payment',
  }
}
const hasFeeSummary = response => {
  const summary = normalizeFeeSummary(response)
  const componentAmount = summary.components.reduce((total, item) => total + Number(item.amount ?? item.feeAmount ?? item.value ?? 0), 0)
  const summaryAmount = [summary.tuitionFee, summary.admissionFee, summary.totalFee].reduce((total, value) => total + Number(value || 0), 0)
  return componentAmount > 0 || summaryAmount > 0
}
const mergeFeeResponses = (summaryResponse, structureResponse) => {
  const summary = normalizeFeeSummary(summaryResponse)
  const structure = normalizeFeeSummary(structureResponse)
  const amount=(summaryValue,structureValue)=>Number(summaryValue)>0?summaryValue:structureValue
  return normalizeFeeSummary({ ...structure, ...summary, components: structure.components.length ? structure.components : summary.components, feeComponents: structure.feeComponents?.length ? structure.feeComponents : summary.feeComponents,tuitionFee:amount(summary.tuitionFee,structure.tuitionFee),admissionFee:amount(summary.admissionFee,structure.admissionFee),hostelFee:amount(summary.hostelFee,structure.hostelFee),transportFee:amount(summary.transportFee,structure.transportFee),scholarshipAmount:amount(summary.scholarshipAmount,structure.scholarshipAmount),totalFee:amount(summary.totalFee,structure.totalFee) })
}
const defaultFeeSummary = data => {
  const matchedPlan = findMatchingFeeStructure(data.academic, data.admission, data.fees?.structureId);
  const hostelFee = getResolvedHostelFee(data.admission, data.fees, data.academic)
  const transportFee = getResolvedTransportFee(data.admission, data.fees, data.academic)
  const scholarshipAmount = Number(data.fees?.scholarshipAmount || 0)

  if (matchedPlan) {
    const rawComps = Array.isArray(matchedPlan.components) ? matchedPlan.components : Array.isArray(matchedPlan.feeComponents) ? matchedPlan.feeComponents : [];
    const components = rawComps.map(item => ({
      ...item,
      name: item.name ?? item.feeHeadName ?? item.componentName ?? 'Fee Component',
      amount: Number(item.amount ?? item.feeAmount ?? 0)
    }));
    const tuition = components.filter(c => !/admission|registration/i.test(c.name)).reduce((sum, c) => sum + Number(c.amount || 0), 0) || Number(matchedPlan.amount || 0);
    const admissionComp = components.find(c => /admission|registration/i.test(c.name));
    const admissionFee = admissionComp ? Number(admissionComp.amount || 0) : Number(data.fees?.admissionFee || 0);
    const total = Math.max(0, tuition + admissionFee + hostelFee + transportFee - scholarshipAmount);

    return {
      configured: true,
      structureId: matchedPlan.id,
      structureName: matchedPlan.name,
      planName: matchedPlan.name,
      tuitionFee: tuition,
      admissionFee,
      hostelFee,
      transportFee,
      scholarshipAmount,
      totalFee: total,
      components,
      installments: matchedPlan.installments || matchedPlan.paymentPlan?.installments || [],
      paymentStatus: data.fees?.paymentStatus || 'Pending',
      paymentPlan: matchedPlan.plan || matchedPlan.paymentPlan?.mode || data.fees?.paymentPlan || 'Full Payment',
      source: 'matchedPlan'
    };
  }

  if (data.fees?.components?.length || Number(data.fees?.tuitionFee) > 0) {
    const tuition = Number(data.fees?.tuitionFee || 0);
    const admissionFee = Number(data.fees?.admissionFee || 0);
    const total = Math.max(0, tuition + admissionFee + hostelFee + transportFee - scholarshipAmount);
    return {
      configured: true,
      structureId: data.fees?.structureId || '',
      structureName: data.fees?.structureName || 'Academic Fee Plan',
      planName: data.fees?.structureName || 'Academic Fee Plan',
      tuitionFee: tuition,
      admissionFee,
      hostelFee,
      transportFee,
      scholarshipAmount,
      totalFee: total,
      components: data.fees.components || [],
      installments: data.fees.installments || [],
      paymentStatus: data.fees?.paymentStatus || 'Pending',
      paymentPlan: data.fees?.paymentPlan || 'Full Payment',
      source: 'existing'
    };
  }

  return {
    configured: false,
    structureId: '',
    structureName: '',
    planName: '',
    tuitionFee: 0,
    admissionFee: 0,
    hostelFee,
    transportFee,
    scholarshipAmount,
    totalFee: Math.max(0, hostelFee + transportFee - scholarshipAmount),
    components: [],
    installments: [],
    paymentStatus: data.fees?.paymentStatus || 'Pending',
    paymentPlan: 'Full Payment',
    source: 'unconfigured'
  };
}
const resolveFeeSummary = (_data, summaryResponse, structureResponse) => studentIntegrationFees(summaryResponse, structureResponse)
const normalizeEmail = value => text(value).toLowerCase()
const validEmail = value => { const email = normalizeEmail(value); return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/i.test(email) && !email.includes('..') }
const academicEndYear = data => Number(String(data.academic.academicYear || new Date().getFullYear()).slice(0,4)) || new Date().getFullYear()
const validPassingYear = (value, data, level) => { if (!/^\d{4}$/.test(text(value))) return 'Enter a valid 4-digit passing year.'; const year=Number(value), limit=academicEndYear(data); if(year>limit)return 'Year of passing cannot be in the future.'; const birthYear=data.personal.dob?new Date(`${data.personal.dob}T00:00:00`).getFullYear():null; if(birthYear&&year<birthYear+(level==='tenth'?14:16))return 'Year of passing is not valid for the student date of birth.'; if(level==='intermediate'&&data.previousEducation.tenth.passingYear&&year<Number(data.previousEducation.tenth.passingYear))return 'Qualification year cannot be earlier than the 10th passing year.'; return '' }
const validScore = item => { const value=text(item.score); if(!value)return ''; if(!/^\d+(\.\d{1,2})?$/.test(value))return `Enter a valid ${item.scoreType.toLowerCase()}.`; const number=Number(value), max=item.scoreType==='CGPA'?10:100; return number<0||number>max?`${item.scoreType} must be between 0 and ${max}.`:'' }

const _aadhaarChecksum = value => {
  const digits = text(value).replace(/\D/g, '')
  if (!/^\d{12}$/.test(digits) || /^(\d)\1{11}$/.test(digits)) return false
  const d = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]]
  const p = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]]
  return [...digits].reverse().reduce((checksum, digit, index) => d[checksum][p[index % 8][Number(digit)]], 0) === 0
}
const validAadhaar = value => /^\d{12}$/.test(text(value)) && !/^(\d)\1{11}$/.test(text(value))
const validDob = value => {
  if (!text(value)) return true
  const dob = new Date(`${value}T00:00:00`)
  if (Number.isNaN(dob.getTime())) return false
  const today = new Date()
  const latestEligibleDob = new Date(today.getFullYear() - 17, today.getMonth(), today.getDate())
  return dob <= latestEligibleDob
}
const REQUIRED = ['personal.firstName','personal.lastName','personal.gender','personal.dob','personal.aadhaar','contact.mobile','contact.email','contact.currentAddress.line1','contact.currentAddress.town','contact.currentAddress.city','contact.currentAddress.district','contact.currentAddress.state','contact.currentAddress.pincode','academic.academicYear','academic.admissionType','academic.course','academic.branch','admission.collegeId']
const requiredPaths = new Set(REQUIRED)
const validationStep = path => {
  const prefixes = ['personal.','academic.','parents.','contact.','previousEducation.','admission.','fees.','documents.']
  const index = prefixes.findIndex(prefix => path.startsWith(prefix))
  return index < 0 ? 1 : LEGACY_STEP_TO_MAIN[index]
}
const validationLabel = path => {
  const labels = {
    'admission.hostelPreference':'Hostel preference',
    'admission.hostelRoomType':'Hostel room type',
    'admission.transportRoute':'Transport route',
  }
  return labels[path] || path.split('.').at(-1).replace(/([A-Z])/g,' $1').replace(/^./,value=>value.toUpperCase())
}
const validate = data => {
  const errors = {}
  REQUIRED.forEach(path => { if (!text(read(data, path))) errors[path] = 'This field is required.' })
  if (data.personal.dob && !validDob(data.personal.dob)) errors['personal.dob'] = 'Student must be at least 17 years old.'
  if (!data.contact.sameAddress) ['line1','town','city','district','state','pincode'].forEach(key => { if (!text(data.contact.permanentAddress[key])) errors[`contact.permanentAddress.${key}`] = 'This field is required.' })
  if (data.personal.aadhaar && !validAadhaar(data.personal.aadhaar)) errors['personal.aadhaar'] = 'Enter a valid 12-digit Aadhaar number.'
  ;['contact.mobile','contact.alternateMobile','parents.father.mobile','parents.mother.mobile','parents.guardian.mobile'].forEach(path => { if (read(data, path) && !/^[6-9]\d{9}$/.test(read(data, path))) errors[path] = 'Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.' })
  ;['contact.email','contact.alternateEmail','parents.father.email','parents.mother.email','parents.guardian.email'].forEach(path => { if (text(read(data,path)) && !validEmail(read(data,path))) errors[path] = 'Enter a valid email address.' })
  if (text(data.contact.alternateMobile) && data.contact.mobile === data.contact.alternateMobile) errors['contact.alternateMobile'] = 'Alternate mobile number must be different from the student mobile number.'
  if (text(data.contact.alternateEmail) && text(data.contact.email).toLowerCase() === text(data.contact.alternateEmail).toLowerCase()) errors['contact.alternateEmail'] = 'Alternate email must be different from the student email.'
  ;[['tenth','tenth'],['intermediate','intermediate']].forEach(([key,level]) => { const item=data.previousEducation[key], yearError=item.passingYear?validPassingYear(item.passingYear,data,level):''; if(yearError)errors[`previousEducation.${key}.passingYear`]=yearError; const scoreError=validScore(item); if(scoreError)errors[`previousEducation.${key}.score`]=scoreError })
  if (data.academic.admissionType === 'Lateral Entry' && !text(data.academic.quota)) errors['academic.quota'] = 'Select the admission quota for lateral entry.'
  if (data.academic.admissionType === 'Lateral Entry' && data.academic.quota === 'Other' && !text(data.academic.quotaOther)) errors['academic.quotaOther'] = 'Enter the admission quota.'
  if (data.previousEducation.intermediate.stream === 'Other' && !text(data.previousEducation.intermediate.streamOther)) errors['previousEducation.intermediate.streamOther'] = 'Enter the stream name.'
  if (data.admission.hostel === 'Yes' && !text(data.admission.hostelPreference)) errors['admission.hostelPreference'] = 'Select a hostel preference.'
  if (data.admission.hostel === 'Yes' && !text(data.admission.hostelRoomType)) errors['admission.hostelRoomType'] = 'Select a room type / number of beds.'
  if (data.admission.transport === 'Yes' && !text(data.admission.transportRoute)) errors['admission.transportRoute'] = 'Select a transport route.'
  ;['tuitionFee','admissionFee','scholarshipAmount','hostelFee','transportFee'].forEach(key => { if (text(data.fees[key]) && Number(data.fees[key]) < 0) errors[`fees.${key}`] = 'Amount cannot be negative.' })
  const grossFee = ['tuitionFee','admissionFee','hostelFee','transportFee'].reduce((sum,key) => sum + Number(data.fees[key] || 0), 0)
  if (Number(data.fees.scholarshipAmount || 0) > grossFee) errors['fees.scholarshipAmount'] = 'Scholarship cannot exceed the gross fee.'
  ;['permanentAddress','currentAddress'].forEach(section => { if (section === 'permanentAddress' && data.contact.sameAddress) return; const item = data.contact[section]; if (item.pincode && !/^\d{6}$/.test(item.pincode)) errors[`contact.${section}.pincode`] = 'Enter a valid 6-digit PIN code.'; if (item.line1 && item.line1.length < 5) errors[`contact.${section}.line1`] = 'Enter a complete address.' })
  return errors
}

const duplicateAdmissionMessage = (rows, candidate, currentAdmissionId = '') => {
  const digits = value => String(value || '').replace(/\D/g, '')
  const candidateId = String(currentAdmissionId || candidate.admissionId || candidate.studentAdmissionId || '')
  const match = rows.map(admissionFromApi).find((row) => {
    // Normalized admissions use `id` for the student profile when one exists;
    // compare the admission-specific ID first so editing this same record does
    // not report its Aadhaar/mobile as a duplicate of itself.
    const rowAdmissionId = String(row.admissionId ?? row.studentAdmissionId ?? row.id ?? '')
    if (candidateId && rowAdmissionId === candidateId) return false
    return (digits(candidate.personal?.aadhaar).length === 12 && digits(row.personal?.aadhaar) === digits(candidate.personal?.aadhaar))
      || (digits(candidate.contact?.mobile).length === 10 && digits(row.contact?.mobile) === digits(candidate.contact?.mobile))
  })
  if (!match) return ''
  if (digits(candidate.personal?.aadhaar).length === 12 && digits(match.personal?.aadhaar) === digits(candidate.personal?.aadhaar)) return 'An admission with this Aadhaar number already exists.'
  return 'An admission with this student mobile number already exists.'
}

function Badge({ value }) {
  const norm = normalizeStatus(value);
  const rawStr = String(value || '').trim();
  const lower = rawStr.toLowerCase();
  const isSubmitted = norm === 'SUBMITTED' || lower === 'submitted' || lower === 'verified';
  const isApproved = norm === 'APPROVED' || lower === 'approved';
  const isRejected = norm === 'REJECTED' || lower === 'rejected';
  const isPending = ['PENDING', 'UNDER_REVIEW', 'CORRECTION_REQUIRED'].includes(norm) || lower === 'pending' || lower === 'correction required';
  const isNotSubmitted = lower.includes('not submitted');

  const badgeClass = isSubmitted
    ? 'status-submitted'
    : isApproved
    ? 'status-approved'
    : isRejected
    ? 'status-rejected'
    : isPending
    ? 'status-pending'
    : isNotSubmitted
    ? 'status-not-submitted'
    : `status-${norm.toLowerCase().replaceAll('_', '-')}`;

  return (
    <span className={`sa-badge ${badgeClass}`}>
      <i />
      {STATUS[norm] || STATUS[value] || value}
    </span>
  );
}
function Button({ primary = false, danger = false, children, ...props }) { return <button type="button" className={danger ? 'sa-danger' : primary ? 'sa-primary' : 'sa-secondary'} {...props}>{children}</button> }
function ConfirmDialog({ icon: Icon = FiAlertCircle, title, confirmLabel = 'Confirm', onCancel, onConfirm, busy = false, error = null, children }) {
  return <ViewDialog title={title} icon={Icon} onClose={onCancel} busy={busy} showExport={false} hideFooter maxWidth="560px">
    {error && <p role="alert" className="sa-callout danger">{error}</p>}
    <div className="sa-dialog-copy">{children}</div>
    <footer className="sa-wizard-actions"><Button disabled={busy} onClick={onCancel}>Cancel</Button><Button primary disabled={busy} onClick={onConfirm}>{busy ? 'Processing...' : confirmLabel}</Button></footer>
  </ViewDialog>
}

function Section({ title, icon: Icon = FiFileText, hint, action, children, className = '' }) {
  const shownTitle = title === 'Application Information' ? 'Registration Details' : title;
  return (
    <section className={`sa-form-section ${className}`}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span><Icon /></span>
          <div>
            <h2>{shownTitle}</h2>
            {hint && <p>{hint}</p>}
          </div>
        </div>
        {action && <div className="sa-section-action">{action}</div>}
      </header>
      <div className="sa-form-grid">{children}</div>
    </section>
  )
}

function Field({ data, path, label, update, options, type = 'text', readOnly = false, error, placeholder, disabled = false, required, markTouched }) {
  const isRequired = required !== undefined ? required : (
    requiredPaths.has(path) ||
    (!data?.contact?.sameAddress && path.startsWith('contact.permanentAddress.') && ['line1','town','city','district','state','pincode'].includes(path.split('.').at(-1))) ||
    (data?.academic?.admissionType === 'Lateral Entry' && path === 'academic.quota') ||
    (data?.academic?.admissionType === 'Lateral Entry' && data?.academic?.quota === 'Other' && path === 'academic.quotaOther') ||
    (data?.previousEducation?.intermediate?.stream === 'Other' && path === 'previousEducation.intermediate.streamOther') ||
    (data?.admission?.hostel === 'Yes' && ['admission.hostelPreference', 'admission.hostelRoomType'].includes(path)) ||
    (data?.admission?.transport === 'Yes' && path === 'admission.transportRoute')
  )
  const value = read(data, path) ?? ''
  const shownLabel = ({ 'Application Number': 'Registration Number', 'Application Date': 'Registration Date' })[label] || label
  const numeric = /mobile|pincode|aadhaar|passingYear/i.test(path)
  const maxLength = /aadhaar$/i.test(path) ? 12 : /pincode/i.test(path) ? 6 : /mobile/i.test(path) ? 10 : /passingYear/i.test(path) ? 4 : undefined
  const id = `sa-${path.replaceAll('.', '-')}`
  const change = event => {
    markTouched?.(path)
    update(path, numeric ? event.target.value.replace(/\D/g, '').slice(0, maxLength) : event.target.value)
  }
  const blur = () => {
    markTouched?.(path)
    if (/email/i.test(path) && value !== text(value)) update(path, text(value))
  }
  return (
    <label className={`sa-field ${error ? 'invalid' : ''}`} htmlFor={id}>
      <span>{shownLabel}{isRequired && <b> *</b>}</span>
      {options ? (
        <ProjectSelect id={id} value={value} disabled={disabled || readOnly} required={isRequired} onChange={change} onBlur={blur} aria-required={isRequired} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-error` : undefined}>
          <option value="">{placeholder || `Select ${shownLabel}`}</option>
          {options.map(option => <option key={option}>{option}</option>)}
        </ProjectSelect>
      ) : (
        <input id={id} type={type} value={value} readOnly={readOnly || path === 'admission.batch'} disabled={disabled} inputMode={numeric ? 'numeric' : type === 'number' ? 'decimal' : undefined} min={type === 'number' ? 0 : undefined} maxLength={maxLength} placeholder={placeholder} onChange={change} onBlur={blur} aria-required={isRequired} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-error` : undefined} />
      )}
      {error && <small id={`${id}-error`} role="alert">{error}</small>}
    </label>
  )
}
function AddressFields({ data, prefix, update, errors, markTouched }) { return [['line1','Address Line 1'],['line2','Landmark (Optional)'],['town','Village / Town'],['city','City'],['district','District'],['state','State'],['country','Country'],['pincode','PIN Code']].map(([key,label]) => <Field key={key} data={data} path={`${prefix}.${key}`} label={label} update={update} error={errors[`${prefix}.${key}`]} markTouched={markTouched} />) }
function Breadcrumb({ tail }) { return <div className="sa-breadcrumb"><span>Student Management</span><FiChevronRight /><span>Admissions</span>{tail && <><FiChevronRight /><strong>{tail}</strong></>}</div> }

function AdmissionFilters({ rows, query, setQuery, filters, setFilters, hidden = false }) {
  const options = key => [...new Set(rows.map(item => key === 'status' ? item.status : key === 'feeStatus' ? (item.fees?.paymentStatus || 'Pending') : key === 'quota' ? quota(item) : item.academic?.[key]).filter(Boolean))].sort()
  const active = Object.entries(filters).filter(([,value]) => value)
  const clear = () => { setQuery(''); setFilters(Object.fromEntries(FILTERS.map(([key]) => [key, '']))) }
  return (
    <section id="admission-filters" className="sa-admission-filters" aria-label="Search and filter admissions" hidden={hidden}>
      <FilterPanel
        className="sa-admission-filter-panel"
        active={active.length > 0}
        search={<label className="sa-search">
          <FiSearch aria-hidden="true" />
          <input value={query} onChange={event => setQuery(event.target.value)} title="Search name, registration, admission, mobile or email" placeholder="Search name, registration, admission, mobile or email" />
        </label>}
        actions={Boolean(query || active.length) && (
          <button type="button" className="sa-clear-filters" onClick={clear}><FiX aria-hidden="true" /> Clear filters</button>
        )}
        filters={(
          <div className="sa-filter-grid">
            {FILTERS.map(([key,label]) => <label key={key}>
              <span>{label}</span>
              <ProjectSelect value={filters[key]} onChange={event => setFilters(current => ({ ...current, [key]: event.target.value, ...(key === 'course' ? { branch: '' } : {}) }))}>
                <option value="">All {label}</option>
                {options(key).map(value => <option value={value} key={value}>{key === 'status' ? (STATUS[value] || value) : value}</option>)}
              </ProjectSelect>
            </label>)}
          </div>
        )}
      />
      {active.length > 0 && <div className="sa-filter-chips">{active.map(([key,value]) => <button type="button" key={key} onClick={() => setFilters(current => ({ ...current, [key]: '' }))}>{FILTERS.find(item => item[0] === key)?.[1]}: {key === 'status' ? (STATUS[value] || value) : value} <FiX aria-hidden="true" /></button>)}</div>}
    </section>
  )
}
function EmptyState() {
  return <div className="sa-empty"><span><FiInbox /></span><h3>No admission applications found</h3><p>Create a new admission application to begin student enrollment.</p></div>
}

function AdmissionList() {
  const { canAction } = useScreenAccess()
  const canCreate = canAction('/student-management/admissions', 'create'), canEdit = canAction('/student-management/admissions', 'edit')
  const [loading, setLoading] = useState(true)
  const [loadError, setDirectoryError] = useState('')
  const requestSequence = useRef(0)
  const [sort, setSort] = useState('recent')
  const navigate = useNavigate()
  const { selectedCollegeId, selectedCollege, selectedAcademicYearId, selectedAcademicYear } = useAcademic()
  const [rows, setRows] = useCollegeState([])
  const [, setLoadError] = useToastState('', 'error')
  const [exportReady, setExportReady] = useState(false)
  const [query, setQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [page, setPage] = useState(1)
  const initialFilters = Object.fromEntries(FILTERS.map(([key]) => [key, '']))
  const [filters, setFilters] = useState(initialFilters)
  const activeFilterCount = Object.values(filters).filter(Boolean).length + Number(Boolean(query.trim()))
  const loadAdmissions = useCallback(() => {
    const requestId = ++requestSequence.current
    let active = true
    setLoading(true); setDirectoryError('')
    studentAdmissionApi.getAll().then(items => {
      if (active && requestId === requestSequence.current) {
        setExportReady(isApiResult(items))
        setRows(newestFirst('admissions', items).map(admissionFromApi))
      }
    }).catch(error => {
      if (active && requestId === requestSequence.current) { setDirectoryError(error.message || 'Unable to load admissions.'); setLoadError(error.message || 'Unable to load admissions.'); setExportReady(false) }
    }).finally(() => { if (active && requestId === requestSequence.current) setLoading(false) })
    return () => { active = false }
  }, [setLoadError, selectedCollegeId, selectedAcademicYearId])

  useEffect(() => {
    const cancel = loadAdmissions()
    return cancel
  }, [loadAdmissions])

  useEffect(() => {
    const unsub = eventBus.on(ERP_EVENTS.STUDENT_UPDATED, () => {
      loadAdmissions()
    })
    return () => unsub?.()
  }, [loadAdmissions])

  const normYear = y => String(y || '').replace(/[^0-9]/g, '')
  const scopedRows = useMemo(() => {
    return rows.filter(item => {
      let collegeMatches = true
      if (selectedCollegeId) {
        const itemCollegeId = item.admission?.collegeId ?? item.collegeId ?? item.academic?.collegeId ?? ''
        const itemCollegeName = item.admission?.college ?? item.college ?? ''
        const matchById = itemCollegeId && String(itemCollegeId) === String(selectedCollegeId)
        const matchByName = selectedCollege?.name && itemCollegeName && itemCollegeName.trim().toLowerCase() === selectedCollege.name.trim().toLowerCase()
        collegeMatches = Boolean(matchById || matchByName)
      }

      let yearMatches = true
      if (selectedAcademicYearId) {
        const itemYearId = item.academic?.academicYearId ?? item.academicYearId ?? ''
        const itemYearName = item.academic?.academicYear ?? item.academicYear ?? ''
        const matchById = itemYearId && String(itemYearId) === String(selectedAcademicYearId)
        const matchByName = selectedAcademicYear?.name && itemYearName && (
          normYear(itemYearName) === normYear(selectedAcademicYear.name) ||
          itemYearName.trim().toLowerCase() === selectedAcademicYear.name.trim().toLowerCase()
        )
        yearMatches = Boolean(matchById || matchByName)
      }

      return collegeMatches && yearMatches
    })
  }, [rows, selectedCollegeId, selectedCollege, selectedAcademicYearId, selectedAcademicYear])

  const shown = useMemo(() => scopedRows.filter(item => {
    const needle = [studentName(item),item?.application?.number,item?.application?.admissionNumber,item?.application?.registrationNumber,item?.contact?.mobile,item?.contact?.email].join(' ').toLowerCase()
    const normStat = normalizeStatus(item?.status)
    const values = { status: normStat, course: item?.academic?.course, department: item?.academic?.department, branch: item?.academic?.branch, semester: item?.academic?.semester, admissionType: item?.academic?.admissionType, quota: quota(item), feeStatus: item?.fees?.paymentStatus || 'Pending' }
    return needle.includes(query.trim().toLowerCase()) && Object.entries(filters).every(([key,value]) => !value || values[key] === value)
  }), [scopedRows, query, filters])
  useEffect(() => { setPage(1) }, [query, filters])
  const totalPages = Math.max(1, Math.ceil(shown.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const sortedRows = [...shown].sort((a, b) => sort === 'name' ? studentName(a).localeCompare(studentName(b)) : sort === 'registration' ? String(a.application.number).localeCompare(String(b.application.number), undefined, { numeric: true }) : 0)
  const pageRows = sortedRows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)
  const clear = () => { setQuery(''); setFilters(initialFilters); setPage(1) }
  const stats = {
    total: scopedRows.length,
    approved: scopedRows.filter(item => normalizeStatus(item.status) === 'APPROVED').length,
    pending: scopedRows.filter(item => ['SUBMITTED', 'PENDING', 'UNDER_REVIEW', 'VERIFIED', 'DOCUMENT_VERIFICATION'].includes(normalizeStatus(item.status))).length,
    draft: scopedRows.filter(item => normalizeStatus(item.status) === 'DRAFT').length,
  }

  return (
    <>
      <PageHeader
        title="Student Admissions"
        subtitle="Manage registrations, review and approval in the selected college and academic year."
        compactSummary={[
          { label: 'Applications', value: loading ? '—' : stats.total },
          { label: 'Approved', value: loading ? '—' : stats.approved, tone: 'active' },
          { label: 'Awaiting review', value: loading ? '—' : stats.pending, tone: 'upcoming' },
          { label: 'Drafts', value: loading ? '—' : stats.draft },
        ]}
      />
      <section className="sa-directory cm-panel">
        <header className="course-directory-heading">
          <div>
            <span className="cm-eyebrow">Admission Directory</span>
            <p>{shown.length} records</p>
          </div>
          <div className="directory-export-actions">
            <ExportMenu rows={shown} columns={admissionColumns} recordSections={admissionDetailSections} title="Student Admissions" filename="student-admissions" loading={!exportReady} scope="Current filtered API results" />
            <button
              type="button"
              className={`sa-secondary sa-filter-toggle ${showFilters ? 'is-open' : ''} ${activeFilterCount ? 'has-filters' : ''}`}
              aria-expanded={showFilters}
              aria-controls="admission-filters"
              onClick={() => setShowFilters(value => !value)}
            >
              <FiFilter aria-hidden="true" />
              {showFilters ? 'Hide filters' : 'Filters'}
              {activeFilterCount > 0 && <span className="sa-filter-count" aria-label={`${activeFilterCount} active filter${activeFilterCount === 1 ? '' : 's'}`}>{activeFilterCount}</span>}
            </button>
            <button hidden={!canCreate} className="cm-button" type="button" onClick={() => navigate('/student-management/admissions/new')}>
              <FiPlus /> New Admission
            </button>
          </div>
        </header>
        <AdmissionFilters rows={scopedRows} query={query} setQuery={setQuery} filters={filters} setFilters={setFilters} hidden={!showFilters} />
        <label className="sa-sort">Sort by <select aria-label="Sort admissions" value={sort} onChange={event => { setSort(event.target.value); setPage(1) }}><option value="recent">Recently added</option><option value="name">Student name</option><option value="registration">Registration number</option></select></label>
        {loading ? <p role="status" className="sa-empty">Loading admissions...</p> : loadError ? <div className="sa-empty" role="alert"><p>{loadError}</p><Button onClick={loadAdmissions}>Retry</Button></div> : !scopedRows.length || !shown.length ? (
          <EmptyState hasRows={Boolean(scopedRows.length)} filtered={Boolean(query || Object.values(filters).some(Boolean))} onCreate={() => navigate('/student-management/admissions/new')} onClear={clear} />
        ) : (
          <div className="sa-table-wrap" tabIndex={0} role="region" aria-label="Student admissions table">
            <table className="sa-admission-table">
              <caption className="sr-only">Student admission applications</caption>
              <thead>
                <tr>
                  <th style={{ minWidth: '150px' }}>Registration Number</th>
                  <th style={{ minWidth: '200px' }}>Student</th>
                  <th style={{ minWidth: '170px' }}>Academic Enrollment</th>
                  <th style={{ minWidth: '130px', maxWidth: '160px' }}>Admission Type</th>
                  <th className="table-center" style={{ width: '120px' }}>Fee Status</th>
                  <th className="table-center" style={{ width: '140px' }}>Application Status</th>
                  <th className="table-center" style={{ width: '140px' }}>Updated</th>
                  <th className="table-center" style={{ width: '140px' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {pageRows.map(item => {
                  const normStat = normalizeStatus(item.status)
                  const feeStat = item.fees?.paymentStatus || 'Pending'
                  const isEditable = canEdit && ['DRAFT', 'CORRECTION_REQUIRED'].includes(normStat)
                  const isReviewable = canEdit && ['SUBMITTED', 'PENDING', 'UNDER_REVIEW', 'VERIFIED'].includes(normStat)
                  const targetId = item.admissionId || item.id || item.studentAdmissionId
                  const sName = studentName(item)
                  const sContact = item.contact.email || item.contact.mobile || 'Contact pending'
                  return (
                    <tr key={item.id}>
                      <td style={{ minWidth: '150px' }}>
                        <div className="table-primary-cell">
                          <strong title={item.application.number}>{item.application.number}</strong>
                          <small title={item.application.admissionNumber || 'Admission pending'}>{item.application.admissionNumber || 'Admission pending'}</small>
                        </div>
                      </td>
                      <td style={{ minWidth: '200px' }}>
                        <div className="sa-student">
                          <i>{item.personal.photo ? <img src={item.personal.photo} alt={sName} /> : sName.split(' ').map(part => part[0]).slice(0, 2).join('')}</i>
                          <span>
                            <button type="button" className="student-name-link" title={sName} aria-label={`View details for ${sName}`} onClick={() => { const targetId = item.admissionId || item.id || item.studentAdmissionId; if (targetId) navigate(`/student-management/admissions/${targetId}`) }}>{sName}</button>
                            <small title={sContact}>{sContact}</small>
                          </span>
                        </div>
                      </td>
                      <td style={{ minWidth: '170px' }}>
                        <div className="table-primary-cell">
                          <strong title={display(item.academic.course)}>{display(item.academic.course)}</strong>
                          <small title={display(item.academic.branch)}>{display(item.academic.branch)}</small>
                        </div>
                      </td>
                      <td style={{ minWidth: '130px', maxWidth: '160px' }}><span className="table-cell-truncate" title={display(item.academic.admissionType)}>{display(item.academic.admissionType)}</span></td>
                      <td className="table-center" style={{ width: '120px' }}><StatusBadge value={formatFeeStatus(feeStat)} /></td>
                      <td className="table-center" style={{ width: '140px' }}><StatusBadge value={STATUS[normStat] || normStat} /></td>
                      <td className="table-center" style={{ width: '140px' }}><span className="sa-updated">{dateTime(item.updatedAt || item.createdAt)}</span></td>
                      <td className="table-center" style={{ width: '176px', minWidth: '176px' }}>
                        <div className="sa-icon-actions table-actions-group">
                          <button
                            type="button"
                            className="table-action-btn action-view"
                            title="View Application"
                            aria-label={`View application for ${sName}`}
                            onClick={() => { if (targetId) navigate(`/student-management/admissions/${targetId}`) }}
                          >
                            <FiEye />
                          </button>
                          {isEditable && (
                            <button
                              type="button"
                              className="table-action-btn action-edit"
                              title="Edit Application"
                              aria-label={`Edit application for ${sName}`}
                              onClick={() => {
                                if (targetId) navigate(`/student-management/admissions/${targetId}/edit`)
                              }}
                            >
                              <FiEdit2 />
                            </button>
                          )}
                          <button
                            type="button"
                            className="table-action-btn action-deactivate"
                            title="Delete unavailable: admissions API does not support deletion"
                            aria-label={`Delete application for ${sName} (unavailable)`}
                            disabled
                          >
                            <FiTrash2 />
                          </button>
                          {isReviewable && (
                            <button
                              type="button"
                              className="table-action-btn action-activate"
                              title="Review / Approve"
                              aria-label={`Review application for ${sName}`}
                              onClick={() => {
                                if (targetId) navigate(`/student-management/admissions/${targetId}/approval`)
                              }}
                            >
                              <FiCheckCircle />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
        {shown.length > 0 && <TablePagination page={currentPage} totalPages={totalPages} onPageChange={setPage} />}
      </section>
    </>
  )
}

function PhotoUpload({ data, update, notify }) {
  const upload = event => {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    if (!['image/jpeg','image/png','image/webp'].includes(file.type)) return notify('Upload a JPG, PNG or WebP student photo.', 'error')
    if (file.size > 1024 * 1024) return notify('Student photo must be 1 MB or smaller.', 'error')
    const reader = new FileReader()
    reader.onload = () => {
      update('personal.photo', reader.result)
      update('personal.photoUrl', reader.result)
      notify('Photo selected. Save the admission step to keep it.', 'info')
    }
    reader.onerror = () => notify('Unable to read the selected photo.', 'error')
    reader.readAsDataURL(file)
  }
  const photoSrc = data.personal.photo ? apiAssetUrl(data.personal.photo) : (data.personal.photoUrl ? apiAssetUrl(data.personal.photoUrl) : '')
  const initials = studentInitials(data)
  return (
    <div className="sa-photo-upload">
      <div className="sa-photo-preview">
        {photoSrc ? <img src={photoSrc} alt="Student live preview" /> : initials || <FiUser />}
      </div>
      <div className="sa-photo-meta">
        <strong>Student Photo</strong>
        <span>JPG, PNG or WebP | Maximum 1 MB</span>
        <div className="sa-photo-actions">
          <label className="sa-photo-button">
            <FiCamera />
            {photoSrc ? 'Change Photo' : 'Upload Photo'}
            <input type="file" accept="image/jpeg,image/png,image/webp" aria-label="Upload student photo" onChange={upload} />
          </label>
          {photoSrc && (
            <button
              type="button"
              className="sa-photo-remove"
              onClick={() => {
                update('personal.photo', '')
                update('personal.photoUrl', '')
              }}
            >
              <FiTrash2 className="module-action-icon module-action-icon--danger" /> Remove
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
function DocumentsUpload({ data, update, notify }) {
  const choose = (key, file) => {
    if (!file) return
    if (!/\.(pdf|jpe?g|png|webp)$/i.test(file.name) || file.size > 5 * 1024 * 1024) { notify('Choose a PDF, JPG, PNG or WEBP document up to 5 MB.', 'error'); return }
    update('documents.' + key, { ...(data.documents?.[key] || {}), file, name: file.name, uploaded: false, status: 'Pending' })
  }
  return <section className="sa-documents"><header><h2>Supporting documents</h2><p>Select files now. Each upload is confirmed by the server when the student identity is available.</p></header><div className="sa-document-grid">{DOCUMENTS.map(([key,label]) => {
    const document = data.documents?.[key]
    return <article className="sa-document-item" key={key}><FiFileText /><div className="sa-document-copy"><strong>{label}</strong><span>{document?.file ? 'Selected — awaiting upload' : document?.uploaded || document?.id ? 'Uploaded' : document?.status || 'Not uploaded'}</span><small>{document?.name}</small></div><div className="sa-document-actions"><label className="sa-document-picker">{document?.file || document?.id ? 'Replace file' : 'Choose file'}<input aria-label={label + ' file'} type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" onChange={event => { choose(key,event.target.files?.[0]); event.target.value = '' }} /></label><ProjectSelect aria-label={label + ' status'} value={document?.status || ''} onChange={event => update('documents.' + key,{ ...(document || {}), status:event.target.value })}><option value="">Select status</option><option value="Submitted">Submitted</option><option value="Pending">Pending</option></ProjectSelect>{(document?.id || document?.data) && <DocumentPreview document={document} studentId={data.studentId} />}{document?.file && <Button onClick={() => update('documents.' + key, { ...document, file: undefined, name: undefined })}>Clear selected file</Button>}</div></article>
  })}</div></section>
}
function WizardStepper({ step, setStep, furthestStep, busy }) {
  const navRef = useRef(null), activeRef = useRef(null)
  useEffect(() => {
    const nav = navRef.current
    if (!nav) return
    const revealActiveStep = () => {
      const active = activeRef.current
      if (!active) return
      const navBounds = nav.getBoundingClientRect()
      const activeBounds = active.getBoundingClientRect()
      const left = nav.scrollLeft + activeBounds.left - navBounds.left
        - (nav.clientWidth - activeBounds.width) / 2
      nav.scrollTo({
        left: Math.max(0, Math.min(left, nav.scrollWidth - nav.clientWidth)),
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth',
      })
    }
    const frame = window.requestAnimationFrame(revealActiveStep)
    const observer = new ResizeObserver(revealActiveStep)
    observer.observe(nav)
    return () => {
      window.cancelAnimationFrame(frame)
      observer.disconnect()
    }
  }, [step])
  return (
    <nav ref={navRef} className="sa-reference-stepper" aria-label="Admission form steps">
      {STEPS.map((label, index) => {
        const isCompleted = index < step
        const isActive = index === step
        return (
          <button
            ref={isActive ? activeRef : null}
            key={label}
            type="button"
            className={isActive ? 'active' : isCompleted ? 'completed' : ''}
            onClick={() => setStep(index)}
            disabled={busy || index > Math.max(step, furthestStep)}
            aria-current={isActive ? 'step' : undefined}
            aria-controls="admission-step-content"
            aria-label={`Step ${index + 1} of ${STEPS.length}: ${label}${isActive ? ', current' : isCompleted ? ', completed' : ''}`}
          >
            <span>{isCompleted ? <FiCheck /> : index + 1}</span>
            {label}
          </button>
        )
      })}
    </nav>
  )
}
function FeeSummary({ data }) {
  const fees = data.fees || {}
  const components = Array.isArray(fees.components) ? fees.components : Array.isArray(fees.feeComponents) ? fees.feeComponents : []
  const tuition = Number(fees.tuitionFee) > 0 ? Number(fees.tuitionFee) : (components.filter(c => !/admission|registration/i.test(c.name || '')).reduce((sum, c) => sum + Number(c.amount || 0), 0))
  const admission = Number(fees.admissionFee !== undefined && fees.admissionFee !== '' ? fees.admissionFee : 0)
  const hostel = data.admission?.hostel === 'Yes' ? getResolvedHostelFee(data.admission, fees, data.academic) : 0
  const transport = data.admission?.transport === 'Yes' ? getResolvedTransportFee(data.admission, fees, data.academic) : 0
  const scholarship = data.admission?.scholarship === 'Yes' ? Number(fees.scholarshipAmount || 0) : 0
  const isConfigured = fees.configured !== false && (components.length > 0 || tuition > 0 || admission > 0)
  const rows = [
    ...(isConfigured ? [['Tuition Fee (per year)', tuition], ['Admission Fee (one-time)', admission]] : []),
    ...(data.admission?.hostel === 'Yes' ? [['Hostel Fee (per year)', hostel]] : []),
    ...(data.admission?.transport === 'Yes' ? [['Transportation Fee (per year)', transport]] : [])
  ]
  const gross = rows.reduce((sum, [, value]) => sum + Number(value || 0), 0)
  const net = Math.max(0, gross - scholarship)
  return (
    <aside className="sa-fee-summary">
      <header>
        <span><FiInbox /></span>
        <div>
          <h3>Fee Summary</h3>
          <p>{isConfigured ? (fees.structureName || fees.planName || 'Configured Fee Plan') : 'Fee Structure Not Configured'}</p>
        </div>
      </header>
      {isConfigured || hostel > 0 || transport > 0 ? (
        <>
          <dl>
            {rows.map(([label, value]) => (
              <div key={label}>
                <dt>{label}</dt>
                <dd>{money(value)}</dd>
              </div>
            ))}
            <div className="subtotal">
              <dt>Gross Fee</dt>
              <dd>{money(gross)}</dd>
            </div>
            {scholarship > 0 && (
              <div className="deduction">
                <dt>Scholarship Deduction</dt>
                <dd>− {money(scholarship)}</dd>
              </div>
            )}
          </dl>
          <footer>
            <span>
              Net Payable
              <small>After applicable deductions</small>
            </span>
            <strong>{money(net > 0 ? net : (Number(data.fees?.totalFee) || 0))}</strong>
          </footer>
        </>
      ) : (
        <div style={{ padding: '16px', color: 'var(--text-muted)', fontSize: '12px' }}>
          No active fee plan configured for the selected academic program.
        </div>
      )}
    </aside>
  )
}
/* oxlint-disable-next-line react-hooks/exhaustive-deps -- update is intentionally triggered only when academic matching inputs change */
function ApplicantFeeStructure({ data, update, error }) {
  const fees = data.fees || {}
  const collegeId = Number(data.admission?.collegeId || data.academic?.collegeId)
  const academicYearId = Number(data.academic?.academicYearId)
  const courseId = Number(data.academic?.courseId)
  const branchId = Number(data.academic?.branchId)
  const semesterId = Number(data.academic?.semesterId || 0)
  const batch = String(data.admission?.batch || data.academic?.batch || '').trim()
  const quota = String(data.academic?.quota || '').trim()
  const studentCategory = String(data.academic?.studentCategory || '').trim()
  const [serverPlanState, setServerPlanState] = useState({ loading: false, plans: [], error: '' })

  useEffect(() => {
    let active = true
    const scope = { collegeId, academicYearId, courseId, branchId, semesterId, batch, quota, studentCategory }
    if (![collegeId, academicYearId, courseId, branchId].every(value => Number.isInteger(value) && value > 0) || !Number.isInteger(semesterId) || semesterId < 0 || !batch) {
      setServerPlanState({ loading: false, plans: [], error: '' })
      return () => { active = false }
    }
    setServerPlanState(current => ({ ...current, loading: true, error: '' }))
    admissionFeePlanApi.getMatching(scope).then(rows => {
      if (!active) return
      const plans = (Array.isArray(rows) ? rows : []).map(plan => {
        const id = String(plan.feeStructureId ?? plan.id ?? '')
        const mode = String(plan.paymentMode ?? plan.plan ?? '').toUpperCase()
        const paymentMode = /INSTALLMENT|TERM|SEMESTER/.test(mode) ? 'Term-wise Payment' : 'Full Payment'
        const components = (Array.isArray(plan.components) ? plan.components : []).map(item => ({
          ...item,
          name: item.name ?? item.feeHeadName ?? item.componentName ?? item.code ?? 'Fee Component',
          amount: Number(item.amount ?? item.feeAmount ?? 0),
        }))
        return {
          ...plan,
          id,
          name: plan.name ?? plan.planName ?? plan.code ?? `Fee Plan ${id}`,
          status: String(plan.status ?? '').toUpperCase() === 'PUBLISHED' ? 'Published' : plan.status,
          amount: Number(plan.totalAmount ?? plan.amount ?? 0),
          components,
          installments: Array.isArray(plan.installments) ? plan.installments : [],
          plan: paymentMode,
          paymentPlan: { mode: paymentMode, installments: Array.isArray(plan.installments) ? plan.installments : [] },
        }
      }).filter(plan => plan.id)
      setServerPlanState({ loading: false, plans, error: '' })
    }).catch(fetchError => {
      if (active) setServerPlanState({ loading: false, plans: [], error: fetchError.message || 'Unable to fetch approved fee plans.' })
    })
    return () => { active = false }
  }, [collegeId, academicYearId, courseId, branchId, semesterId, batch, quota, studentCategory])

  const matchingPlans = matchingFeeStructures(data.academic, data.admission, serverPlanState.plans)
  const assignedComponents = Array.isArray(fees.components) ? fees.components : Array.isArray(fees.feeComponents) ? fees.feeComponents : []
  const hasAssignedPlan = /^\d+$/.test(String(fees.structureId ?? '')) &&
    (assignedComponents.length > 0 || Number(fees.tuitionFee || 0) > 0 || Number(fees.totalFee || 0) > 0)
  const currentAssignedPlan = hasAssignedPlan ? {
    id: String(fees.structureId),
    name: fees.structureName || fees.planName || 'Currently assigned fee plan',
    status: 'Assigned',
    amount: Number(fees.totalFee || fees.tuitionFee || 0),
    components: assignedComponents,
    installments: Array.isArray(fees.installments) ? fees.installments : [],
    plan: fees.paymentPlan || 'Full Payment',
  } : null
  const availablePlans = currentAssignedPlan && !matchingPlans.some(plan => String(plan.id) === currentAssignedPlan.id)
    ? [...matchingPlans, currentAssignedPlan]
    : matchingPlans
  const selectedPlan = availablePlans.find(plan => String(plan.id) === String(fees.structureId))
  const planMatchesSelectedSemester = plan => {
    const semesterSpecific = plan.cycle === 'Semester-wise' || plan.feePeriod === 'Per Semester' || String(plan.cycle || '').toUpperCase() === 'SEMESTER'
    if (!semesterId || !semesterSpecific) return true
    if (plan.semesterId != null && String(plan.semesterId)) return String(plan.semesterId) === String(semesterId)
    return String(plan.semesterName || '').trim().toLowerCase() === String(data.academic?.semester || '').trim().toLowerCase()
  }
  const matchedPlan = selectedPlan || (availablePlans.length === 1 && planMatchesSelectedSemester(availablePlans[0]) ? availablePlans[0] : null)
  const planSelector = (
    <label className="sa-field">
      <span>Assign Fee Plan</span>
      <ProjectSelect aria-label="Assign admission fee plan" value={matchedPlan?.id || ""} onChange={event => update("fees", { ...fees, configured: false, structureId: event.target.value })} disabled={!availablePlans.length}>
        {availablePlans.length > 1 && !selectedPlan && <option value="">Select a fee plan</option>}
        {!availablePlans.length && <option value="">{serverPlanState.loading ? 'Loading matching fee plans…' : 'No matching approved fee plans'}</option>}
        {availablePlans.map(plan => <option key={plan.id} value={plan.id}>{plan.name || plan.planName} — {feeMoney(feeTotal(plan))}{plan.status === 'Assigned' ? ' (currently assigned)' : ''}</option>)}
      </ProjectSelect>
      <small>{serverPlanState.error && !availablePlans.length ? `Could not fetch approved fee plans: ${serverPlanState.error}. ` : ''}{availablePlans.length > 1 && (!semesterId || availablePlans.some(plan => !planMatchesSelectedSemester(plan))) ? 'Choose the correct semester fee plan; select a valid semester in Academic Enrollment to narrow this list. ' : ''}{!serverPlanState.loading && !availablePlans.length ? 'Check that an approved plan matches the selected college, academic year, course, branch, semester and batch. ' : ''}Select a plan matching this admission's academic details. <Link to="/fees/structures" target="_blank" rel="noopener noreferrer">Manage fee plans</Link></small>
    </label>
  )

  // Sync matched plan to form state if needed
  useEffect(() => {
    if (matchedPlan && (!fees.configured || String(fees.structureId) !== String(matchedPlan.id))) {
      const rawComps = Array.isArray(matchedPlan.components) ? matchedPlan.components : Array.isArray(matchedPlan.feeComponents) ? matchedPlan.feeComponents : []
      const components = rawComps.map(item => ({
        ...item,
        name: item.name ?? item.feeHeadName ?? item.componentName ?? 'Fee Component',
        amount: Number(item.amount ?? item.feeAmount ?? 0)
      }))
      const tuition = components.filter(c => !/admission|registration/i.test(c.name)).reduce((sum, c) => sum + Number(c.amount || 0), 0) || Number(matchedPlan.amount || 0)
      const admissionComp = components.find(c => /admission|registration/i.test(c.name))
      const admissionFee = admissionComp ? Number(admissionComp.amount || 0) : Number(fees.admissionFee || 0)
      const hostel = getResolvedHostelFee(data.admission, fees, data.academic)
      const transport = getResolvedTransportFee(data.admission, fees, data.academic)
      const scholarship = Number(fees.scholarshipAmount ?? fees.discountAmount ?? 0)
      const total = Math.max(0, tuition + admissionFee + hostel + transport - scholarship)

      update('fees', {
        ...fees,
        configured: true,
        structureId: matchedPlan.id,
        structureName: matchedPlan.name,
        planName: matchedPlan.name,
        tuitionFee: String(tuition),
        admissionFee: String(admissionFee),
        hostelFee: String(hostel),
        transportFee: String(transport),
        totalFee: String(total),
        components,
        installments: matchedPlan.installments || matchedPlan.paymentPlan?.installments || [],
        paymentPlan: matchedPlan.plan || matchedPlan.paymentPlan?.mode || fees.paymentPlan || 'Full Payment',
      })
    } else if (!matchedPlan && !fees.components?.length && Number(fees.tuitionFee) === 0 && fees.configured !== false) {
      update('fees.configured', false)
    }
  }, [data.academic.academicYear, data.academic.course, data.academic.branch, data.admission.batch, data.academic.quota, matchedPlan?.id, fees.structureId, fees.configured])

  const components = Array.isArray(fees.components) ? fees.components : Array.isArray(fees.feeComponents) ? fees.feeComponents : []
  const componentName = item => item.name ?? item.feeHeadName ?? item.componentName ?? item.description ?? 'Fee Component'
  const isConfigured = Boolean(matchedPlan || fees.configured || (components.length > 0 && Number(fees.tuitionFee || 0) > 0))

  if (!isConfigured) {
    return (
      <div className="sa-fee-structure-view">
        {planSelector}
        <div className="sa-fee-unconfigured-card">
          <div className="sa-fee-unconfigured-icon">
            <FiAlertCircle />
          </div>
          <div className="sa-fee-unconfigured-body">
            <h3>Fee Structure Not Configured</h3>
            <p>
              No active fee plan matches the selected Academic Year ({display(data.academic.academicYear)}), Course ({display(data.academic.course)}), and Branch ({display(data.academic.branch)}).
            </p>
            <div className="sa-fee-unconfigured-hint">
              Please configure and publish an academic fee structure under <strong>Fee Management &gt; Fee Plans</strong> to establish tuition, fee heads, and payment schedules for this batch.
            </div>
          </div>
        </div>
      </div>
    )
  }

  const admissionComponents = components.filter(item => /admission|registration/i.test(componentName(item)))
  const shownComponents = components.filter(item => !/admission|hostel|transport|scholarship|discount/i.test(componentName(item)) && Number(item.amount ?? item.feeAmount ?? 0) > 0)
  const tuition = Number(fees.tuitionFee ?? fees.academicFee ?? 0) > 0 ? Number(fees.tuitionFee ?? fees.academicFee) : (shownComponents.length ? shownComponents.reduce((sum, c) => sum + Number(c.amount ?? 0), 0) : 0)
  const admission = Number(fees.admissionFee !== undefined && fees.admissionFee !== '' ? fees.admissionFee : 0)
  const hostel = getResolvedHostelFee(data.admission, fees, data.academic)
  const transport = getResolvedTransportFee(data.admission, fees, data.academic)
  const scholarship = Number(fees.scholarshipAmount ?? fees.discountAmount ?? 0)
  const firstYear = Number(fees.totalFee ?? matchedPlan?.totalAmount ?? matchedPlan?.amount ?? 0)
  const entireCourse = Math.max(0, (tuition + hostel + transport) * 4 + admission - scholarship)
  const plan = String(fees.paymentPlan || 'Full Payment').toUpperCase()
  const termWise = plan.includes('TERM') || plan.includes('INSTALLMENT') || plan === 'SEMESTER_WISE'
  const firstTerm = Math.ceil(firstYear / 2)
  const secondTerm = Math.max(0, firstYear - firstTerm)
  const futureTerm = Math.ceil(Math.max(0, tuition + hostel + transport) / 2)
  const setPlan = value => update('fees.paymentPlan', value)
  const installments = fees.installments || matchedPlan?.installments || matchedPlan?.paymentPlan?.installments || []

  return (
    <div className="sa-fee-structure-view">
        {planSelector}
      <section className="sa-applicant-fees">
        <header>
          <FiInbox />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
              <h2>Fee Structure</h2>
              {(fees.structureName || matchedPlan?.name) && (
                <span className="fm-badge fm-badge--published" style={{ fontSize: '11px', fontWeight: 700 }}>
                  {fees.structureName || matchedPlan?.name}
                </span>
              )}
            </div>
            <p>Applicable fee heads and collection schedule for the selected academic program.</p>
          </div>
        </header>
        <dl>
          <div>
            <dt>Course / Branch</dt>
            <dd>{display(data.academic.course)} | {display(data.academic.branch)}</dd>
          </div>
          {shownComponents.length ? (
            shownComponents.map((item, index) => (
              <div key={item.feeComponentId ?? item.id ?? index}>
                <dt>{componentName(item)}</dt>
                <dd>{money(item.amount)}</dd>
              </div>
            ))
          ) : (
            <div>
              <dt>Tuition Fee (per year)</dt>
              <dd>{money(tuition)}</dd>
            </div>
          )}
          {admissionComponents.length > 0 || admission > 0 ? (
            <div className={`sa-admission-fee ${error ? 'invalid' : ''}`}>
              <dt>
                <label htmlFor="sa-admission-fee">
                  {componentName(admissionComponents[0] || { name: 'Admission Fee (one-time)' })}
                  <small>One-time charge</small>
                </label>
              </dt>
              <dd>
                <span>₹</span>
                <input
                  id="sa-admission-fee"
                  type="number"
                  min="0"
                  step="1"
                  value={fees.admissionFee ?? admission}
                  onChange={event => update('fees.admissionFee', event.target.value)}
                  placeholder="Enter amount"
                />
              </dd>
              {error && <small role="alert">{error}</small>}
            </div>
          ) : null}
          {hostel > 0 && (
            <div>
              <dt>Hostel Fee (per year){data.admission.hostelRoomType ? ` | ${data.admission.hostelRoomType}` : ''}</dt>
              <dd>{money(hostel)}</dd>
            </div>
          )}
          {transport > 0 && (
            <div>
              <dt>Transportation Fee (per year){data.admission.transportRoute ? ` | ${data.admission.transportRoute}` : ''}</dt>
              <dd>{money(transport)}</dd>
            </div>
          )}
          {scholarship > 0 && (
            <div>
              <dt>Scholarship / Discount</dt>
              <dd>− {money(scholarship)}</dd>
            </div>
          )}
        </dl>
        <div className="sa-fee-estimates">
          <div>
            <span>Assigned payable amount</span>
            <strong>{money(firstYear)}</strong>
          </div>
          <div><span>Paid amount</span><strong>{fees.paidAmount != null ? money(fees.paidAmount) : 'Unavailable'}</strong></div>
          <div><span>Outstanding balance</span><strong>{fees.balanceAmount != null ? money(fees.balanceAmount) : 'Unavailable'}</strong></div>
        </div>
      </section>

      {/* Payment Preference & Installment Schedule */}
      <section className={`sa-payment-plan ${error ? 'invalid' : ''}`}>
        <h3>Payment Preference <b>*</b></h3>
        <p>Select the payment preference supported by the assigned fee plan.</p>
        <div>
          <label className={!termWise ? 'selected' : ''}>
            <input type="radio" name="paymentPlan" checked={!termWise} onChange={() => setPlan('Full Payment')} />
            <span>
              <strong>Full Payment</strong>
              <small>Pay the complete annual fee in a single payment</small>
            </span>
          </label>
          <label className={termWise ? 'selected' : ''}>
            <input type="radio" name="paymentPlan" checked={termWise} onChange={() => setPlan('Term-wise Payment')} />
            <span>
              <strong>Term-wise / Installments</strong>
              <small>Pay according to the scheduled installment schedule</small>
            </span>
          </label>
        </div>

        {termWise && (
          <section className="sa-term-breakdown">
            <header>
              <strong>Payment Schedule Breakdown</strong>
              <span>{installments.length ? `${installments.length} Scheduled Installments` : 'Schedule unavailable'}</span>
            </header>
            {installments.length > 0 ? (
              <div className="fm-table-wrap" style={{ margin: 0 }}>
                <table className="fm-table" style={{ width: '100%', fontSize: '12px' }}>
                  <thead>
                    <tr>
                      <th style={{ padding: '8px 12px' }}>Installment</th>
                      <th style={{ padding: '8px 12px' }}>Due Date</th>
                      <th style={{ padding: '8px 12px', textAlign: 'right' }}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {installments.map((inst, idx) => (
                      <tr key={inst.id || idx}>
                        <td style={{ padding: '8px 12px', fontWeight: 600 }}>Installment {idx + 1}</td>
                        <td style={{ padding: '8px 12px' }}>{inst.dueDate || '—'}</td>
                        <td style={{ padding: '8px 12px', textAlign: 'right', fontWeight: 700, color: 'var(--brand)' }}>
                          {inst.amount != null ? money(inst.amount) : 'Unavailable'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p>No installment schedule was returned for this fee plan.</p>
            )}
          </section>
        )}
        {error && <small className="field-error" role="alert">{error}</small>}
      </section>
    </div>
  )
}
function ReviewSection({ title, icon: Icon, step, edit, items }) {
  const terms = { 'Application Number': 'Registration Number', 'Application Date': 'Registration Date' }
  const titles = {
    'Student Information': 'Student Information',
    'Contact Information': 'Contact & Address',
    'Parent / Guardian': 'Parent / Guardian Details',
    'Academic Enrollment': 'Academic Enrollment',
    'Previous Education': 'Previous Education History',
    'Admission & Services': 'Admission & Campus Services',
    'Fee Summary': 'Fee Structure & Payment Summary',
    'Uploaded Documents': 'Supporting Documents'
  }
  const normalized = items.map(([label, value, hideEmpty, fullWidth]) => [terms[label] || label, value, hideEmpty, fullWidth])
  const visible = normalized.filter(([, value, hideEmpty]) => !hideEmpty || (text(value) && text(value) !== '-' && text(value) !== 'N/A'))
  if (!visible.length) return null
  return (
    <section className="sa-review-card">
      <header className="sa-review-card-header">
        <div className="sa-card-header-title">
          {Icon && <span className="sa-card-header-icon"><Icon /></span>}
          <h3>{titles[title] || title}</h3>
          <span className="sa-card-count-badge">{visible.length}</span>
        </div>
        {edit && (
          <button type="button" className="sa-card-edit-btn" onClick={() => edit(LEGACY_STEP_TO_MAIN[step] ?? step)}>
            <FiEdit2 size={12} /> Edit
          </button>
        )}
      </header>
      <div className="sa-card-kv-grid">
        {visible.map(([label, value, , fullWidth]) => (
          <div key={label} className={`sa-kv-cell ${fullWidth ? 'sa-kv-full' : ''}`}>
            <span className="sa-kv-label">{label}</span>
            <strong className="sa-kv-val">{display(value)}</strong>
          </div>
        ))}
      </div>
    </section>
  )
}
function CoreReview({ data, edit }) {
  const address = value => formatAddress(value)
  return (
    <div className="sa-review-columns">
      <div className="sa-review-col">
        <ReviewSection
          title="Student Information"
          icon={FiUser}
          step={0}
          edit={edit}
          items={[
            ['Student Name', studentName(data)],
            ['First Name', data.personal?.firstName],
            ['Middle Name', data.personal?.middleName, true],
            ['Last Name', data.personal?.lastName],
            ['Gender', data.personal?.gender],
            ['Date of Birth', data.personal?.dob],
            ['Blood Group', data.personal?.bloodGroup, true],
            ['Nationality', data.personal?.nationality],
            ['Aadhaar Number', data.personal?.aadhaar],
          ]}
        />
        <ReviewSection
          title="Contact Information"
          icon={FiPhone}
          step={1}
          edit={edit}
          items={[
            ['Student Mobile', data.contact?.mobile],
            ['Alternate Mobile', data.contact?.alternateMobile, true],
            ['Student Email', data.contact?.email],
            ['Alternate Email', data.contact?.alternateEmail, true],
            ['Current Address', address(data.contact?.currentAddress), false, true],
            ['Permanent Address', address(data.contact?.permanentAddress) || address(data.contact?.currentAddress), false, true],
          ]}
        />
        <ReviewSection
          title="Parent / Guardian"
          icon={FiUsers}
          step={2}
          edit={edit}
          items={[
            ['Father Name', data.parents?.father?.name, true],
            ['Father Mobile', data.parents?.father?.mobile, true],
            ['Father Email', data.parents?.father?.email, true],
            ['Father Occupation', data.parents?.father?.occupation, true],
            ['Father Qualification', data.parents?.father?.qualification, true],
            ['Annual Income', data.parents?.father?.income, true],
            ['Mother Name', data.parents?.mother?.name, true],
            ['Mother Mobile', data.parents?.mother?.mobile, true],
            ['Mother Email', data.parents?.mother?.email, true],
            ['Mother Occupation', data.parents?.mother?.occupation, true],
            ['Mother Qualification', data.parents?.mother?.qualification, true],
            ['Mother Annual Income', data.parents?.mother?.income, true],
            ['Guardian Name', data.parents?.guardian?.name, true],
            ['Guardian Relationship', data.parents?.guardian?.relationship === 'Other' ? data.parents?.guardian?.relationshipOther : data.parents?.guardian?.relationship, true],
            ['Guardian Mobile', data.parents?.guardian?.mobile, true],
            ['Guardian Email', data.parents?.guardian?.email, true],
            ['Guardian Occupation', data.parents?.guardian?.occupation, true],
            ['Guardian Qualification', data.parents?.guardian?.qualification, true],
            ['Guardian Annual Income', data.parents?.guardian?.income, true],
            ['Primary Contact', data.parents?.primaryContact, true],
            ['Emergency Contact', data.parents?.emergencyMobile, true],
          ]}
        />
        {(() => {
          const rHostel = data.admission?.hostel === 'Yes' ? getResolvedHostelFee(data.admission, data.fees, data.academic) : 0
          const rTransport = data.admission?.transport === 'Yes' ? getResolvedTransportFee(data.admission, data.fees, data.academic) : 0
          const rTuition = Number(data.fees?.tuitionFee || 0)
          const rAdmission = Number(data.fees?.admissionFee || 0)
          const rScholarship = Number(data.fees?.scholarshipAmount || 0)
          const rCalc = Math.max(0, rTuition + rAdmission + rHostel + rTransport - rScholarship)
          const rTotal = rCalc > 0 ? rCalc : Number(data.fees?.totalFee || 0)
          const rPlan = formatPaymentPreference(data.fees?.paymentPlan)
          const isTerm = /term|installment|semester/i.test(String(data.fees?.paymentPlan || ''))
          return (
            <ReviewSection
              title="Fee Summary"
              icon={FiCreditCard}
              step={6}
              edit={edit}
              items={[
                ['Tuition Fee (per year)', money(rTuition)],
                ['Admission Fee (one-time)', money(rAdmission)],
                ['Scholarship Deduction', rScholarship ? `- ${money(rScholarship)}` : '', true],
                ['Hostel Room Type', data.admission?.hostelRoomType, true],
                ['Hostel Fee (per year)', money(rHostel), data.admission?.hostel !== 'Yes'],
                ['Transportation Fee (per year)', money(rTransport), data.admission?.transport !== 'Yes'],
                ['Estimated First-Year Total', money(rTotal)],
                ['Estimated Entire 4-Year Total', money(Math.max(0, (rTuition + rHostel + rTransport) * 4 + rAdmission - rScholarship))],
                ['Payment Preference', rPlan],
                ['Estimated Amount per Term', isTerm ? money(Math.ceil(rTotal / 2)) : '', true],
              ]}
            />
          )
        })()}
      </div>
      <div className="sa-review-col">
        <ReviewSection
          title="Academic Enrollment"
          icon={FiBookOpen}
          step={3}
          edit={edit}
          items={[
            ['Academic Year', data.academic?.academicYear],
            ['Joining College', data.admission?.college],
            ['Admission Type', data.academic?.admissionType],
            ['Quota', quota(data), true],
            ['Course', data.academic?.course],
            ['Course Code', data.academic?.courseCode, true],
            ['Department', data.academic?.department, true],
            ['Branch', data.academic?.branch],
            ['Branch Code', data.academic?.branchCode, true],
            ['Student Category', data.academic?.studentCategory, true],
            ['Regulation', data.academic?.regulation, true],
          ]}
        />
        <ReviewSection
          title="Previous Education"
          icon={FiFileText}
          step={4}
          edit={edit}
          items={[
            ['10th Board', data.previousEducation?.tenth?.board, true],
            ['10th School Name', data.previousEducation?.tenth?.institution, true],
            ['10th Roll Number', data.previousEducation?.tenth?.rollNumber, true],
            ['10th Passing Year', data.previousEducation?.tenth?.passingYear, true],
            ['10th Score Type', data.previousEducation?.tenth?.score ? data.previousEducation?.tenth?.scoreType : '', true],
            ['10th Score', data.previousEducation?.tenth?.score, true],
            ['Qualification', data.previousEducation?.intermediate?.qualification === 'Intermediate / 12th' ? '' : data.previousEducation?.intermediate?.qualification, true],
            ['Board / University', data.previousEducation?.intermediate?.board, true],
            ['College Name', data.previousEducation?.intermediate?.institution, true],
            ['Passing Year', data.previousEducation?.intermediate?.passingYear, true],
            ['Stream', data.previousEducation?.intermediate?.stream === 'Other' ? data.previousEducation?.intermediate?.streamOther : data.previousEducation?.intermediate?.stream, true],
            ['Score Type', data.previousEducation?.intermediate?.score ? data.previousEducation?.intermediate?.scoreType : '', true],
            ['Score', data.previousEducation?.intermediate?.score, true],
          ]}
        />
        <ReviewSection
          title="Admission & Services"
          icon={FiHome}
          step={5}
          edit={edit}
          items={[
            ['Registration Number', data.application?.registrationNumber || data.application?.number],
            ['Registration Date', data.application?.registrationDate || data.application?.date],
            ['Admission Number', data.application?.admissionNumber, true],
            ['Admission Date', data.application?.admissionDate, true],
            ['College', data.admission?.college],
            ['Batch', data.admission?.batch],
            ['Scholarship', data.admission?.scholarship],
            ['Hostel', data.admission?.hostel],
            ['Hostel Preference', data.admission?.hostelPreference, true],
            ['Room Type / Beds', data.admission?.hostelRoomType, true],
            ['Transportation', data.admission?.transport],
            ['Transport Route', data.admission?.transportRoute, true],
          ]}
        />
      </div>
    </div>
  )
}
function DocumentPreview({ document, studentId }) { return <StudentDocumentActions document={document} studentId={studentId} /> }
function DocumentReview({ data, edit, studentId }) {
  const documents = [
    ...DOCUMENTS.map(([key, label]) => ({ key, label, document: data.documents?.[key], ...(typeof data.documents?.[key] === 'object' ? data.documents[key] : {}) })),
    ...(data.documents?.otherCertificates || []).map(item => ({ key: item.id, label: 'Other Certificate', ...item }))
  ]
  return (
    <section className="sa-review-card sa-document-review-card">
      <header className="sa-review-card-header">
        <div className="sa-card-header-title">
          <span className="sa-card-header-icon"><FiShield /></span>
          <h3>Supporting Documents</h3>
          <span className="sa-card-count-badge">{documents.length}</span>
        </div>
        {edit && (
          <button type="button" className="sa-card-edit-btn" onClick={() => edit(3)}>
            <FiEdit2 size={12} /> Edit
          </button>
        )}
      </header>
      <div className="sa-doc-review-grid">
        {documents.map(document => {
          const ready = Boolean(document.uploaded || document.file || document.data || document.id)
          const status = documentStatus(document.document || document)
          return (
            <div key={document.key} className="sa-doc-review-item">
              <div className="sa-doc-item-icon">
                <FiFileText />
              </div>
              <div className="sa-doc-item-info">
                <strong className="sa-doc-item-name">{document.label}</strong>
              </div>
              <div className="sa-doc-item-status-action">
                <Badge value={status} />
                {ready && <DocumentPreview document={document} studentId={studentId} />}
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
function FullReview({ data, edit, studentId }) {
  return (
    <div className="sa-review-content-wrap">
      <CoreReview data={data} edit={edit} />
      <DocumentReview data={data} edit={edit} studentId={studentId} />
    </div>
  )
}
function PreviewHeader({ data }) {
  const marked = DOCUMENTS.filter(([key]) => {
    const doc = data.documents?.[key]
    const status = documentStatus(doc)
    return status && status !== 'Not Submitted'
  }).length
  const photoSrc = data.personal?.photo ? apiAssetUrl(data.personal.photo) : (data.personal?.photoUrl ? apiAssetUrl(data.personal.photoUrl) : '')
  return (
    <section className="sa-preview-header">
      <div className="sa-preview-photo">
        {photoSrc ? <img src={photoSrc} alt={studentName(data)} /> : <FiUser />}
      </div>
      <div className="sa-preview-identity">
        <span>Admission Preview</span>
        <h2>{studentName(data)}</h2>
        <p>{data.application?.registrationNumber || data.application?.number} | {display(data.academic?.course)} | {display(data.academic?.branch)}</p>
      </div>
      <dl>
        <div>
          <dt>Academic Year</dt>
          <dd>{display(data.academic?.academicYear)}</dd>
        </div>
        <div>
          <dt>Payment Preference</dt>
          <dd>{display(data.fees?.paymentPlan)}</dd>
        </div>
        <div>
          <dt>Document Status</dt>
          <dd>{marked}/{DOCUMENTS.length} marked</dd>
        </div>
      </dl>
    </section>
  )
}

function AdmissionForm() {
  const { canAction } = useScreenAccess()
  const submittedRecord = useRef(null)
  const creationUncertain = useRef(false)
  const [formLoading, setFormLoading] = useState(false)
  const [formLoadError, setFormLoadError] = useState('')
  const [formWarnings, setFormWarnings] = useState([])
  const [formAttempt, setFormAttempt] = useState(0)
  const [masterAttempt, setMasterAttempt] = useState(0)
  const [furthestStep, setFurthestStep] = useState(0)
  const { id } = useParams(); const navigate = useNavigate(); const validId = (id && id !== 'undefined' && id !== 'null') ? id : null;
  const location = useLocation()
  const resume = location.state?.admissionWizard
  const initialStep = same(resume?.admissionId, validId) && Number.isInteger(resume?.step)
    ? Math.max(0, Math.min(resume.step, STEPS.length - 1)) : 0
  const wizardContentRef = useRef(null)
  const previousStepRef = useRef(initialStep)
  const locallySavedAdmission = useRef(null)
  const [saveError, setSaveError] = useState('')
  const { selectedCollegeId: globalCollegeId, selectedCollege: globalCollege, selectedAcademicYearId: globalAcademicYearId, selectedAcademicYear: globalAcademicYear } = useAcademic();
  const [data, setData] = useState(() => {
    const init = empty();
    if (!validId) {
      init.previewEditedFields = {};
      if (globalCollegeId) {
        init.admission.collegeId = globalCollegeId;
        init.admission.college = globalCollege?.name || globalCollege?.collegeName || '';
      }
      if (globalAcademicYearId) {
        init.academic.academicYearId = globalAcademicYearId;
        init.academic.academicYear = globalAcademicYear?.name || globalAcademicYear?.academicYearName || '';
      }
    }
    return init;
  });
  const [recordIds, setRecordIds] = useState({ admissionId: validId, studentId: null, academicId: null })
  const [step, setStep] = useState(initialStep); const [errors, setErrors] = useToastState({}, 'error'); const [touched, setTouched] = useState({}); const [declared, setDeclared] = useState(false); const [, setToast] = useToastState(null, 'success'); const [pinStatus, setPinStatus] = useState({}); const [confirmSubmit, setConfirmSubmit] = useState(false); const [confirmCancel, setConfirmCancel] = useState(false); const [submitting, setSubmitting] = useState(false); const [savingDraft, setSavingDraft] = useState(false); const [savingStep, setSavingStep] = useState(false); const [feeState, setFeeState] = useState({ loading: false, loaded: false, error: '' })
  useEffect(() => {
    if (previousStepRef.current === step) return
    previousStepRef.current = step
    wizardContentRef.current?.focus({ preventScroll: true })
  }, [step])
  const markTouched = (path) => setTouched(current => ({ ...current, [path]: true }))
  const [masters,setMasters]=useState({years:[],courses:[],branches:[],colleges:[],semesters:[]})
  const [courseBranches, setCourseBranches] = useState([])
  const [branchLoading, setBranchLoading] = useState(false)
  const [branchLoadError, setBranchLoadError] = useState('')
  const dataRef = useRef(data)
  useEffect(() => { dataRef.current = data }, [data])
  useEffect(() => { if (!data.application.date) setData(current => ({ ...current, application: { ...current.application, date: new Date().toISOString().slice(0, 10) } })) }, [data.application.date])
  useEffect(() => {
    if (validId) return
    setData(current => {
      let next = current;
      if (globalCollegeId && !same(next.admission?.collegeId, globalCollegeId)) {
        next = setPath(next, 'admission.collegeId', globalCollegeId);
        next = setPath(next, 'admission.college', globalCollege?.name || globalCollege?.collegeName || next.admission?.college || '');
      }
      if (globalAcademicYearId && !same(next.academic?.academicYearId, globalAcademicYearId)) {
        next = setPath(next, 'academic.academicYearId', globalAcademicYearId);
        next = setPath(next, 'academic.academicYear', globalAcademicYear?.name || globalAcademicYear?.academicYearName || next.academic?.academicYear || '');
      }
      if (!same(next.admission?.collegeId,current.admission?.collegeId) || !same(next.academic?.academicYearId,current.academic?.academicYearId)) next = { ...next, academic: { ...next.academic, departmentId:'', department:'', courseId:'',course:'',courseCode:'',branchId:'',branch:'',branchCode:'',semesterId:'',semester:'',sectionId:'',section:'' }, fees: empty().fees };
      return next;
    });
  }, [validId, globalCollegeId, globalCollege, globalAcademicYearId, globalAcademicYear, data.admission.collegeId, data.academic.academicYearId]);
  useEffect(() => {
    if (!masters.colleges.length) return;
    const college = masters.colleges.find(item =>
      (data.admission.collegeId && same(item.collegeId ?? item.id, data.admission.collegeId)) ||
      (data.admission.college && String(item.collegeName ?? item.name ?? item.institutionName ?? '').trim().toLowerCase() === String(data.admission.college).trim().toLowerCase())
    );
    if (!college) return;
    const collegeId = college.collegeId ?? college.id;
    const collegeName = college.collegeName ?? college.name ?? college.institutionName ?? '';
    if ((!data.admission.collegeId && collegeId) || (!data.admission.college && collegeName)) {
      setData(current => ({ ...current, admission: { ...current.admission, collegeId: current.admission.collegeId || collegeId, college: current.admission.college || collegeName } }));
    }
  }, [masters.colleges, data.admission.collegeId, data.admission.college]);
  useEffect(() => {
    if (data.admission.hostel !== 'Yes') return
    const preference = data.personal.gender === 'Male' ? 'Boys Hostel' : data.personal.gender === 'Female' ? 'Girls Hostel' : ''
    if (preference && data.admission.hostelPreference !== preference) setData(current => ({ ...current, admission: { ...current.admission, hostelPreference: preference } }))
  }, [data.admission.hostel, data.admission.hostelPreference, data.personal.gender])
  const notify = (message, tone = 'success') => setToast({ message, tone })
  useEffect(()=>{let active=true;Promise.all([academicYearApi.getAll(),courseApi.getAll(),branchApi.getAll(),getColleges(),getSemesters()]).then(([years,courses,branches,collegeResponse,semesterResponse])=>{if(!active)return;const list=response=>{let value=response;for(let depth=0;depth<5&&value&&typeof value==='object';depth+=1){if(Array.isArray(value))return value;const rows=value.items??value.content??value.results??value.records;if(Array.isArray(rows))return rows;value=value.data}return[]};const operationalYears = getOperationalAcademicYearOptions(years);setMasters({loaded: true, years: operationalYears, courses, branches, colleges:list(collegeResponse), semesters:list(semesterResponse)})}).catch(error=>{ if(active) {setMasters(current=>({...current,loaded:false,error:error.message||'Unable to load admission selections.'}));notify(error.message||'Unable to load admission selections.','error')} });return()=>{active=false}},[masterAttempt, globalCollegeId])
  useEffect(() => {
    const courseId = data.academic.courseId
    let active = true
    setCourseBranches([])
    setBranchLoadError('')
    if (!courseId) {
      setBranchLoading(false)
      return () => { active = false }
    }

    setBranchLoading(true)
    branchApi.getByCourse(courseId)
      .then(rows => {
        if (active) setCourseBranches(Array.isArray(rows) ? rows : [])
      })
      .catch(error => {
        if (active) setBranchLoadError(error.message || 'Unable to load branches for this course.')
      })
      .finally(() => {
        if (active) setBranchLoading(false)
      })

    return () => { active = false }
  }, [data.academic.courseId])
  useEffect(() => {
    if (step !== 4) return
    let active = true
    setFeeState({ loading: Boolean(recordIds.admissionId), loaded: false, error: '' })
    if (recordIds.admissionId) {
      Promise.allSettled([
        studentFeeApi.getSummary(recordIds.admissionId),
        studentFeeApi.getStructure(recordIds.admissionId)
      ]).then(results => {
        if (!active) return
        const failed = results.find(result => result.status === 'rejected')
        setFeeState({ loading: false, loaded: true, error: failed ? failed.reason?.message || 'Fee information unavailable.' : '' })
        if (failed) return
        const summaryResponse = results[0].status === 'fulfilled' ? results[0].value : null
        const structureResponse = results[1].status === 'fulfilled' ? results[1].value : null
        const summary = resolveFeeSummary(dataRef.current, summaryResponse, structureResponse)
        if (summary) {
          setData(current => ({
            ...current,
            fees: {
              ...current.fees,
              ...summary,
              structureId: summary.feeStructureId ?? summary.structureId ?? current.fees.structureId ?? '',
              tuitionFee: String(summary.tuitionFee ?? current.fees.tuitionFee ?? 0),
              admissionFee: String(summary.admissionFee ?? current.fees.admissionFee ?? 0),
              paymentPlan: current.fees.paymentPlan || summary.paymentPlan || 'Full Payment',
            }
          }))
        }
      }).catch(() => {})
    }
    return () => { active = false }
  }, [step, recordIds.admissionId])
  useEffect(() => { const start=Number(String(data.academic.academicYear).slice(0,4)); const batch=start&&data.academic.course?`${start}-${start+4}`:''; if(data.admission.batch!==batch)queueMicrotask(()=>setData(current=>({...current,admission:{...current.admission,batch}}))) }, [data.academic.academicYear,data.academic.course,data.admission.batch])
  useEffect(() => { const n=Number(String(data.academic.semester).match(/\d+/)?.[0]||0), year=n?`${Math.ceil(n/2)}${['th','st','nd','rd'][Math.ceil(n/2)]||'th'} Year`:''; if(data.academic.yearOfStudy!==year)queueMicrotask(()=>setData(current=>({...current,academic:{...current.academic,yearOfStudy:year}}))) }, [data.academic.semester,data.academic.yearOfStudy])
  useEffect(() => { queueMicrotask(()=>setData(current => { let next=current; for(const key of ['tenth','intermediate']){const item=current.previousEducation[key],max=item.scoreType==='CGPA'?10:100;if(text(item.score)&&Number(item.score)>max)next=setPath(next,`previousEducation.${key}.score`,'')}return next })) }, [data.previousEducation.tenth.scoreType,data.previousEducation.intermediate.scoreType])
  useEffect(() => {
    if (!validId || same(locallySavedAdmission.current, validId)) return
    let active = true
    setFormLoading(true); setFormLoadError('')
    studentAdmissionApi.getById(validId).then(async row => {
      const loadedIds = idsFromApi(row, validId), admissionId = loadedIds.admissionId, studentId = loadedIds.studentId
      const sections = await Promise.allSettled([
        studentAcademicDetailsApi.get(admissionId),
        studentPreviousEducationApi.get(admissionId),
        studentId ? studentParentApi.get(studentId) : Promise.resolve(null),
        studentId ? studentDocumentApi.getAll(studentId) : Promise.resolve([]),
        studentFeeApi.getSummary(admissionId),
        studentFeeApi.getStructure(admissionId)
      ])
      if (!active) return
      setFormWarnings(sections.flatMap((result,index) => result.status === 'rejected' ? [(['Academic details','Previous education','Parent details','Documents','Fee summary','Fee structure'][index]) + ': ' + (result.reason?.message || 'Unable to load saved information.')] : []))
      const loaded = admissionFromApi({
        ...row,
        academicDetails: sections[0].status === 'fulfilled' && sections[0].value ? sections[0].value : row.academicDetails,
        previousEducation: sections[1].status === 'fulfilled' && sections[1].value ? sections[1].value : row.previousEducation,
        parents: sections[2].status === 'fulfilled' && sections[2].value ? sections[2].value : row.parents,
        documents: sections[3].status === 'fulfilled' ? mergeDocumentStatuses(row.documents, documentsFromApi(sections[3].value)) : row.documents
      })
      const feeSummary = resolveFeeSummary(loaded, sections[4].status === 'fulfilled' ? sections[4].value : row.feeSummary, sections[5].status === 'fulfilled' ? sections[5].value : null)
      const baseLoaded = feeSummary ? { ...loaded, fees: { ...loaded.fees, ...feeSummary } } : loaded

      let localDraft = null
      try {
        const stored = localStorage.getItem(`pirnav-draft-admission-${admissionId}`)
        if (stored) localDraft = JSON.parse(stored)
      } catch { /* ignore */ }

      const finalLoaded = localDraft
        ? normalizeCanonicalStudent({
            ...baseLoaded,
            ...localDraft,
            application: { ...baseLoaded.application, ...(localDraft.application || {}) },
            personal: { ...baseLoaded.personal, ...(localDraft.personal || {}) },
            contact: { ...baseLoaded.contact, ...(localDraft.contact || {}) },
            parents: { ...baseLoaded.parents, ...(localDraft.parents || {}) },
            academic: { ...baseLoaded.academic, ...(localDraft.academic || {}) },
            previousEducation: { ...baseLoaded.previousEducation, ...(localDraft.previousEducation || {}) },
            admission: { ...baseLoaded.admission, ...(localDraft.admission || {}) },
            fees: { ...baseLoaded.fees, ...(localDraft.fees || {}) },
            documents: { ...baseLoaded.documents, ...(localDraft.documents || {}) },
          })
        : baseLoaded

      // Browser drafts may predate a corrected enrollment or a changed global
      // year. Restore the server's academic mapping as one consistent unit.
      setData({
        ...finalLoaded,
        academic: baseLoaded.academic,
        fees: { ...baseLoaded.fees, paymentPlan: localDraft?.fees?.paymentPlan || baseLoaded.fees.paymentPlan },
        admission: { ...finalLoaded.admission, collegeId: baseLoaded.admission.collegeId, college: baseLoaded.admission.college },
        previewEditedFields: localDraft?.previewEditedFields ?? row.formData?.previewEditedFields,
      })
      setRecordIds(loadedIds)
    }).catch(error => { if(active) { setFormLoadError(error.message || 'Unable to load this admission.'); notify(error.message || 'Unable to load this admission.', 'error') } }).finally(() => { if(active) setFormLoading(false) })
    return () => { active = false }
  }, [validId, formAttempt])
  const update = (path, value) => {
    setSaveError('')
    setData(current => {
      let next = resetAdmissionAcademicDependents(setPath(current, path, value), current, path);
      if (path === 'academic.semesterId') {
        const semester = masters.semesters.find(item => same(item.semesterId ?? item.id, value))
        next.academic = { ...next.academic, semester: semester?.semesterName ?? semester?.name ?? '', sectionId: '', section: '', requiresSemesterSelection: Boolean(value || current.academic.semesterId || current.academic.requiresSemesterSelection) }
      }
      if (current.previewEditedFields) next.previewEditedFields = { ...current.previewEditedFields, [path]: true };
      if (path === 'personal.gender') {
        if (next.admission.hostel === 'Yes') {
          next.admission.hostelPreference = (value === 'Male' ? 'Boys Hostel' : value === 'Female' ? 'Girls Hostel' : next.admission.hostelPreference || 'Boys Hostel');
        }
      }
      if (path === 'contact.sameAddress') {
        if (value) {
          next.contact.permanentAddress = { ...next.contact.currentAddress };
        } else {
          next.contact.permanentAddress = blankAddress();
        }
      }
      if (path.startsWith('contact.currentAddress.') && next.contact.sameAddress) next.contact.permanentAddress = { ...next.contact.currentAddress };
      if (path === 'academic.course' || path === 'academic.courseId') Object.assign(next.academic, { branch: '', branchId: '', branchCode: '' });
      if (path === 'academic.admissionType' && value !== 'Lateral Entry') {
        next.academic.quota = '';
        next.academic.quotaOther = '';
      }
      if (path === 'academic.quota' && value !== 'Other') next.academic.quotaOther = '';
      if (path === 'parents.guardian.relationship' && value !== 'Other') next.parents.guardian.relationshipOther = '';
      if (path === 'previousEducation.intermediate.stream' && value !== 'Other') next.previousEducation.intermediate.streamOther = '';
      if (path === 'admission.scholarship' && value === 'No') { next.admission.scholarshipType = ''; next.fees.scholarshipAmount = '' }
      if (path === 'admission.hostel') {
        if (value === 'No') {
          next.admission.hostelPreference = '';
          next.admission.hostelRoomType = '';
          next.fees.hostelFee = '';
        } else if (value === 'Yes') {
          next.admission.hostelPreference = (current.personal?.gender === 'Male' ? 'Boys Hostel' : current.personal?.gender === 'Female' ? 'Girls Hostel' : 'Boys Hostel');
          if (next.admission.hostelRoomType) {
            next.fees.hostelFee = String(getResolvedHostelFee(next.admission, next.fees, next.academic) || '');
          }
        }
      }
      if (path === 'admission.hostelRoomType' || path === 'admission.hostelPreference') {
        next.fees.hostelFee = String(getResolvedHostelFee(next.admission, next.fees, next.academic) || '');
      }
      if (path === 'admission.transport') {
        if (value === 'No') {
          next.admission.transportRoute = '';
          next.fees.transportFee = '';
        } else if (next.admission.transportRoute) {
          next.fees.transportFee = String(getResolvedTransportFee(next.admission, next.fees, next.academic) || '');
        }
      }
      if (path === 'admission.transportRoute') {
        next.fees.transportFee = String(getResolvedTransportFee(next.admission, next.fees, next.academic) || '');
      }
      const matched = findMatchingFeeStructure(next.academic, next.admission, next.fees?.structureId);
      const tuition = Number(next.fees.tuitionFee) > 0 ? Number(next.fees.tuitionFee) : (matched ? Number(matched.amount || 0) : 0);
      const admission = Number(next.fees.admissionFee !== undefined && next.fees.admissionFee !== '' ? next.fees.admissionFee : 0);
      const hostel = getResolvedHostelFee(next.admission, next.fees, next.academic);
      const transport = getResolvedTransportFee(next.admission, next.fees, next.academic);
      const scholarship = Number(next.fees.scholarshipAmount || 0);
      const total = Math.max(0, tuition + admission + hostel + transport - scholarship);
      next.fees.tuitionFee = String(tuition);
      next.fees.admissionFee = String(admission);
      next.fees.hostelFee = String(hostel);
      next.fees.transportFee = String(transport);
      if (path.startsWith('fees.') || path.startsWith('admission.hostel') || path.startsWith('admission.transport')) next.fees.totalFee = String(total);
      return next;
    });
    setErrors(current => ({ ...current, [path]: '', ...(path === 'academic.semesterId' ? { 'academic.semester': '' } : {}) }));
  }
  const currentPincode = data.contact.currentAddress.pincode, permanentPincode = data.contact.permanentAddress.pincode, sameAddress = data.contact.sameAddress
  const lastPinLookupRef = useRef({ current: '', permanent: '' })
  useEffect(() => {
    const targets = [['contact.currentAddress','current',currentPincode], ...(!sameAddress ? [['contact.permanentAddress','permanent',permanentPincode]] : [])]
    let active = true
    const timer = window.setTimeout(async () => {
      await Promise.all(targets.map(async ([prefix, key, pin]) => {
        if (!/^\d{6}$/.test(pin)) { setPinStatus(current => ({ ...current, [key]: '' })); lastPinLookupRef.current[key] = ''; return }
        if (lastPinLookupRef.current[key] === pin) return
        lastPinLookupRef.current[key] = pin
        setPinStatus(current => ({ ...current, [key]: 'Fetching location...' }))
        try {
          const location = await lookupIndianPincode(pin)
          if (!active) return
          setData(current => {
            if (read(current, `${prefix}.pincode`) !== pin) return current
            let next = current
            if (location.town) next = setPath(next, `${prefix}.town`, location.town)
            else if (location.city && !read(current, `${prefix}.town`)) next = setPath(next, `${prefix}.town`, location.city)
            if (location.city) next = setPath(next, `${prefix}.city`, location.city)
            if (location.district) next = setPath(next, `${prefix}.district`, location.district)
            if (location.state) next = setPath(next, `${prefix}.state`, location.state)
            next = setPath(next, `${prefix}.country`, location.country || 'India')
            if (prefix === 'contact.currentAddress' && next.contact.sameAddress) next.contact.permanentAddress = { ...next.contact.currentAddress }
            return next
          })
          setErrors(current => {
            const copy = { ...current }
            delete copy[`${prefix}.town`]
            delete copy[`${prefix}.city`]
            delete copy[`${prefix}.district`]
            delete copy[`${prefix}.state`]
            delete copy[`${prefix}.pincode`]
            return copy
          })
          setPinStatus(current => ({ ...current, [key]: 'Address details filled' }))
        } catch (error) {
          if (active) setPinStatus(current => ({ ...current, [key]: error.message || 'PIN code not found - enter manually' }))
        }
      }))
    }, 350)
    return () => { active = false; window.clearTimeout(timer) }
  }, [currentPincode, permanentPincode, sameAddress])
  // An existing admission keeps its enrollment year, even when that year is
  // absent from the active-year list. Changing it would invalidate its semester.

  useEffect(() => {
    if (data.academic.admissionType === 'Lateral Entry') return
    if (!data.academic.quota && !data.academic.quotaOther) return
    setData(current => ({ ...current, academic: { ...current.academic, quota: '', quotaOther: '' } }))
  }, [data.academic.admissionType, data.academic.quota, data.academic.quotaOther])

  const semesterOptions = admissionSemesterOptions(masters.semesters, data.academic, data.admission.collegeId)
  const allErrors = validate(data)
  const semesterError = masters.loaded ? admissionSemesterError(data.academic, semesterOptions) : ''
  if (semesterError) allErrors['academic.semester'] = semesterError
  const getFieldError = (path) => errors[path] || (touched[path] ? allErrors[path] : (read(data, path) && allErrors[path] ? allErrors[path] : ''))
  const field = (path,label,options,type,readOnly,placeholder,disabled) => <Field {...{ data,path,label,options,type,readOnly,placeholder,disabled,update,markTouched }} error={getFieldError(path)} />
  const effectiveAddressErrors = Object.fromEntries(
    Object.keys(allErrors).map(path => [path, getFieldError(path)])
  )
  const courseCodeFallback = (name) => {
    if (!name) return ''
    const clean = String(name).trim()
    if (/bachelor of technology|^b\.?tech/i.test(clean)) return 'B.TECH'
    if (/master of technology|^m\.?tech/i.test(clean)) return 'M.TECH'
    if (/master of business administration|^mba/i.test(clean)) return 'MBA'
    if (/bachelor of pharmacy|^b\.?pharm/i.test(clean)) return 'B.PHARM'
    if (/master of computer applications|^mca/i.test(clean)) return 'MCA'
    return clean.split(/\s+/).map(w => w[0]).join('').toUpperCase()
  }

  const branchCodeFallback = (name) => {
    if (!name) return ''
    const clean = String(name).trim()
    if (/electrical and electronics/i.test(clean) || /^eee/i.test(clean)) return 'EEE'
    if (/electronics and communication/i.test(clean) || /^ece/i.test(clean)) return 'ECE'
    if (/computer science and engineering|computer science/i.test(clean) || /^cse/i.test(clean)) return 'CSE'
    if (/mechanical/i.test(clean) || /^mech/i.test(clean)) return 'MECH'
    if (/civil/i.test(clean)) return 'CIVIL'
    if (/information technology/i.test(clean) || /^it$/i.test(clean)) return 'IT'
    if (/artificial intelligence and machine learning|ai & ml|aiml/i.test(clean)) return 'AIML'
    if (/data science/i.test(clean) || /^ds$/i.test(clean)) return 'DS'
    if (/cyber security/i.test(clean) || /^cs$/i.test(clean)) return 'CS'
    return clean.split(/\s+/).filter(w => !['and', '&', 'of', 'in'].includes(w.toLowerCase())).map(w => w[0]).join('').toUpperCase()
  }

  const isItemActive = (item) => {
    if (!item) return false
    if (item.status !== undefined) {
      if (typeof item.status === 'boolean') return item.status
      if (typeof item.status === 'number') return item.status === 1
      const s = String(item.status).trim().toLowerCase()
      return s === 'active' || s === '1' || s === 'true' || s === 'current'
    }
    if (item.isActive !== undefined) return Boolean(item.isActive)
    return true
  }

  const academicOption=(item,idKeys,nameKeys)=>({id:idKeys.map(key=>read(item,key)).find(value=>value!=null&&value!==''),name:nameKeys.map(key=>read(item,key)).find(Boolean)||''})
  const yearOptions=masters.years.filter(isItemActive).map(item=>academicOption(item,['academicYearId','id'],['academicYearName','name'])).filter(item=>item.id)
  const selectedCollegeId = data.admission.collegeId
  const departmentOptions = [...new Map(masters.courses.filter(item => isItemActive(item) && (!item.collegeId || same(item.collegeId,selectedCollegeId))).filter(item => item.departmentId).map(item => [String(item.departmentId), { id:item.departmentId,name:item.departmentName || item.department?.departmentName || item.department?.name || String(item.departmentId) }])).values()]
  const courseOptions=masters.courses.filter(item => !data.academic.departmentId || same(item.departmentId, data.academic.departmentId)).filter(isItemActive).map(item=>{
    const opt = academicOption(item,['courseId','id'],['courseName','name'])
    const code = item.courseCode || item.code || item.shortName || item.courseShortName || courseCodeFallback(opt.name)
    return { ...opt, code, collegeId:item.collegeId??item.college?.collegeId??item.college?.id }
  }).filter(item=>item.id&&(!selectedCollegeId||!item.collegeId||same(item.collegeId,selectedCollegeId)))
  const collegeCourseIds = new Set(courseOptions.map(item => String(item.id)))
  const courseMasterBranches = masters.branches.filter(item => !data.academic.courseId || !item.courseId || same(item.courseId, data.academic.courseId))
  const branchSource = courseBranches.length ? courseBranches : courseMasterBranches
  const branchOptions=branchSource.filter(isItemActive).map(item=>{
    const opt = academicOption(item,['branchId','id'],['branchName','name','branchShortName','shortName'])
    const code = item.branchCode || item.code || item.shortName || item.branchShortName || branchCodeFallback(opt.name)
    return { ...opt, code, courseId:item.courseId??item.course?.courseId??item.course?.id, collegeId:item.collegeId??item.college?.collegeId??item.college?.id }
  }).filter(item=>item.id&&(!selectedCollegeId||same(item.collegeId,selectedCollegeId)||collegeCourseIds.has(String(item.courseId)))&&(data.academic.courseId&&same(item.courseId,data.academic.courseId)))
  const collegeOptions=masters.colleges.filter(isItemActive).map(item=>({id:item.collegeId??item.id,name:item.collegeName??item.name??item.institutionName??''})).filter(item=>item.id&&item.name)

  const roomTypeOptions = useMemo(() => {
    const list = []
    const seen = new Set()
    const addRoomType = value => {
      const name = normalizeHostelRoomType(value)
      const key = name.toLowerCase()
      if (name && !seen.has(key)) {
        seen.add(key)
        list.push(name)
      }
    }
    try {
      const hostelPlans = readHostelStructures(selectedCollegeId)
      if (Array.isArray(hostelPlans)) {
        hostelPlans.forEach(p => {
          if (Array.isArray(p.roomPricing)) {
            p.roomPricing.forEach(r => addRoomType(r.roomType))
          }
          addRoomType(p.roomType)
        })
      }
    } catch {}
    Object.keys(HOSTEL_FEES).forEach(addRoomType)
    addRoomType(data.admission.hostelRoomType)
    return list
  }, [selectedCollegeId, data.admission.hostelRoomType])

  useEffect(() => {
    const roomType = data.admission.hostelRoomType
    const normalized = normalizeHostelRoomType(roomType)
    if (roomType && normalized !== roomType) {
      setData(current => ({ ...current, admission: { ...current.admission, hostelRoomType: normalized } }))
    }
  }, [data.admission.hostelRoomType])

  const transportRouteOptions = useMemo(() => {
    const list = []
    try {
      const transportPlans = readTransportStructures(selectedCollegeId)
      if (Array.isArray(transportPlans)) {
        transportPlans.forEach(p => {
          const rName = String(p.route || p.routeCode || p.name || '').trim()
          if (rName && !list.includes(rName)) list.push(rName)
        })
      }
    } catch {}
    return [...new Set([...list, ...Object.keys(TRANSPORT_FEES)])]
  }, [selectedCollegeId])

  useEffect(() => {
    const targetCourse = courseOptions.find(c => same(c.id, data.academic.courseId) || same(c.name, data.academic.course))
    const expectedCourseCode = targetCourse?.code || courseCodeFallback(data.academic.course)
    const targetBranch = branchOptions.find(b => same(b.id, data.academic.branchId) || same(b.name, data.academic.branch))
    const expectedBranchCode = targetBranch?.code || branchCodeFallback(data.academic.branch)

    if (data.academic.course && expectedCourseCode && (!data.academic.courseCode || data.academic.courseCode !== expectedCourseCode)) {
      setData(current => ({
        ...current,
        academic: { ...current.academic, courseCode: expectedCourseCode }
      }))
    }
    if (data.academic.branch && expectedBranchCode && (!data.academic.branchCode || data.academic.branchCode !== expectedBranchCode)) {
      setData(current => ({
        ...current,
        academic: { ...current.academic, branchCode: expectedBranchCode }
      }))
    }
  }, [data.academic.courseId, data.academic.course, data.academic.branchId, data.academic.branch, courseOptions, branchOptions])

  const masterField=(namePath,idPath,label,options,disabled=false,resets=[])=>{
    const id=`sa-${idPath.replaceAll('.','-')}`;
    const masterError = errors[namePath] || ((touched[namePath] || touched[idPath] || read(data, idPath)) ? allErrors[namePath] : '');
    const branchField = idPath === 'academic.branchId'
    const placeholder = disabled ? 'Select Course first' : branchField && branchLoading ? 'Loading branches...' : branchField && !options.length ? branchLoadError ? 'Branches unavailable' : 'No branches configured' : `Select ${label}`
    return <label className={`sa-field ${masterError?'invalid':''}`} htmlFor={id}><span>{label}<b> *</b></span><ProjectSelect id={id} value={read(data,idPath)||''} disabled={disabled || (branchField && branchLoading)} onChange={event=>{setSaveError('');markTouched(namePath);markTouched(idPath);const option=options.find(item=>same(item.id,event.target.value));setData(current=>{let next=setPath(current,idPath,event.target.value);if(current.previewEditedFields)next.previewEditedFields={...current.previewEditedFields,[idPath]:true,[namePath]:true};next=setPath(next,namePath,option?.name||'');if(idPath==='academic.courseId')next=setPath(next,'academic.courseCode',option?.code||courseCodeFallback(option?.name));if(idPath==='academic.branchId')next=setPath(next,'academic.branchCode',option?.code||branchCodeFallback(option?.name));resets.forEach(([resetId,resetName])=>{next=setPath(next,resetId,'');next=setPath(next,resetName,'')});return resetAdmissionAcademicDependents(next,current,idPath)});setErrors(current=>({...current,[namePath]:''}))}} onBlur={() => { markTouched(namePath); markTouched(idPath) }}><option value="">{placeholder}</option>{options.map(option=><option key={option.id} value={option.id}>{option.name}{option.code ? ` (${option.code})` : ''}</option>)}</ProjectSelect>{branchField && !branchLoading && !options.length && <small role={branchLoadError?'alert':'status'}>{branchLoadError || 'Ask an administrator to add an active branch under this course.'}</small>}{masterError&&<small role="alert">{masterError}</small>}</label>
  }
  const screens = [
    <Section key="identity" title="Student Identity" icon={FiUser} hint="Core identity and government identification details"><PhotoUpload data={data} update={update} notify={notify} />{field('personal.firstName','First Name')}{field('personal.middleName','Middle Name')}{field('personal.lastName','Last Name')}{field('personal.gender','Gender',['Female','Male','Non-binary'])}{field('personal.dob','Date of Birth',null,'date')}{field('personal.bloodGroup','Blood Group',['A+','A-','B+','B-','AB+','AB-','O+','O-'])}{field('personal.nationality','Nationality')}{field('personal.aadhaar','Aadhaar Number')}</Section>,
    <><Section title="Contact Information" icon={FiPhone}>{field('contact.mobile','Student Mobile')}{field('contact.alternateMobile','Alternate Mobile')}{field('contact.email','Student Email',null,'email')}{field('contact.alternateEmail','Alternate Email',null,'email')}</Section><Section title="Current Address" icon={FiHome}><AddressFields data={data} prefix="contact.currentAddress" update={update} errors={effectiveAddressErrors} markTouched={markTouched} />{pinStatus.current && <p className={`sa-pincode-status ${pinStatus.current.includes('filled') ? 'success' : ''}`}>{pinStatus.current}</p>}</Section><Section title="Permanent Address" icon={FiHome} action={<label className="sa-same-addr-check" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.78rem', fontWeight: 650, color: 'var(--brand, #125AA8)' }}><input type="checkbox" checked={Boolean(data.contact.sameAddress)} onChange={event => update('contact.sameAddress', event.target.checked)} style={{ width: '15px', height: '15px', accentColor: 'var(--brand, #125AA8)', cursor: 'pointer' }} /><span>Same as current address</span></label>}>{!data.contact.sameAddress && <><AddressFields data={data} prefix="contact.permanentAddress" update={update} errors={effectiveAddressErrors} markTouched={markTouched} />{pinStatus.permanent && <p className={`sa-pincode-status ${pinStatus.permanent.includes('filled') ? 'success' : ''}`}>{pinStatus.permanent}</p>}</>}</Section></>,
    <><Section title="Father Details" icon={FiUsers} hint="Optional parent or guardian contact information.">{field('parents.father.name','Father Name')}{field('parents.father.mobile','Father Mobile')}{field('parents.father.email','Father Email',null,'email')}{field('parents.father.occupation','Father Occupation')}{field('parents.father.qualification','Father Qualification')}{field('parents.father.income','Father Annual Income',null,'number')}</Section><Section title="Mother Details" icon={FiUsers}>{field('parents.mother.name','Mother Name')}{field('parents.mother.mobile','Mother Mobile')}{field('parents.mother.email','Mother Email',null,'email')}{field('parents.mother.occupation','Mother Occupation')}{field('parents.mother.qualification','Mother Qualification')}{field('parents.mother.income','Mother Annual Income',null,'number')}</Section><Section title="Guardian Details" icon={FiUsers}>{field('parents.guardian.name','Guardian Name')}{field('parents.guardian.relationship','Relationship',['Father','Mother','Guardian','Other'])}{data.parents.guardian.relationship === 'Other' && field('parents.guardian.relationshipOther','Specify Relationship')}{field('parents.guardian.mobile','Guardian Mobile')}{field('parents.guardian.email','Guardian Email',null,'email')}{field('parents.guardian.occupation','Guardian Occupation')}{field('parents.guardian.qualification','Guardian Qualification')}{field('parents.guardian.income','Guardian Annual Income',null,'number')}{field('parents.primaryContact','Primary Contact',['Father','Mother','Guardian'])}{field('parents.emergencyMobile','Emergency Contact Mobile')}</Section></>,
    <Section key="academic" title="Academic Enrollment" icon={FiBookOpen} hint="Review the working college and academic year, then select the matching academic placement.">{field('academic.academicYear','Academic Year',null,'text',true)}{field('admission.college','Joining College',null,'text',true)}{field('academic.admissionType','Admission Type',ADMISSION_TYPES)}{data.academic.admissionType === 'Lateral Entry' && <>{field('academic.quota','Admission Quota',ADMISSION_QUOTAS)}{data.academic.quota === 'Other' && field('academic.quotaOther','Specify Admission Quota')}</>}{departmentOptions.length > 0 && masterField('academic.department','academic.departmentId','Department',departmentOptions,!selectedCollegeId,[['academic.courseId','academic.course'],['academic.branchId','academic.branch']])}{masterField('academic.course','academic.courseId','Course',courseOptions,!selectedCollegeId,[['academic.branchId','academic.branch']])}{field('academic.courseCode','Course Code',null,'text',true)}{masterField('academic.branch','academic.branchId','Branch',branchOptions,!data.academic.courseId)}{field('academic.branchCode','Branch Code',null,'text',true)}<label className={`sa-field ${getFieldError('academic.semester') ? 'invalid' : ''}`}><span>Semester{data.academic.requiresSemesterSelection && <b> *</b>}</span><ProjectSelect value={data.academic.semesterId || ''} disabled={!masters.loaded || !data.academic.courseId || !data.academic.branchId} onChange={event => update('academic.semesterId', event.target.value)}><option value="">Select Semester</option>{data.academic.semesterId && !semesterOptions.some(item => same(item.id, data.academic.semesterId)) && <option value={data.academic.semesterId} disabled>{data.academic.semester || 'Saved semester'} (unavailable)</option>}{semesterOptions.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</ProjectSelect>{getFieldError('academic.semester') && <small role="alert">{getFieldError('academic.semester')}</small>}{masters.loaded && data.academic.branchId && !semesterOptions.length && <small>No matching semesters are configured. Ask an administrator to configure a semester for this course, branch and academic year.</small>}</label>{field('academic.studentCategory','Student Category',['General','SC','ST','BC','EWS','Other'])}{field('academic.regulation','Regulation')}</Section>,
    <><Section title="10th / SSC" icon={FiBookOpen} hint="Enter only the essential school details.">{field('previousEducation.tenth.board','Board')}{field('previousEducation.tenth.institution','School Name')}{field('previousEducation.tenth.passingYear','Year of Passing')}{field('previousEducation.tenth.score','Percentage (0-100)',null,'number')}</Section><Section title="Intermediate / Diploma" icon={FiBookOpen} hint="Enter only the essential qualifying-education details.">{field('previousEducation.intermediate.board','Board / University')}{field('previousEducation.intermediate.institution','College Name')}{field('previousEducation.intermediate.passingYear','Year of Passing')}{field('previousEducation.intermediate.stream','Stream',['MPC','Other'])}{data.previousEducation.intermediate.stream === 'Other' && field('previousEducation.intermediate.streamOther','Specify Stream')}{field('previousEducation.intermediate.score','Percentage (0-100)',null,'number')}</Section></>,
    <><Section title="Application Information" icon={FiFileText} hint="Registration details.">{field('application.number','Registration Number',null,'text',true)}{field('application.date','Registration Date',null,'date',false)}{field('admission.batch','Batch')}</Section><Section title="Student Services" icon={FiHome}>{field('admission.hostel','Hostel Required',['No','Yes'])}{data.admission.hostel === 'Yes' && <>{field('admission.hostelPreference','Hostel Preference',data.personal.gender === 'Male' ? ['Boys Hostel'] : data.personal.gender === 'Female' ? ['Girls Hostel'] : ['Boys Hostel','Girls Hostel'],undefined,data.personal.gender === 'Male' || data.personal.gender === 'Female')}{field('admission.hostelRoomType','Room Type / Beds',roomTypeOptions)}</>}{field('admission.transport','Transportation Required',['No','Yes'])}{data.admission.transport === 'Yes' && field('admission.transportRoute','Transport Route',transportRouteOptions)}</Section></>,
    <div key="fees"><ApplicantFeeStructure data={data} update={update} error={errors['fees.paymentPlan']} /></div>,
    <DocumentsUpload key="documents" data={data} update={update} errors={errors} notify={notify} />,
  ]
  const wizardScreens = [<>{screens[0]}{screens[1]}</>, <>{masters.error && <div role="alert"><p>{masters.error}</p><Button onClick={() => setMasterAttempt(current => current + 1)}>Retry academic selections</Button></div>}{!masters.loaded && !masters.error && <p role="status">Loading academic selections...</p>}{screens[3]}{screens[4]}{screens[5]}</>, screens[2], screens[7], <>{feeState.loading && <p role="status">Loading Student Integration fees...</p>}{feeState.error && <p role="alert">{feeState.error}</p>}{screens[6]}</>, <FullReview data={data} edit={setStep} studentId={recordIds.studentId} />]
  const uploadDocuments = async studentId => uploadAdmissionDocuments(studentId, dataRef.current.documents, DOCUMENTS, studentDocumentApi.upload, (item, saved) => {
    const current = dataRef.current
    const documents = { ...current.documents }
    if (item.index != null) documents.otherCertificates = (documents.otherCertificates || []).map((document, index) => index === item.index ? saved : document)
    else documents[item.key] = saved
    dataRef.current = { ...current, documents }
    setData(dataRef.current)
  })
  const focusFirst = () => window.setTimeout(() => document.querySelector('.student-admission .sa-field.invalid :is(input,select)')?.focus({ preventScroll: false }), 0)
  const nextStep = async () => {
    if (savingStep || submitting || savingDraft) return
    if (!canAction('/student-management/admissions', recordIds.admissionId ? 'edit' : 'create')) { setSaveError('You do not have permission to save this admission.'); return }
    setSaveError('')
    if (step === 1 && !masters.loaded) {
      setSaveError('Academic selections have not loaded yet. Please retry after they load.')
      return
    }
    const prefixes = [['personal.','contact.'],['academic.','previousEducation.','application.','admission.'],['parents.'],['documents.'],['fees.'],[]][step]
    const relevant = Object.fromEntries(Object.entries(allErrors).filter(([path]) => prefixes.some(prefix => path.startsWith(prefix))))
    setTouched(current => {
      const next = { ...current }
      Object.keys(allErrors).forEach(path => {
        if (prefixes.some(prefix => path.startsWith(prefix))) next[path] = true
      })
      return next
    })
    setErrors(relevant)
    if (Object.keys(relevant).length) { notify('Correct the highlighted fields before continuing.', 'error'); focusFirst(); return }
    setSavingStep(true)
    try {
      let result, ids = recordIds
      if (!ids.admissionId) {
        if (creationUncertain.current) throw new Error('A previous creation returned without an admission identity. Check the directory before creating another application.');
        const duplicate = duplicateAdmissionMessage(await studentAdmissionApi.getAll(), data)
        if (duplicate) throw new Error(duplicate)
        result = await studentAdmissionApi.create(data)
        rememberCreated('admissions', idsFromApi(result).admissionId)
        ids = idsFromApi(result)
        if (!ids.admissionId) { creationUncertain.current = true; throw new Error('The admission was created but no admission ID was returned.') }
        setRecordIds(ids)
      } else if ([0, 1].includes(step)) result = await studentAdmissionApi.update(ids.admissionId, data, { preserveAcademicMapping: step !== 1 })
      if (step === 1) {
        await studentAcademicDetailsApi.update(ids.admissionId, data)
        await studentPreviousEducationApi.update(ids.admissionId, data)
      } else if (step === 2) {
        if (ids.studentId) await studentParentApi.update(ids.studentId, data)
        else await studentAdmissionApi.update(ids.admissionId, data, { preserveAcademicMapping: true })
      } else if (step === 3) {
        if (ids.studentId) await uploadDocuments(ids.studentId)
        await studentAdmissionApi.update(ids.admissionId, dataRef.current)
      } else if (step === 4) {
        await studentAdmissionApi.update(ids.admissionId, data)
      }
      if (data.personal?.photo) {
        saveAdmissionPhoto(ids.admissionId, data.personal.photo)
        if (ids.studentId) saveAdmissionPhoto(ids.studentId, data.personal.photo)
      }
      if (ids.admissionId) {
        try {
          localStorage.setItem(`pirnav-draft-admission-${ids.admissionId}`, JSON.stringify(data))
        } catch { /* storage fallback */ }
      }
      if (result) {
        const returnedIds = idsFromApi(result, ids.admissionId)
        if (data.personal?.photo) {
          saveAdmissionPhoto(returnedIds.admissionId ?? ids.admissionId, data.personal.photo)
          if (returnedIds.studentId ?? ids.studentId) saveAdmissionPhoto(returnedIds.studentId ?? ids.studentId, data.personal.photo)
        }
        setRecordIds(current => ({ admissionId: returnedIds.admissionId ?? current.admissionId, studentId: returnedIds.studentId ?? current.studentId, academicId: returnedIds.academicId ?? current.academicId }))
      }
      notify(
        step === 3 && !ids.studentId
            ? 'Documents are ready to upload when the admission is submitted.'
            : 'Admission step saved successfully.',
        step === 3 && !ids.studentId ? 'info' : 'success',
      )
      const next = Math.min(step + 1, STEPS.length - 1)
      setStep(next); setFurthestStep(current => Math.max(current, next))
      if (!recordIds.admissionId) {
        // Navigate only after saving the draft and preserve progress if the
        // new -> edit route transition remounts the form.
        locallySavedAdmission.current = ids.admissionId
        navigate(`/student-management/admissions/${ids.admissionId}/edit`, {
          replace: true,
          state: { admissionWizard: { admissionId: ids.admissionId, step: next } },
        })
      }
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch (error) {
      const message = error.message || 'Unable to save this step.'
      setSaveError(message)
      notify(message, 'error')
    }
    finally { setSavingStep(false) }
  }
  const requestSubmit = () => {
    const entries=Object.entries(allErrors)
    setErrors(allErrors)
    if(entries.length){
      const [path,message]=entries[0]
      setStep(validationStep(path))
      notify(`${validationLabel(path)}: ${message}`, 'error')
      focusFirst()
      return
    }
    if (!declared) { notify('Confirm the declaration before submitting.', 'error'); return }
    setConfirmSubmit(true)
  }
  const skipCurrentStep = () => {
    if (step !== 2) return
    if (step === 2) {
      setData(current => ({ ...current, parents: empty().parents }))
      setErrors(current => Object.fromEntries(Object.entries(current).filter(([path]) => !path.startsWith('parents.'))))
      notify('Parent / Guardian details skipped.', 'info')
    } else if (step === 4) {
      // Previous education is optional. Clear partially entered values so this
      // step can be skipped without optional format validation blocking submit.
      setData(current => ({ ...current, previousEducation: empty().previousEducation }))
      setErrors(current => Object.fromEntries(Object.entries(current).filter(([path]) => !path.startsWith('previousEducation.'))))
      notify('Previous education details skipped.', 'info')
    }
    setStep(current => current + 1)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
  const submit = async () => {
    if (submitting || !canAction('/student-management/admissions', recordIds.admissionId ? 'edit' : 'create')) return;
    setSubmitting(true);
    try {
      let ids = recordIds;
      if (!ids.admissionId) {
        if (creationUncertain.current) throw new Error('A previous creation returned without an admission identity. Check the directory before creating another application.');
        const duplicate = duplicateAdmissionMessage(await studentAdmissionApi.getAll(), data);
        if (duplicate) throw new Error(duplicate);
        const result = await studentAdmissionApi.create(data);
        rememberCreated('admissions', idsFromApi(result).admissionId);
        ids = idsFromApi(result);
        if (!ids.admissionId) { creationUncertain.current = true; throw new Error('The admission was created but no admission ID was returned.') };
        setRecordIds(ids);
      } else if (!submittedRecord.current) {
        await studentAdmissionApi.update(ids.admissionId, data);
      }
      const duplicate = duplicateAdmissionMessage(await studentAdmissionApi.getAll(), data, ids.admissionId);
      if (duplicate) throw new Error(duplicate);
      const submitted = submittedRecord.current?.admissionId === ids.admissionId
        ? submittedRecord.current : await studentAdmissionApi.submit(ids.admissionId);
      submittedRecord.current = { ...submitted, admissionId: ids.admissionId };
      setRecordIds(current => ({ ...current, ...idsFromApi(submitted, ids.admissionId) }));
      const submittedIds = idsFromApi(submitted, ids.admissionId);
      const studentId = submittedIds.studentId ?? ids.studentId;
      rememberCreated('admissions', ids.admissionId);
      if (studentId) rememberCreated('student-profiles', studentId);
      const uploadedCount = await uploadDocuments(studentId);
      const latest = await studentAdmissionStatusApi.get(ids.admissionId);
      setData(current => ({ ...current, status: latest?.status ?? 'SUBMITTED' }));
      setRecordIds(current => ({ ...current, studentId: studentId ?? current.studentId }));
      setConfirmSubmit(false);
      try { localStorage.removeItem(`pirnav-draft-admission-${ids.admissionId}`) } catch { /* ignore */ }
      eventBus.emit(ERP_EVENTS.STUDENT_UPDATED, { admissionId: ids.admissionId, status: 'SUBMITTED' });
      notify(uploadedCount ? 'Admission submitted and documents uploaded successfully' : 'Admission application submitted successfully');
      navigate('/student-management/admissions');
    } catch (error) {
      setSaveError(error.message || 'Unable to submit this admission.');
      notify(error.message || 'Unable to submit this admission.', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  const saveAllDraftData = async (shouldNavigate = true) => {
    if (savingDraft || !canAction('/student-management/admissions', recordIds.admissionId ? 'edit' : 'create')) return;
    setSavingDraft(true);
    try {
      let ids = recordIds || {};
      if (!ids.admissionId) {
        if (creationUncertain.current) throw new Error('A previous creation returned without an admission identity. Check the directory before creating another application.');
        const duplicate = duplicateAdmissionMessage(await studentAdmissionApi.getAll(), data);
        if (duplicate) throw new Error(duplicate);
        const result = await studentAdmissionApi.create(data);
        rememberCreated('admissions', idsFromApi(result).admissionId);
        ids = idsFromApi(result);
        if (!ids.admissionId) { creationUncertain.current = true; throw new Error('The admission was created but no admission ID was returned.') };
        setRecordIds(ids);
      } else {
        await studentAdmissionApi.update(ids.admissionId, data);
      }

      if (ids.admissionId && (data.academic?.course || data.academic?.courseId)) {
        try {
          await studentAcademicDetailsApi.update(ids.admissionId, data);
        } catch (error) { throw new Error('Draft record saved. ' + (error.message || 'Some details could not be saved.')) }
      }

      if (ids.studentId && (data.parents?.father?.name || data.parents?.mother?.name || data.parents?.guardian?.name)) {
        try {
          await studentParentApi.update(ids.studentId, data);
        } catch (error) { throw new Error('Draft record saved. ' + (error.message || 'Some details could not be saved.')) }
      }

      if (ids.admissionId && (data.previousEducation?.tenth?.board || data.previousEducation?.tenth?.institution || data.previousEducation?.intermediate?.board)) {
        try {
          await studentPreviousEducationApi.update(ids.admissionId, data);
        } catch (error) { throw new Error('Draft record saved. ' + (error.message || 'Some details could not be saved.')) }
      }

      if (data.personal?.photo) {
        saveAdmissionPhoto(ids.admissionId, data.personal.photo);
        if (ids.studentId) saveAdmissionPhoto(ids.studentId, data.personal.photo);
      }

      if (ids.admissionId) {
        try {
          localStorage.setItem(`pirnav-draft-admission-${ids.admissionId}`, JSON.stringify(data))
        } catch { /* storage fallback */ }
      }

      if (ids.studentId) await uploadDocuments(ids.studentId)

      eventBus.emit(ERP_EVENTS.STUDENT_UPDATED, { admissionId: ids.admissionId, status: data.status || 'Draft' });
      notify('Draft application saved successfully.', 'success');
      setConfirmCancel(false);
      if (shouldNavigate) {
        window.setTimeout(() => navigate('/student-management/admissions'), 400);
      }
    } catch (error) {
      setSaveError(error.message || 'Unable to save draft.');
      setConfirmCancel(false);
      notify(error.message || 'Unable to save draft.', 'error');
    } finally {
      setSavingDraft(false);
    }
  };

  const handleCancel = () => {
    const hasData = Boolean(
      data.personal?.firstName ||
      data.contact?.mobile ||
      data.contact?.email ||
      data.academic?.course ||
      data.parents?.father?.name ||
      recordIds.admissionId
    );
    if (hasData) {
      setConfirmCancel(true);
    } else {
      navigate('/student-management/admissions');
    }
  };

  if (formLoading) return <p role="status" className="sa-empty">Loading admission...</p>
  if (formLoadError) return <div role="alert" className="sa-empty"><p>{formLoadError}</p><Button onClick={() => setFormAttempt(current => current + 1)}>Retry</Button></div>
  if (!canAction('/student-management/admissions', validId ? 'edit' : 'create')) return <div role="alert" className="sa-empty"><h2>Admission access unavailable</h2><p>You do not have permission to change this admission.</p><Button onClick={() => navigate('/student-management/admissions')}>Back to admissions</Button></div>
  return (
    <>
      <Breadcrumb tail={id ? 'Edit Admission' : 'New Admission'} />
      {formWarnings.length > 0 && <div role="alert" className="sa-callout warning"><strong>Some saved sections could not be loaded.</strong>{formWarnings.map(message => <span key={message}>{message}</span>)}<Button onClick={() => setFormAttempt(current => current + 1)}>Retry saved sections</Button></div>}
      <header className="sa-page-header sa-wizard-header">
        <div>
          <h1>{id ? 'Edit Student Admission' : 'New Student Admission'}</h1>
          <p>Registration Number <strong>{data.application.number}</strong></p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Badge value={data.status} />
          <span className="sa-draft-pct" style={{ fontSize: '0.76rem', fontWeight: 700, color: 'var(--brand, #125AA8)', background: 'var(--brand-soft, #EAF3FF)', padding: '4px 9px', borderRadius: '6px' }}>
            {Math.round(((step + 1) / STEPS.length) * 100)}% Complete
          </span>
          <Button onClick={handleCancel}>Cancel</Button>
        </div>
      </header>

      <div className="sa-admission-layout">
        <WizardStepper step={step} setStep={setStep} furthestStep={Math.max(furthestStep, initialStep)} busy={savingStep || submitting || savingDraft} />
        <form className="sa-wizard-card" noValidate aria-busy={savingStep || submitting || savingDraft} onSubmit={event => { event.preventDefault(); step < STEPS.length - 1 ? nextStep() : requestSubmit() }}>
          <div ref={wizardContentRef} id="admission-step-content" className="sa-wizard-content" role="region" aria-label={`${STEPS[step]} form section`} tabIndex={-1}>
            {wizardScreens[step]}
            {step === STEPS.length - 1 && (
              <label className="sa-declaration">
                <input type="checkbox" checked={declared} onChange={event => setDeclared(event.target.checked)} />
                <span><strong>Registration Declaration</strong>I confirm that the information entered above is correct.</span>
              </label>
            )}
          </div>
          <footer className="sa-wizard-actions erp-actions-bar">
            {saveError && <p role="alert" className="error">{saveError}</p>}
            {saveError && /semester|course not found|branch.*invalid/i.test(saveError) && step !== 1 && <Button onClick={() => { setStep(1); setSaveError('') }}>Review academic details</Button>}
            <Button disabled={!step || submitting || savingStep || savingDraft} onClick={() => setStep(current => current - 1)} aria-label="Go to previous admission step">
              <FiArrowLeft /> Back
            </Button>
            <span />
            <Button onClick={() => saveAllDraftData(false)} disabled={savingDraft || savingStep || submitting} aria-label="Save admission as draft">
              <FiSave /> {savingDraft ? 'Saving Draft...' : 'Save as Draft'}
            </Button>
            {step === 2 && <Button disabled={submitting} onClick={skipCurrentStep}>Skip</Button>}
            {step < STEPS.length - 1 ? (
              <Button primary onClick={nextStep} disabled={savingStep || savingDraft || submitting}>
                {savingStep ? 'Saving...' : 'Save & Continue'} <FiArrowRight />
              </Button>
            ) : (
              <Button primary disabled={!declared || submitting || savingDraft} onClick={requestSubmit}>
                {submitting ? 'Submitting...' : 'Submit Application'}
              </Button>
            )}
          </footer>
        </form>
      </div>

      {confirmSubmit && (
        <ConfirmDialog icon={FiCheckCircle} title="Confirm Registration Submission" confirmLabel="Confirm & Submit" busy={submitting} onCancel={() => setConfirmSubmit(false)} onConfirm={submit}>
          <p>Please verify the student details below. Once submitted, the registration will be sent to the admissions team for review.</p>
          <dl>
            <div><dt>Student</dt><dd>{studentName(data)}</dd></div>
            <div><dt>Registration Number</dt><dd>{data.application.number}</dd></div>
          </dl>
        </ConfirmDialog>
      )}

      {confirmCancel && (
        <ViewDialog title="Save Draft Before Leaving?" icon={FiSave} onClose={() => setConfirmCancel(false)} showExport={false} hideFooter busy={savingDraft} maxWidth="560px">
            <div className="sa-dialog-copy">
              <p>You have entered details in this admission application. Would you like to save your progress as a <strong>Draft</strong> before leaving? All your filled information across all steps will be saved so you can resume editing anytime.</p>
              <dl>
                <div><dt>Student</dt><dd>{studentName(data) || '-'}</dd></div>
                <div><dt>Registration Number</dt><dd>{data.application?.number || '-'}</dd></div>
              </dl>
            </div>
            <footer style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '8px', flexWrap: 'wrap' }}>
              <Button danger onClick={() => { setConfirmCancel(false); navigate('/student-management/admissions') }}>
                Discard & Exit
              </Button>
              <Button onClick={() => setConfirmCancel(false)}>
                Keep Editing
              </Button>
              <Button primary onClick={() => saveAllDraftData(true)} disabled={savingDraft}>
                {savingDraft ? 'Saving Draft...' : 'Save Draft & Exit'}
              </Button>
            </footer>
        </ViewDialog>
      )}
    </>
  )
}

function InfoGrid({ title, icon: Icon, items }) {
  const terms = {
    'Application Date': 'Registration Date',
    'Application Overview': 'Registration Overview',
    'Admission & Services': 'Registration & Services',
    'Fee Record': 'Fee Structure & Payment'
  };
  const visible = items.filter(([, value]) => text(value) && text(value) !== '-' && text(value) !== 'N/A')
  if (!visible.length) return null
  return (
    <section className="sa-detail-panel sa-modern-panel">
      <header className="sa-panel-header">
        <div className="sa-panel-title-wrap">
          {Icon && <span className="sa-panel-icon"><Icon /></span>}
          <h2>{terms[title] || title}</h2>
        </div>
        <span className="sa-card-count-badge">{visible.length} items</span>
      </header>
      <div className="sa-card-kv-grid sa-detail-kv-grid">
        {visible.map(([label, value, fullWidth]) => (
          <div key={label} className={`sa-kv-cell ${fullWidth ? 'sa-kv-full' : ''}`}>
            <span className="sa-kv-label">{terms[label] || label}</span>
            <strong className="sa-kv-val">{display(value)}</strong>
          </div>
        ))}
      </div>
    </section>
  )
}

function DocumentDetails({ data }) {
  const documents = [
    ...DOCUMENTS.map(([key, label]) => [key, label, data.documents?.[key]]),
    ...(data.documents?.otherCertificates || []).map(item => [item.id, 'Other Certificate', item])
  ]
  return (
    <section className="sa-detail-panel sa-modern-panel">
      <header className="sa-panel-header">
        <div className="sa-panel-title-wrap">
          <span className="sa-panel-icon"><FiShield /></span>
          <h2>Document Status</h2>
        </div>
        <span className="sa-card-count-badge">{documents.length} files</span>
      </header>
      <div className="sa-doc-review-grid">
        {documents.map(([key, label, document]) => {
          const status = documentStatus(document)
          return (
            <div key={key} className="sa-doc-review-item">
              <div className="sa-doc-item-icon">
                <FiFileText />
              </div>
              <div className="sa-doc-item-info">
                <strong className="sa-doc-item-name">{label}</strong>
              </div>
              <div className="sa-doc-item-status-action">
                <Badge value={status} />
<StudentDocumentActions document={document} studentId={data.studentId} />
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}

function Timeline({ activity = [] }) {
  const list = Array.isArray(activity) ? activity : [];
  return (
    <section className="sa-detail-panel sa-modern-panel">
      <header className="sa-panel-header">
        <div className="sa-panel-title-wrap">
          <span className="sa-panel-icon"><FiClock /></span>
          <h2>Admission Activity Timeline</h2>
        </div>
        <span className="sa-card-count-badge">{list.length} events</span>
      </header>
      <div className="sa-timeline-wrap">
        {!list.length ? (
          <div className="sa-timeline-empty">
            <FiClock />
            <p>No activity records logged for this admission yet.</p>
          </div>
        ) : (
          <div className="sa-timeline-list">
            {[...list].reverse().map((item, index) => {
              const isFirst = index === 0;
              return (
                <div key={`${item.date}-${index}`} className={`sa-timeline-item ${isFirst ? 'is-latest' : ''}`}>
                  <div className="sa-timeline-dot">
                    {isFirst ? <FiCheck /> : <FiClock />}
                  </div>
                  <div className="sa-timeline-body">
                    <div className="sa-timeline-row">
                      <strong className="sa-timeline-event">{item.label}</strong>
                      <span className="sa-timeline-date">{dateTime(item.date)}</span>
                    </div>
                    {item.remarks && (
                      <div className="sa-timeline-note">
                        {item.remarks}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  )
}

function DetailContent({ data, tab }) {
  const address = value => formatAddress(value)
  if (tab === 'personal') {
    return (
      <div className="sa-detail-grid-layout">
        <InfoGrid
          title="Personal Information"
          icon={FiUser}
          items={[
            ['Student Name', studentName(data)],
            ['First Name', data.personal?.firstName],
            ['Middle Name', data.personal?.middleName],
            ['Last Name', data.personal?.lastName],
            ['Gender', data.personal?.gender],
            ['Date of Birth', data.personal?.dob],
            ['Blood Group', data.personal?.bloodGroup],
            ['Nationality', data.personal?.nationality],
            ['Aadhaar Number', data.personal?.aadhaar],
          ]}
        />
        <InfoGrid
          title="Contact & Address"
          icon={FiPhone}
          items={[
            ['Student Mobile', data.contact?.mobile],
            ['Alternate Mobile', data.contact?.alternateMobile],
            ['Student Email', data.contact?.email],
            ['Alternate Email', data.contact?.alternateEmail],
            ['Current Address', address(data.contact?.currentAddress), true],
            ['Permanent Address', address(data.contact?.permanentAddress) || address(data.contact?.currentAddress), true],
          ]}
        />
        <InfoGrid
          title="Parent / Guardian"
          icon={FiUsers}
          items={[
            ['Father Name', data.parents?.father?.name],
            ['Father Mobile', data.parents?.father?.mobile],
            ['Father Email', data.parents?.father?.email],
            ['Father Occupation', data.parents?.father?.occupation],
            ['Father Qualification', data.parents?.father?.qualification],
            ['Father Annual Income', data.parents?.father?.income],
            ['Mother Name', data.parents?.mother?.name],
            ['Mother Mobile', data.parents?.mother?.mobile],
            ['Mother Email', data.parents?.mother?.email],
            ['Mother Occupation', data.parents?.mother?.occupation],
            ['Mother Qualification', data.parents?.mother?.qualification],
            ['Mother Annual Income', data.parents?.mother?.income],
            ['Guardian Name', data.parents?.guardian?.name],
            ['Guardian Relationship', data.parents?.guardian?.relationship === 'Other' ? data.parents?.guardian?.relationshipOther : data.parents?.guardian?.relationship],
            ['Guardian Mobile', data.parents?.guardian?.mobile],
            ['Guardian Email', data.parents?.guardian?.email],
            ['Guardian Occupation', data.parents?.guardian?.occupation],
            ['Guardian Qualification', data.parents?.guardian?.qualification],
            ['Guardian Annual Income', data.parents?.guardian?.income],
            ['Primary Contact', data.parents?.primaryContact],
            ['Emergency Contact', data.parents?.emergencyMobile],
          ]}
        />
      </div>
    )
  }
  if (tab === 'academic') {
    return (
      <InfoGrid
        title="Academic Enrollment"
        icon={FiBookOpen}
        items={[
          ['Academic Year', data.academic?.academicYear],
          ['Joining College', data.admission?.college],
          ['Admission Type', data.academic?.admissionType],
          ['Quota', quota(data)],
          ['Course', data.academic?.course],
          ['Course Code', data.academic?.courseCode],
          ['Department', data.academic?.department],
          ['Branch', data.academic?.branch],
          ['Branch Code', data.academic?.branchCode],
          ['Student Category', data.academic?.studentCategory],
          ['Regulation', data.academic?.regulation],
        ]}
      />
    )
  }
  if (tab === 'education') {
    return (
      <div className="sa-detail-grid-layout">
        <InfoGrid
          title="10th / SSC"
          icon={FiFileText}
          items={[
            ['Board', data.previousEducation?.tenth?.board],
            ['School', data.previousEducation?.tenth?.institution],
            ['Roll Number', data.previousEducation?.tenth?.rollNumber],
            ['Passing Year', data.previousEducation?.tenth?.passingYear],
            ['Score Type', data.previousEducation?.tenth?.score ? data.previousEducation?.tenth?.scoreType : ''],
            ['Score', data.previousEducation?.tenth?.score],
          ]}
        />
        <InfoGrid
          title="Intermediate / Diploma"
          icon={FiFileText}
          items={[
            ['Qualification', data.previousEducation?.intermediate?.qualification === 'Intermediate / 12th' ? '' : data.previousEducation?.intermediate?.qualification],
            ['Board / University', data.previousEducation?.intermediate?.board],
            ['College', data.previousEducation?.intermediate?.institution],
            ['Roll Number', data.previousEducation?.intermediate?.rollNumber],
            ['Passing Year', data.previousEducation?.intermediate?.passingYear],
            ['Stream', data.previousEducation?.intermediate?.stream === 'Other' ? data.previousEducation?.intermediate?.streamOther : data.previousEducation?.intermediate?.stream],
            ['Score Type', data.previousEducation?.intermediate?.score ? data.previousEducation?.intermediate?.scoreType : ''],
            ['Score', data.previousEducation?.intermediate?.score],
          ]}
        />
      </div>
    )
  }
  if (tab === 'services') {
    return (
      <InfoGrid
        title="Admission & Services"
        icon={FiHome}
        items={[
          ['Registration Number', data.application?.registrationNumber || data.application?.number],
          ['Registration Date', data.application?.registrationDate || data.application?.date],
          ['Admission Number', data.application?.admissionNumber],
          ['Admission Date', data.application?.admissionDate],
          ['College', data.admission?.college],
          ['Batch', data.admission?.batch],
          ['Scholarship', data.admission?.scholarship],
          ['Hostel', data.admission?.hostel],
          ['Hostel Preference', data.admission?.hostelPreference],
          ['Room Type / Beds', data.admission?.hostelRoomType],
          ['Transportation', data.admission?.transport],
          ['Transport Route', data.admission?.transportRoute],
        ]}
      />
    )
  }
  if (tab === 'fees' && data.integrationFeeError) return <p role="alert">{data.integrationFeeError}</p>
  if (tab === 'fees') {
    const isConfigured = Boolean(data.fees?.configured || (data.fees?.components?.length > 0 && Number(data.fees?.tuitionFee || 0) > 0) || Number(data.fees?.totalFee || 0) > 0)
    if (!isConfigured) {
      return (
        <div className="sa-fee-unconfigured-card" style={{ margin: '16px 0' }}>
          <div className="sa-fee-unconfigured-icon">
            <FiAlertCircle />
          </div>
          <div className="sa-fee-unconfigured-body">
            <h3>Fee Structure Not Configured</h3>
            <p>
              No active fee plan has been configured for {studentFullName(data)} ({display(data.academic?.course)} - {display(data.academic?.branch)}).
            </p>
            <div className="sa-fee-unconfigured-hint">
              Academic fee structures can be configured and approved from <strong>Fee Management &gt; Fee Plans</strong>.
            </div>
          </div>
        </div>
      )
    }
    const resolvedH = getResolvedHostelFee(data.admission, data.fees, data.academic)
    const resolvedT = getResolvedTransportFee(data.admission, data.fees, data.academic)
    const tuition = Number(data.fees?.tuitionFee || 0)
    const admissionFee = Number(data.fees?.admissionFee || 0)
    const scholarship = Number(data.fees?.scholarshipAmount || 0)
    const calculatedTotal = Math.max(0, tuition + admissionFee + resolvedH + resolvedT - scholarship)
    const totalFee = calculatedTotal > 0 ? calculatedTotal : Number(data.fees?.totalFee || 0)
    const paidAmount = Number(data.fees?.paidAmount || (data.fees?.paymentStatus === 'Paid' ? totalFee : 0))
    const balance = Math.max(0, totalFee - paidAmount)
    const isOverdue = data.fees?.paymentStatus === 'Overdue'
    const statusLabel = isOverdue ? 'Overdue' : balance === 0 && totalFee > 0 ? 'Paid' : paidAmount > 0 ? 'Partially Paid' : 'Pending'
    const statusSlug = statusLabel.toLowerCase().replace(/\s+/g, '-')
    const formattedPaymentPlan = formatPaymentPreference(data.fees?.paymentPlan)
    const isTermWise = /term|installment|semester/i.test(String(data.fees?.paymentPlan || ''))

    return (
      <div className="sa-fees-detail-container">
        {/* Colorful Financial Summary KPI Cards */}
        <div className="fm-summary-cards-grid" style={{ marginBottom: '16px' }}>
          <div className="fm-summary-card fm-summary-card--blue">
            <div className="fm-summary-card__header">
              <span className="fm-summary-card__label">Total Fee</span>
              <span className="fm-summary-card__icon-box"><FiCreditCard /></span>
            </div>
            <strong className="fm-summary-card__value">{money(totalFee)}</strong>
            <span className="fm-summary-card__meta">{data.fees?.structureName || 'Applicable Fee Plan'}</span>
          </div>

          <div className="fm-summary-card fm-summary-card--green">
            <div className="fm-summary-card__header">
              <span className="fm-summary-card__label">Paid Amount</span>
              <span className="fm-summary-card__icon-box"><FiCheckCircle /></span>
            </div>
            <strong className="fm-summary-card__value">{money(paidAmount)}</strong>
            <span className="fm-summary-card__meta">Payments recorded</span>
          </div>

          <div className="fm-summary-card fm-summary-card--amber">
            <div className="fm-summary-card__header">
              <span className="fm-summary-card__label">Pending Balance</span>
              <span className="fm-summary-card__icon-box"><FiClock /></span>
            </div>
            <strong className="fm-summary-card__value">{money(balance)}</strong>
            <span className="fm-summary-card__meta">Outstanding balance</span>
          </div>

          <div className={`fm-summary-card ${isOverdue ? 'fm-summary-card--red' : 'fm-summary-card--blue'}`}>
            <div className="fm-summary-card__header">
              <span className="fm-summary-card__label">Fee Status</span>
              <span className="fm-summary-card__icon-box"><FiShield /></span>
            </div>
            <strong className="fm-summary-card__value" style={{ fontSize: '18px' }}>
              <span className={`fm-badge fm-badge--${statusSlug}`}>{statusLabel}</span>
            </strong>
            <span className="fm-summary-card__meta">Payment preference: {formattedPaymentPlan}</span>
          </div>
        </div>

        <div className="sa-detail-grid-layout">
          <InfoGrid
            title="Fee Plan & Charges"
            icon={FiCreditCard}
            items={[
              ['Plan Name', data.fees?.structureName || data.fees?.planName || 'Academic Fee Structure'],
              ['Tuition Fee (per year)', money(data.fees?.tuitionFee)],
              ['Admission Fee (one-time)', money(data.fees?.admissionFee)],
              ['Scholarship Deduction', data.fees?.scholarshipAmount ? `- ${money(data.fees?.scholarshipAmount)}` : 'None'],
              ['Hostel Room Type', data.admission?.hostelRoomType || 'Not selected'],
              ['Hostel Fee (per year)', data.admission?.hostel === 'Yes' ? money(resolvedH) : 'Not selected'],
              ['Transportation Fee (per year)', data.admission?.transport === 'Yes' ? money(resolvedT) : 'Not selected'],
              ['Estimated First-Year Total', money(totalFee)],
              ['Estimated Entire 4-Year Total', money(Math.max(0, (tuition + resolvedH + resolvedT) * 4 + admissionFee - scholarship))],
              ['Payment Preference', formattedPaymentPlan],
              ['First Term Estimate', isTermWise ? money(Math.ceil(totalFee / 2)) : 'Not applicable'],
              ['Second Term Estimate', isTermWise ? money(Math.floor(totalFee / 2)) : 'Not applicable'],
            ]}
          />
          <FeeSummary data={data} />
        </div>
      </div>
    )
  }
  if (tab === 'documents') return <DocumentDetails data={data} />
  if (tab === 'activity') return <Timeline activity={data.activity} />
  return (
    <InfoGrid
      title="Application Overview"
      icon={FiGrid}
      items={[
        ['Registration Number', data.application?.registrationNumber || data.application?.number],
        ['Registration Date', data.application?.registrationDate || data.application?.date],
        ['Admission Number', data.application?.admissionNumber],
        ['Admission Date', data.application?.admissionDate],
        ['College', data.admission?.college],
        ['Academic Year', data.academic?.academicYear],
        ['Admission Type', data.academic?.admissionType],
        ['Course', data.academic?.course],
        ['Branch', data.academic?.branch],
        ['Quota', quota(data)],
        ['Fee Status', data.fees?.paymentStatus],
        ['Admission Status', STATUS[data.status] || data.status],
      ]}
    />
  )
}
function StudentHeader({ data }) {
  const normStat = normalizeStatus(data.status);
  const initials = studentInitials(data);
  const photoSrc = data.personal?.photo ? apiAssetUrl(data.personal.photo) : (data.personal?.photoUrl ? apiAssetUrl(data.personal.photoUrl) : '');
  return (
    <div className="cm-profile-banner">
      <div className="cm-profile-avatar-wrap">
        {photoSrc ? (
          <img src={photoSrc} alt={studentName(data)} className="cm-profile-logo" />
        ) : (
          <div className="cm-profile-placeholder">{initials}</div>
        )}
      </div>
      <div className="cm-profile-header-info">
        <div className="cm-profile-badges">
          {(data.application?.registrationNumber || data.application?.number) && <span className="cm-badge cm-badge-code">Reg: {data.application.registrationNumber || data.application.number}</span>}
          {data.application?.admissionNumber && <span className="cm-badge cm-badge-type">Adm: {data.application.admissionNumber}</span>}
          <span className={`cm-status-badge ${normStat === 'APPROVED' ? 'active' : 'inactive'}`}>
            {STATUS[normStat] || normStat}
          </span>
        </div>
        <h1 className="cm-profile-title"><span>{studentName(data)}</span></h1>
        <p className="cm-profile-subtitle">
          <span>{[display(data.academic?.course), display(data.academic?.branch), display(data.academic?.academicYear)].filter(Boolean).join(' - ')}</span>
        </p>
      </div>
    </div>
  );
}

function AdmissionDetails({ approval = false }) {
  const { canAction } = useScreenAccess()
  const authorized = canAction('/student-management/admissions', 'edit')
  const [detailError, setDetailError] = useState('')
  const [loadAttempt, setLoadAttempt] = useState(0)
  const { id } = useParams(); const navigate = useNavigate(); const validId = (id && id !== 'undefined' && id !== 'null') ? id : null; const [data, setData] = useState(null); const [loadingDetail, setLoadingDetail] = useState(Boolean(validId)); const [tab, setTab] = useState('overview'); const [remarks, setRemarks] = useState(''); const [toast, setToast] = useToastState(null, 'success'); const [confirmApproval, setConfirmApproval] = useState(false); const [reviewed, setReviewed] = useState(false); const [savingStatus, setSavingStatus] = useState(false)
  useEffect(() => {
    if (!validId) { setLoadingDetail(false); return }
    let active = true
    studentAdmissionApi.getById(validId).then(async row => {
      const admissionId = row.admissionId ?? row.id ?? validId
      const studentId = idsFromApi(row, admissionId).studentId
      const optional = await Promise.allSettled([
        studentAcademicDetailsApi.get(admissionId),
        studentPreviousEducationApi.get(admissionId),
        studentFeeApi.getSummary(admissionId),
        studentAdmissionStatusApi.get(admissionId),
        studentId ? studentParentApi.get(studentId) : Promise.resolve(null),
        studentId ? studentDocumentApi.getAll(studentId) : Promise.resolve([])
      ])
      const uploadedDocs = optional[5].status === 'fulfilled' && Array.isArray(optional[5].value) && optional[5].value.length ? documentsFromApi(optional[5].value) : {}
      const rawDocs = row.documents || row.documentStatuses || (typeof row.formData === 'string' ? (() => { try { return JSON.parse(row.formData)?.documents } catch { return null } })() : row.formData?.documents) || {}
      const mergedDocs = mergeDocumentStatuses(rawDocs, uploadedDocs)
      const hydrated = admissionFromApi({
        ...row,
        academicDetails: optional[0].status === 'fulfilled' && optional[0].value ? optional[0].value : row.academicDetails,
        previousEducation: optional[1].status === 'fulfilled' && optional[1].value ? optional[1].value : row.previousEducation,
        feeSummary: optional[2].status === 'fulfilled' ? optional[2].value : null,
        status: optional[3].status === 'fulfilled' ? optional[3].value?.status ?? row.status : row.status,
        parents: optional[4].status === 'fulfilled' && optional[4].value ? optional[4].value : row.parents,
        documents: Object.keys(mergedDocs).length ? mergedDocs : (row.documents || row.documentStatuses),
      })
      if (active) setData({ ...hydrated, integrationFeeError: optional[2].status === 'rejected' ? optional[2].reason?.message || 'Fee information unavailable.' : '' })
    }).catch(error => { if (active) { setDetailError(error.message || 'Unable to load admission.'); setToast({ message: error.message || 'Unable to load admission.', tone: 'error' }) } }).finally(() => { if (active) setLoadingDetail(false) }); return () => { active = false } }, [validId, setToast, loadAttempt])
  if (loadingDetail) return <section className="sa-empty"><FiClock /><h2>Loading admission...</h2></section>
  if (!data) return <section className="sa-empty"><FiAlertCircle /><h2>{detailError || 'Admission not found'}</h2><Button onClick={() => setLoadAttempt(current => current + 1)}>Retry</Button><Button onClick={() => navigate('/student-management/admissions')}>Back</Button></section>
  const transition = async status => { if (savingStatus || !admissionDecisionAllowed(normalizeStatus(data.status), status, authorized)) return; if (['CORRECTION_REQUIRED','REJECTED'].includes(status) && !text(remarks)) { setToast({ message: 'Admission officer remarks are required for this decision.', tone: 'error' }); return } setSavingStatus(true); try { const result = await studentAdmissionStatusApi.update(id, { status, remarks }); setData(current => ({ ...current, status: normalizeStatus(result.status), remarks })); setRemarks(''); eventBus.emit(ERP_EVENTS.STUDENT_UPDATED, { admissionId: id, status }); setToast({ message: status === 'APPROVED' ? approvalNotice(result) : `${STATUS[status] || status} saved successfully`, tone: 'success' }); setConfirmApproval(false); if (status === 'APPROVED') navigate('/student-management/profiles') } catch (error) { setToast({ message: error.message || 'Unable to update admission status.', tone: 'error' }) } finally { setSavingStatus(false) } }
  if (approval) {
    const markedDocs = DOCUMENTS.filter(([key]) => {
      const doc = data.documents?.[key]
      const status = documentStatus(doc)
      return status && status !== 'Not Submitted'
    }).length
    const photoSrc = data.personal?.photo ? apiAssetUrl(data.personal.photo) : (data.personal?.photoUrl ? apiAssetUrl(data.personal.photoUrl) : '')
    const initials = studentInitials(data)
    const studentId = idsFromApi(data, id).studentId

    return (
      <div className="cm-profile-view" data-export-record>
        <Breadcrumb tail="Admission Review" />
        <div className="cm-profile-top-bar">
          <ExportMenu
            mode="single"
            title="Student Admission"
            filename={`admission_${data.application?.admissionNumber || data.application?.number || id}`}
            recordSections={admissionDetailSections(data)}
          />
          <button
            type="button"
            className="cm-button secondary erp-btn erp-btn--secondary"
            onClick={() => navigate('/student-management/admissions')}
          >
            <FiArrowLeft /> Back
          </button>
        </div>

        <div className="cm-profile-card">
          <StudentHeader data={data} />
          <nav className="sa-tabs">
            {DETAIL_TABS_APPROVAL.map(([value, label, Icon]) => (
              <button key={value} className={tab === value ? 'active' : ''} onClick={() => setTab(value)}>
                <Icon /> {label}
              </button>
            ))}
          </nav>

          <section className="sa-detail-card">
            {tab === 'decision' ? (
              <div className="sa-detail-grid-layout">
                <section className="sa-approval">
                  <header>
                    <div>
                      <h2>Review Decision</h2>
                      <p>Complete the application review before recording a workflow decision.</p>
                    </div>
                    <Badge value={data.status} />
                  </header>
                  <label className="sa-review-confirm">
                    <input type="checkbox" checked={reviewed} onChange={event => setReviewed(event.target.checked)} />
                    <span>I have reviewed all admission sections and supporting information.</span>
                  </label>
                  <label className="sa-remarks">
                    <span>Admission Officer Remarks</span>
                    <textarea
                      maxLength="500"
                      value={remarks}
                      onChange={event => setRemarks(event.target.value)}
                      placeholder="Add verification, correction or decision remarks..."
                    />
                    <small>{remarks.length}/500</small>
                  </label>
                  <footer>
                    {authorized && ['SUBMITTED', 'PENDING', 'UNDER_REVIEW', 'VERIFIED'].includes(normalizeStatus(data.status)) && (
                      <><Button disabled={!reviewed || savingStatus || !remarks.trim()} onClick={() => transition('CORRECTION_REQUIRED')}>Request Correction</Button><Button danger disabled={!reviewed || savingStatus || !remarks.trim()} onClick={() => transition('REJECTED')}>
                        Reject
                      </Button></>
                    )}
                    {['SUBMITTED', 'PENDING', 'UNDER_REVIEW', 'VERIFIED'].includes(data.status) && (
                      <Button primary disabled={!reviewed || savingStatus} onClick={() => { setToast(null); setConfirmApproval(true) }}>
                        Approve Admission
                      </Button>
                    )}
                    {data.status === 'APPROVED' && (
                      <span className="sa-approved-note">
                        <FiCheckCircle /> Admission approved as {data.application.admissionNumber}
                      </span>
                    )}
                  </footer>
                </section>
              </div>
            ) : (
              <DetailContent data={data} tab={tab} />
            )}
            {(() => {
              const tabs = DETAIL_TABS_APPROVAL.map(([v]) => v)
              const idx = tabs.indexOf(tab)
              const prevTab = idx > 0 ? tabs[idx - 1] : null
              const nextTab = idx < tabs.length - 1 ? tabs[idx + 1] : null
              return (
                <div className="sa-tab-nav-footer">
                  {prevTab ? (
                    <button type="button" className="cm-button secondary" onClick={() => setTab(prevTab)}>
                      &larr; Previous
                    </button>
                  ) : <span />}
                  {nextTab && (
                    <button type="button" className="cm-button" onClick={() => setTab(nextTab)}>
                      Next &rarr;
                    </button>
                  )}
                </div>
              )
            })()}
          </section>
        </div>

        {confirmApproval && (
          <ConfirmDialog
            busy={savingStatus}
            error={toast?.tone === 'error' ? toast.message : null}
            title="Approve Student Admission?"
            confirmLabel="Approve Admission"
            onCancel={() => setConfirmApproval(false)}
            onConfirm={() => transition('APPROVED')}
          >
            <p>This will mark the student admission as approved and generate an admission number.</p>
            <dl>
              <div><dt>Student</dt><dd>{studentName(data)}</dd></div>
              <div><dt>Course / Branch</dt><dd>{data.academic?.course} | {data.academic?.branch}</dd></div>
              <div><dt>Academic Year</dt><dd>{data.academic?.academicYear}</dd></div>
              <div><dt>Fee Status</dt><dd>{data.fees?.paymentStatus}</dd></div>
            </dl>
          </ConfirmDialog>
        )}
      </div>
    )
  }
  return (
    <div className="cm-profile-view" data-export-record>
      <Breadcrumb tail="Admission Details" />
      <div className="cm-profile-top-bar">
        <ExportMenu mode="single" title="Student Admission" filename={`admission_${data.application.admissionNumber || data.application.number || id}`} recordSections={admissionDetailSections(data)} />
        <button type="button" className="cm-button secondary erp-btn erp-btn--secondary" onClick={() => navigate('/student-management/admissions')}>
          &larr; Back
        </button>
      </div>

      <div className="cm-profile-card">
        <StudentHeader data={data} />
        <nav className="sa-tabs">
          {DETAIL_TABS.map(([value, label, Icon]) => (
            <button key={value} className={tab === value ? 'active' : ''} onClick={() => setTab(value)}>
              <Icon /> {label}
            </button>
          ))}
        </nav>

        <section className="sa-detail-card">
          <DetailContent data={data} tab={tab} />
        </section>
      </div>
    </div>
  );
}

function AdmissionRouteDialog({ approval = false }) {
  const navigate = useNavigate()
  return <ViewDialog title={approval ? 'Admission Review' : 'Admission Details'} icon={FiUser} onClose={() => navigate('/student-management/admissions')} maxWidth="1120px" showExport={false}><AdmissionDetails approval={approval} /></ViewDialog>
}

export default function StudentAdmission() {
  const { pathname } = useLocation()
  let screen = <AdmissionList />
  if (pathname.endsWith('/new') || pathname.endsWith('/edit')) screen = <AdmissionForm />
  else if (pathname.endsWith('/approval')) screen = <><AdmissionList /><AdmissionRouteDialog approval /></>
  else if (/\/admissions\/[^/]+$/.test(pathname)) screen = <><AdmissionList /><AdmissionRouteDialog /></>
  return <DashboardLayout><main className="student-admission">{screen}</main></DashboardLayout>
}
