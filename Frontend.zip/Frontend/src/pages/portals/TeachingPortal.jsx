import Link from '../../components/portals/PermissionLink.jsx'
/* eslint-disable react/set-state-in-effect -- Reset dependent registers before synchronizing them with the selected backend class. */
import { useEffect, useState } from 'react'
import { FiAlertCircle, FiBookOpen, FiDownload, FiFileText, FiSearch, FiX } from 'react-icons/fi'
import PortalLayout from '../../layouts/PortalLayout.jsx'
import FilterPanel from '../../components/FilterPanel.jsx'
import { Feedback, Field, PortalDialog, Stats, Status } from '../../components/portals/PortalUI.jsx'
import { teachingService as service } from '../../services/portals/teachingService.js'
import { usePortalData } from '../../hooks/usePortalData.js'
import './teaching-portal.css'
import './teaching-portal-enhanced.css'
import TeachingDashboard from './TeachingDashboard.jsx'
import FacultyAttendance from './FacultyAttendance.jsx'
import FacultySelfAttendance from './FacultySelfAttendance.jsx'
import TeachingMarks from './TeachingMarks.jsx'
import TeachingLeave from './TeachingLeave.jsx'

const same = (a, b) => String(a) === String(b)
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` }
const time = value => String(value || '').slice(0, 5) || '—'
const formatDate = value => value ? String(value).slice(0, 10) : '—'
const descriptions = { dashboard: 'Your teaching schedule, assigned classes, and daily academic work.', students: 'View students enrolled in the sections assigned to you.', subjects: 'Your teaching allocations, sections, and weekly workload.', attendance: 'Record and review attendance for your assigned classes.', 'my-attendance': 'Track your daily check-in, check-out times, working hours, and review weekly and monthly attendance records.', marks: 'Enter assessment marks for students in your assigned subjects.', timetable: 'Your published teaching schedule, organised by weekday.', materials: 'Learning resources for your assigned subjects.', leave: 'Apply for leave using your college’s active policies.', notifications: 'College announcements and updates for your account.', profile: 'Your faculty identity and employment information.' }

function Table({ columns, records, empty = 'No records found', detail = 'Try another filter or contact your academic coordinator to verify the assignments.' }) {
  return <div className="tf-table-wrap"><table><thead><tr>{columns.map(([key, title]) => <th key={key} scope="col">{title}</th>)}</tr></thead><tbody>{records.length ? records.map((row, i) => <tr key={`${row.id ?? row.studentId ?? row.timetableEntryId ?? i}:${row.sectionId ?? ''}`}>{columns.map(([key, , render]) => <td key={key}>{render ? render(row) : row[key] ?? '—'}</td>)}</tr>) : <tr><td colSpan={columns.length}><div className="tf-empty"><FiBookOpen /><strong>{empty}</strong><p>{detail}</p></div></td></tr>}</tbody></table></div>
}
function exportCsv(records, columns, filename) {
  const cell = value => `"${String(value ?? '').replace(/^[=+@-]/, "'$&").replaceAll('"', '""')}"`
  const csv = [columns.map(([, title]) => cell(title)).join(','), ...records.map(row => columns.map(([key]) => cell(row[key])).join(','))].join('\r\n')
  const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' })), a = document.createElement('a')
  a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000)
}
export default function TeachingPortal({ screen, title }) {
  const state = usePortalData(service), { data } = state
  const [refreshing, setRefreshing] = useState(false)
  const [dismissedData, setDismissedData] = useState(null)
  const [leaveSummaryTarget, setLeaveSummaryTarget] = useState(null)
  const refresh = async () => { setRefreshing(true); try { await state.refresh() } catch { /* Feedback displays the error. */ } finally { setRefreshing(false) } }
  return <PortalLayout title={title}><main className={`portal-page tf-page${screen === 'leave' ? ' tl-page' : ''}`}><header className="tf-heading"><div><p className="portal-eyebrow">DIGITAL CAMPUS / TEACHING FACULTY</p><h1>{title}</h1><p>{descriptions[screen]}</p></div>{screen === 'leave' ? <div className="tl-summary-anchor" ref={setLeaveSummaryTarget} /> : <div className="tf-heading-actions"><span className={`tf-live${state.error ? ' is-error' : ''}`} role="status">{state.error ? 'Workspace unavailable' : 'College records'}</span></div>}</header>
    <Feedback error={state.error} notice={state.notice} />
    {!data ? <section className={`portal-card tf-loading${state.error ? ' has-error' : ''}`} aria-labelledby={state.error ? 'tf-load-title' : undefined}>
      {state.error ? <>
        <span className="tf-load-icon"><FiAlertCircle aria-hidden="true" /></span>
        <div className="tf-load-copy">
          <p className="portal-eyebrow">TEACHING WORKSPACE</p>
          <h2 id="tf-load-title">Your faculty workspace is unavailable</h2>
          <p>We couldn’t load your assignments and teaching records. Check your faculty access or connection, then try again.</p>
          <button type="button" className="tf-retry-button" onClick={refresh} disabled={refreshing}>{refreshing ? 'Retrying…' : 'Retry loading'}</button>
        </div>
        <aside className="tf-load-help"><strong>What to check</strong><span>Confirm your faculty account is mapped and has permission to access the teaching portal.</span></aside>
      </> : <div className="tf-loading-progress" role="status">
        <span className="tf-loading-spinner" aria-hidden="true" />
        <div><strong>Preparing your workspace</strong><p>Loading your faculty profile and teaching assignments…</p></div>
      </div>}
    </section> : <>
      {!!data.warnings.length && dismissedData !== data && <div className="tf-data-notice" role="status"><span><FiAlertCircle aria-hidden="true" />Some information is temporarily unavailable. Your other teaching records are ready to use.</span><div><button type="button" disabled={refreshing} onClick={refresh}>Retry</button><button type="button" className="tf-notice-close" aria-label="Dismiss data availability notice" onClick={() => setDismissedData(data)}><FiX /></button></div></div>}
      {screen === 'dashboard' && <TeachingDashboard data={data} onRetry={refresh} />}
      {screen === 'students' && <StudentDirectory data={data} />}
      {screen === 'subjects' && <SubjectDirectory data={data} />}
      {screen === 'attendance' && <FacultyAttendance data={data} />}
      {screen === 'my-attendance' && <FacultySelfAttendance data={data} />}
      {screen === 'marks' && <TeachingMarks data={data} />}
      {screen === 'timetable' && <Timetable data={data} />}
      {screen === 'leave' && <TeachingLeave data={data} summaryTarget={leaveSummaryTarget} />}
      {screen === 'profile' && <Profile data={data} />}
      {['materials', 'notifications'].includes(screen) && <Unavailable screen={screen} data={data} />}
    </>}
  </main></PortalLayout>
}
function StudentDirectory({ data }) {
  const [search, setSearch] = useState(''), [section, setSection] = useState(''), [page, setPage] = useState(1), [pageSize, setPageSize] = useState(10), [selected, setSelected] = useState(null)
  const rosterUnavailable = data.warnings.some(message => message.startsWith('Students'))
  const sections = [...new Map(data.assignments.map(r => [String(r.sectionId), r])).values()]
  const filtered = data.students.filter(r => (!section || same(r.sectionId, section)) && `${r.name} ${r.rollNumber} ${r.email || ''}`.toLowerCase().includes(search.trim().toLowerCase()))
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize)), current = Math.min(page, pages), visible = filtered.slice((current - 1) * pageSize, current * pageSize)
  return <><Stats items={[[rosterUnavailable ? "Loaded students" : "My students", new Set(data.students.map(r => r.id)).size], ['Assigned sections', sections.length], ['Matching records', filtered.length]]} /><section className="portal-card tf-directory"><header className="portal-section-heading"><div><p className="portal-eyebrow">CLASS DIRECTORY</p><h2>Assigned students</h2></div><button disabled={!filtered.length} onClick={() => exportCsv(filtered, [['rollNumber', 'Roll number'], ['name', 'Student name'], ['sectionName', 'Section'], ['email', 'Email']], 'my-students.csv')}><FiDownload /> Export CSV</button></header><FilterPanel className="tf-filters" active={!!(search || section)} onClear={() => { setSearch(''); setSection(''); setPage(1) }} actions={<label className="tf-rows">Rows <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setPage(1) }}>{[10, 25, 50].map(n => <option key={n}>{n}</option>)}</select></label>}><label className="course-search"><FiSearch /><input type="search" placeholder="Search name, roll number or email..." value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></label><Field label="Assigned section"><select value={section} onChange={e => { setSection(e.target.value); setPage(1) }}><option value="">All assigned sections</option>{sections.map(r => <option key={r.sectionId} value={r.sectionId}>{r.sectionName} · {r.branchName} · {r.semesterName}</option>)}</select></Field></FilterPanel><Table records={visible} empty={rosterUnavailable ? 'Student records could not be loaded' : data.assignments.length ? 'No students found in your assigned sections' : 'No teaching assignments configured'} columns={[["rollNumber", 'Roll number'], ['name', 'Student', r => <button className="tf-text-button" onClick={() => setSelected(r)}>{r.name}</button>], ['sectionName', 'Section'], ['email', 'Email'], ['status', 'Enrollment', () => <Status>Enrolled</Status>], ['actions', 'Actions', r => <button onClick={() => setSelected(r)}>View details</button>]]} /><footer className="tf-pagination"><span>{filtered.length ? `${(current - 1) * pageSize + 1}–${Math.min(current * pageSize, filtered.length)}` : 0} of {filtered.length} records</span><div><button disabled={current === 1} onClick={() => setPage(current - 1)}>Previous</button><span>{current} / {pages}</span><button disabled={current >= pages} onClick={() => setPage(current + 1)}>Next</button></div></footer></section>{selected && <PortalDialog title="Student details" onClose={() => setSelected(null)}><dl className="portal-profile">{[['Student', selected.name], ['Roll number', selected.rollNumber], ['Section', selected.sectionName], ['Email', selected.email || 'Not provided']].map(([key, value]) => <div key={key}><dt>{key}</dt><dd>{value}</dd></div>)}</dl><div className="portal-actions"><button onClick={() => setSelected(null)}>Close</button></div></PortalDialog>}</>
}
function SubjectDirectory({ data }) {
  const [search, setSearch] = useState('')
  const filtered = data.assignments.filter(r => `${r.subjectName} ${r.subjectCode || ''} ${r.courseName || ''} ${r.branchName || ''} ${r.sectionName || ''} ${r.semesterName || ''} ${r.academicYearName || ''}`.toLowerCase().includes(search.trim().toLowerCase()))
  return <><Stats items={[["My subjects", new Set(data.assignments.map(r => r.subjectId)).size], ['Teaching allocations', data.assignments.length], ['Weekly periods', data.assignments.reduce((sum, r) => sum + Number(r.periodsPerWeek || 0), 0)]]} /><section className="portal-card"><header className="portal-section-heading"><div><h2>My teaching allocations</h2><p>Only subjects and sections assigned to your faculty account are shown.</p></div></header><label className="tf-search"><FiSearch /><input type="search" placeholder="Search subject, code, program or section..." value={search} onChange={e => setSearch(e.target.value)} /></label><Table records={filtered} empty={data.assignments.length ? 'No assigned subjects match this search' : 'No teaching subjects assigned'} columns={[["subjectName", 'Subject', r => <><strong>{r.subjectName}</strong><small>{r.subjectCode || 'Subject code not configured'}</small></>], ['courseName', 'Program'], ['branchName', 'Department / branch'], ['semesterName', 'Semester', r => r.semesterName || `Semester ${r.semesterNumber || r.semesterId}`], ['sectionName', 'Assigned section'], ['academicYearName', 'Academic year'], ['periodsPerWeek', 'Periods / week'], ['actions', 'Actions', r => <div className="tf-row-actions"><Link to={`/faculty-portal/attendance?assignment=${r.id}`}>Attendance</Link><Link to={`/faculty-portal/marks?assignment=${r.id}`}>Marks</Link></div>]]} /></section></>
}
function Timetable({ data }) {
  const [day, setDay] = useState(''), [view, setView] = useState('week')
  const days = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']
  const filtered = data.timetable.filter(r => !day || String(r.dayOfWeek).toUpperCase() === day).slice().sort((a, b) => days.indexOf(String(a.dayOfWeek).toUpperCase()) - days.indexOf(String(b.dayOfWeek).toUpperCase()) || String(a.startTime).localeCompare(String(b.startTime)))
  if (data.timetableError) return <section className="portal-card"><h2>Published teaching timetable</h2><p className="portal-feedback error">{data.timetableError}</p><p>Please try again when the college service is available.</p></section>
  return <section className="portal-card"><header className="portal-section-heading"><h2>Published teaching timetable</h2><div className="tf-row-actions"><button aria-pressed={view === 'week'} onClick={() => setView('week')}>Week</button><button aria-pressed={view === 'list'} onClick={() => setView('list')}>List</button></div></header>{data.timetableError && <p className="portal-feedback error">{data.timetableError}</p>}{view === 'week' ? <div className="tf-week-scroll"><div className="tf-week">{days.map(day => <section key={day}><h3>{day.slice(0, 3)}</h3>{filtered.filter(r => String(r.dayOfWeek).toUpperCase() === day).map((r, i) => <article key={r.timetableEntryId || i}><span>{time(r.startTime)} – {time(r.endTime)}</span><strong>{r.subjectName}</strong><p>{r.sectionName} · {r.classroomName || 'Room not assigned'}</p><small>{r.semesterName}</small></article>)}{!filtered.some(r => String(r.dayOfWeek).toUpperCase() === day) && <p className="tf-no-class">No classes</p>}</section>)}</div></div> : <><Field label="Day"><select value={day} onChange={e => setDay(e.target.value)}><option value="">All days</option>{days.map(d => <option key={d}>{d}</option>)}</select></Field><Table records={filtered} columns={[["dayOfWeek", 'Day'], ['time', 'Time', r => `${time(r.startTime)} – ${time(r.endTime)}`], ['subjectName', 'Subject'], ['sectionName', 'Section'], ['semesterName', 'Semester'], ['classroomName', 'Room']]} /></>}</section>
}
function DeprecatedLeave() {
  const [options, setOptions] = useState({ types: [], policies: [] }), [error, setError] = useState(''), [notice, setNotice] = useState(''), [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [confirm, setConfirm] = useState(false), [form, setForm] = useState({ typeId: '', policyId: '', from: today(), to: today(), reason: '' })
  const load = () => { setLoading(true); setError(''); return service.leaveOptions().then(setOptions).catch(e => setError(e.message)).finally(() => setLoading(false)) }
  useEffect(() => { let active = true; service.leaveOptions().then(result => { if (active) setOptions(result) }).catch(e => { if (active) setError(e.message) }).finally(() => { if (active) setLoading(false) }); return () => { active = false } }, [])
  const input = key => ({ value: form[key], onChange: e => setForm({ ...form, [key]: e.target.value }) })
  return <section className="portal-card"><h2>Apply for leave</h2><Feedback error={error} notice={notice} />{loading && <p role="status">Loading active leave types and policies...</p>}{error && <button onClick={load}>Retry leave options</button>}<form onSubmit={e => { e.preventDefault(); setConfirm(true) }}><fieldset disabled={busy || loading}><div className="portal-filters"><Field label="Leave type"><select required {...input('typeId')}><option value="">Select leave type</option>{options.types.map(r => <option key={r.id ?? r.leaveTypeId} value={r.id ?? r.leaveTypeId}>{r.name}</option>)}</select></Field><Field label="Policy"><select required {...input('policyId')}><option value="">Select active policy</option>{options.policies.map(r => <option key={r.id ?? r.policyId} value={r.id ?? r.policyId}>{r.name}</option>)}</select></Field><Field label="From date"><input required type="date" min={today()} {...input('from')} /></Field><Field label="To date"><input required type="date" min={form.from} {...input('to')} /></Field></div><Field label="Reason"><textarea required minLength={10} maxLength={500} rows={4} {...input('reason')} /></Field><p className="tf-info">Your request is sent to the college for approval. Faculty-specific leave history is not available through the current API contract.</p><div className="portal-actions"><button className="primary" disabled={!options.types.length || !options.policies.length}>Review leave request</button></div></fieldset></form>{confirm && <PortalDialog title="Submit leave request?" onClose={() => { if (!busy) setConfirm(false) }}><p>Request leave from {form.from} to {form.to}?</p><Feedback error={error} /><div className="portal-actions"><button disabled={busy} onClick={() => setConfirm(false)}>Go back</button><button className="primary" disabled={busy} onClick={async () => { setBusy(true); setError(''); try { await service.requestLeave(form); setConfirm(false); setNotice('Leave request submitted to the college for approval.'); setForm({ ...form, reason: '' }) } catch (e) { setError(e.message) } finally { setBusy(false) } }}>{busy ? 'Submitting...' : 'Confirm submission'}</button></div></PortalDialog>}</section>
}
function Profile({ data }) {
  const profile = data.me
  return <><section className="tf-hero tf-profile-hero"><div className="tf-avatar">{(profile.fullName || 'Faculty').split(' ').map(s => s[0]).slice(0, 2).join('')}</div><div><h2>{profile.fullName}</h2><p>{profile.designation || 'Teaching faculty'} · {profile.department || 'Department not configured'}</p><span>{profile.identifier || `Faculty ID ${data.facultyId}`}</span></div></section><section className="portal-card"><h2>Faculty profile</h2><dl className="portal-profile">{[['Employee ID', profile.identifier], ['Faculty ID', data.facultyId], ['Email', profile.email], ['Mobile', profile.mobile], ['Department', profile.department], ['Designation', profile.designation], ['Account status', profile.status], ['Date of birth', formatDate(profile.dateOfBirth)], ['Address', profile.address]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value || 'Not provided'}</dd></div>)}</dl><p className="tf-info">Contact your administrator to update official identity, employment, or department details.</p></section></>
}
function Unavailable({ screen, data }) {
  const materials = screen === 'materials'
  return <section className="portal-card"><header className="portal-section-heading"><h2>{materials ? 'Subject learning resources' : 'Faculty announcements'}</h2></header><div className="tf-feature-status"><FiFileText /><div><h3>{materials ? 'Material sharing API is not configured' : 'Faculty notification API is not configured'}</h3><p>{materials ? 'Your subjects are listed below. Uploading and sharing materials requires a faculty resource endpoint; no files will be saved as live college submissions until it is connected.' : 'Personal announcements will appear here when an authenticated faculty notifications endpoint is available.'}</p></div></div>{materials && <Table records={data.assignments} columns={[["subjectName", 'Assigned subject'], ['sectionName', 'Section'], ['academicYearName', 'Academic year'], ['resources', 'Resource status', () => 'Awaiting backend integration']]} />}</section>
}
