import { useScreenAccess } from '../auth/ScreenAccess.jsx'
import { MODULE_REGISTRY, findModuleForPath } from '../config/moduleRegistry.js'
import { adminWorkspaceForModule } from '../config/adminWorkspaces.js'
import useToastState from '../hooks/useToastState'
import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { FiAlertCircle, FiLock, FiLogOut, FiMenu, FiSearch, FiUser, FiX } from 'react-icons/fi'
import { getUserRole, signOut } from '../auth/auth'
import { changePassword, profileApi } from '../api/apiEndpoints'
import Sidebar from '../components/Sidebar'
import ThemeColorPicker from '../components/ThemeColorPicker'
import { feeBreadcrumbs } from '../utils/feeNavigation'
import HeaderAcademicYear from '../components/HeaderAcademicYear'
import AcademicContextSelect from '../components/AcademicContextSelect'
import DeactivationBlockedDialog from '../components/DeactivationBlockedDialog'
import { API_FAILURE_EVENT } from '../api/apiFailureNotice'
import { dismissToast, getToasts, subscribeToToasts } from '../utils/toast'
import './DashboardLayout.css'
import './AccountMenu.css'
import '../styles/error-notices.css'

const empty = {
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
}

const requirements = (password) => [
  ['At least 8 characters', password.length >= 8],
  ['One uppercase letter', /[A-Z]/.test(password)],
  ['One lowercase letter', /[a-z]/.test(password)],
  ['One number', /\d/.test(password)],
  ['One special character', /[^A-Za-z0-9]/.test(password)],
]

function PageErrorNotices({ pathname }) {
  const toasts = useSyncExternalStore(subscribeToToasts, getToasts, getToasts)
  const [duplicates, setDuplicates] = useState([])
  const [apiFailure, setApiFailure] = useState(null)
  const [hasInlineError, setHasInlineError] = useState(false)
  const errors = toasts.filter((toast) => toast.type === 'error')
  const apiFailureTimer = useRef(null)

  useEffect(() => {
    const onApiFailure = (event) => {
      if (apiFailureTimer.current) return
      const failure = { ...event.detail, id: `${Date.now()}-${Math.random()}` }
      setApiFailure(failure)
      apiFailureTimer.current = window.setTimeout(() => {
        setApiFailure(null)
        apiFailureTimer.current = null
      }, 2000)
    }
    window.addEventListener(API_FAILURE_EVENT, onApiFailure)
    return () => {
      window.removeEventListener(API_FAILURE_EVENT, onApiFailure)
      window.clearTimeout(apiFailureTimer.current)
    }
  }, [])

  useEffect(() => {
    setApiFailure(null)
    window.clearTimeout(apiFailureTimer.current)
    apiFailureTimer.current = null
  }, [pathname])

  useEffect(() => {
    const checkAlerts = () => {
      const existingAlerts = Array.from(document.querySelectorAll([
        '[role="alert"]:not(.page-error-notice):not(.fm-lop-confirm):not(.fm-reset-confirm)',
        '[data-message-tone="error"]',
        '.sm-error', '.tt-error', '.em-alert', '.flm-error', '.fm-error',
        '.branch-api-error', '.course-api-error', '.cm-summary-error',
        '.hod-error-banner', '.rbac-load-error-strip', '.department-error',
        '.cm-empty--error', '.course-empty--error', '.workspace-context-select__error',
      ].join(',')))
        .filter((element) => element.getClientRects().length > 0)
      const messages = existingAlerts.map((element) => (element.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase())
      const nextDuplicates = toasts.filter((toast) => toast.type === 'error' && messages.some((message) => message.includes(toast.message.toLowerCase()))).map((toast) => toast.id)
      setDuplicates((current) => current.length === nextDuplicates.length && current.every((id, index) => id === nextDuplicates[index]) ? current : nextDuplicates)
      setHasInlineError((current) => current === (existingAlerts.length > 0) ? current : existingAlerts.length > 0)
    }
    checkAlerts()
    const observer = new MutationObserver(checkAlerts)
    observer.observe(document.getElementById('root') || document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [toasts, apiFailure])

  const visibleErrors = hasInlineError ? [] : errors.filter((toast) => !duplicates.includes(toast.id))
  const showApiFailure = apiFailure && !hasInlineError && !errors.length
  if (!visibleErrors.length && !showApiFailure) return null

  return <aside className="page-error-notices" aria-label="Page errors" data-no-print>
    {visibleErrors.map((toast) => <div className="page-error-notice" key={toast.id} role="alert">
      <FiAlertCircle aria-hidden="true" />
      <span>{toast.message}</span>
      <button type="button" aria-label="Dismiss error" onClick={() => dismissToast(toast.id)}><FiX aria-hidden="true" /></button>
    </div>)}
    {showApiFailure && <div className="page-error-notice" key={apiFailure.id} role="alert">
      <FiAlertCircle aria-hidden="true" />
      <span>{apiFailure.message}</span>
      <button type="button" aria-label="Dismiss error" onClick={() => setApiFailure(null)}><FiX aria-hidden="true" /></button>
    </div>}
  </aside>
}

export default function DashboardLayout({ children }) {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => localStorage.getItem('pirnav-sidebar-collapsed') === 'true')
  const [globalQuery, setGlobalQuery] = useState('')
  const [account, setAccount] = useState(() => ({
    name: localStorage.getItem('btech-user-name') || sessionStorage.getItem('btech-user-name') || '',
    identifier: localStorage.getItem('btech-user-id') || sessionStorage.getItem('btech-user-id') || '',
  }))
  const { canView } = useScreenAccess()
  const [theme, setTheme] = useState(() => localStorage.getItem('pirnav-theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'))

  const userRole = getUserRole() || 'user'
  const mustChangePassword = localStorage.getItem('btech-must-change-password') === 'true' || sessionStorage.getItem('btech-must-change-password') === 'true'
  const profileIncomplete = localStorage.getItem('btech-profile-completed') === 'false' || sessionStorage.getItem('btech-profile-completed') === 'false'
  useEffect(() => {
    if (mustChangePassword && !pathname.startsWith('/my-profile')) navigate('/my-profile?setup=1', { replace: true })
    else if (!mustChangePassword && profileIncomplete && pathname !== '/my-profile') navigate('/my-profile?profileSetup=1', { replace: true })
  }, [mustChangePassword, profileIncomplete, pathname, navigate])
  const roleLabel = ['admin', 'college_admin', 'super_admin'].includes(String(userRole).toLowerCase())
    ? 'Administrator'
    : userRole.charAt(0).toUpperCase() + userRole.slice(1)
  const pageName = ({
    '/dashboard': 'Overview', '/academic-structure': 'Academic Structure', '/my-profile': 'My Profile', '/settings': 'Settings',
    '/college-institution-management': 'College', '/academic-year-management': 'Academic Years',
    '/student-management/attendance': 'Student Attendance',
    '/department-management': 'Departments', '/semester-management': 'Semesters', '/section-management': 'Sections',
    '/student-management/admissions': 'Student Admissions',
    '/student-management/profiles': 'Student Profiles', '/student-management/promotions': 'Student Promotions',
  })[pathname] || (pathname.startsWith('/semester-management') ? 'Semesters' : pathname.startsWith('/section-management') ? 'Sections' : pathname.startsWith('/student-management/admissions') ? 'Student Admissions' : pathname.startsWith('/student-management/profiles') ? 'Student Profiles' : pathname.startsWith('/student-management/promotions') ? 'Student Promotions' : pathname.startsWith('/faculty/') ? pathname.startsWith('/faculty/attendance') ? 'Faculty Attendance' : 'Faculty Management' : pathname.startsWith('/courses') ? 'Courses' : pathname.startsWith('/branches') ? 'Branches' : 'Digital Campus')
  const breadcrumbSection = (userRole === 'admin' && adminWorkspaceForModule(findModuleForPath(pathname)?.id)?.label) || (['My Profile', 'Settings'].includes(pageName) ? 'Account' : pageName === 'Overview' ? 'Digital Campus' : pageName.startsWith('Student ') ? 'Student Management' : pageName.startsWith('Faculty ') ? 'Faculty' : 'Academic Configuration')
  const financeBreadcrumbs = feeBreadcrumbs(pathname)?.map(crumb => ({ ...crumb, label: ({ 'Fee Structures': 'Fee Plans', 'Student Accounts': 'Student Fees', 'Create Fee Structure': 'Create Fee Plan', 'Edit Fee Structure': 'Edit Fee Plan', 'Structure Details': 'Fee Plan Details' })[crumb.label] || crumb.label }))

  // Logout confirmation state
  const [showLogoutConfirmation, setShowLogoutConfirmation] = useState(false)
  const accountMenuRef = useRef(null)

  // Change password state
  const [open, setOpen] = useState(false)
  const [values, setValues] = useState(empty)
  const [errors, setErrors] = useToastState({}, 'error')
  const [visible, setVisible] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)

  const triggerRef = useRef(null)
  const closeRef = useRef(null)

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('pirnav-theme', theme)
  }, [theme])

  useEffect(() => {
    const syncTheme = event => { if (event.detail?.theme) setTheme(event.detail.theme) }
    window.addEventListener('pirnav-theme-change', syncTheme)
    return () => window.removeEventListener('pirnav-theme-change', syncTheme)
  }, [])

  useEffect(() => {
    if (pathname.startsWith('/faculty')) return undefined
    let active = true
    profileApi.getProfile()
      .then((profile) => { if (active) setAccount({ name: profile.fullName || '', identifier: profile.identifier || profile.admissionNumber || '' }) })
      .catch(() => {})
    return () => { active = false }
  }, [])

  const globalLinks = MODULE_REGISTRY.filter(module => module.navigation || module.id === 'my_profile')
  const globalResults = globalQuery.trim() ? globalLinks.filter(module => module.label.toLowerCase().includes(globalQuery.trim().toLowerCase()) && canView(module.path))
    .slice(0, 10).map(module => [module.label, module.path, module.permission?.module]) : []
  const rules = useMemo(
    () => requirements(values.newPassword),
    [values.newPassword]
  )

  const met = rules.filter((item) => item[1]).length

  const strength = !values.newPassword
    ? 'Not set'
    : met <= 2
      ? 'Weak'
      : met === 3
        ? 'Fair'
        : met === 4
          ? 'Good'
          : 'Strong'

  // -------------------------
  // Logout Actions
  // -------------------------
  const requestSignOut = () => {
    accountMenuRef.current?.removeAttribute('open')
    setShowLogoutConfirmation(true)
  }

  const handleSignOut = () => {
    signOut()
    sessionStorage.setItem('btech-logout-message', 'You have been signed out successfully.')
    navigate('/login', { replace: true })
  }

  // -------------------------
  // Change Password Actions
  // -------------------------
  const validate = (data = values) => {
    const next = {}

    if (!data.currentPassword) {
      next.currentPassword = 'Current password is required.'
    }

    if (!data.newPassword) {
      next.newPassword = 'New password is required.'
    } else if (!requirements(data.newPassword).every((item) => item[1])) {
      next.newPassword = 'Use all password requirements.'
    } else if (data.newPassword === data.currentPassword) {
      next.newPassword = 'New password must be different from current password.'
    }

    if (!data.confirmPassword) {
      next.confirmPassword = 'Confirm your new password.'
    } else if (data.confirmPassword !== data.newPassword) {
      next.confirmPassword = 'Passwords do not match.'
    }

    return next
  }

  const closeModal = () => {
    if (submitting) return

    setOpen(false)
    setValues(empty)
    setErrors({})
    setVisible({})
    setSuccess(false)

    setTimeout(() => {
      triggerRef.current?.focus()
    }, 0)
  }

  useEffect(() => {
    if (!open && !showLogoutConfirmation) return undefined

    if (open) closeRef.current?.focus()

    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        if (open) closeModal()
        if (showLogoutConfirmation) setShowLogoutConfirmation(false)
      }
    }


    return () => {
      window.removeEventListener('keydown', handleKeyDown)
    }
  }, [open, showLogoutConfirmation, submitting])

  const update = (event) => {
    const next = {
      ...values,
      [event.target.name]: event.target.value,
    }

    setValues(next)
    setErrors(previous => ({ ...previous, [event.target.name]: undefined }))
  }

  const submit = async (event) => {
    event.preventDefault()

    const next = validate()
    setErrors(next)

    if (Object.keys(next).length) return

    setSubmitting(true)
    setErrors({})
    try {
      await changePassword({
        currentPassword: values.currentPassword,
        newPassword: values.newPassword,
        confirmNewPassword: values.confirmPassword,
      })
      setValues(empty)
      signOut()
      sessionStorage.setItem('btech-logout-message', 'Password changed successfully. Please sign in with your new password.')
      navigate('/login', { replace: true })
    } catch (error) {
      setErrors({ currentPassword: error.message || 'Unable to change password. Please try again.' })
      setSuccess(false)
    } finally {
      setSubmitting(false)
    }
  }

  const field = (name, label, placeholder) => (
    <label className="password-modal__field">
      <span>{label}</span>

      <div>
        <input
          id={name}
          name={name}
          type={visible[name] ? 'text' : 'password'}
          value={values[name]}
          onChange={update}
          placeholder={placeholder}
          autoComplete={
            name === 'currentPassword' ? 'current-password' : 'new-password'
          }
          aria-invalid={Boolean(errors[name])}
          aria-describedby={errors[name] ? `${name}-error` : undefined}
        />

        <button
          type="button"
          onClick={() =>
            setVisible((current) => ({
              ...current,
              [name]: !current[name],
            }))
          }
          aria-label={`${visible[name] ? 'Hide' : 'Show'} ${label}`}
        >
          {visible[name] ? 'Hide' : 'Show'}
        </button>
      </div>

      {errors[name] && (
        <small id={`${name}-error`} role="alert">
          {errors[name]}
        </small>
      )}
    </label>
  )

  return (
    <div className={`dashboard-layout ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} collapsed={sidebarCollapsed} onToggleCollapse={() => setSidebarCollapsed(value => { const next = !value; localStorage.setItem('pirnav-sidebar-collapsed', String(next)); return next })} />

      <main>
        <header className="dashboard-header">
          <button type="button" className="mobile-navigation-toggle" aria-label="Open navigation" aria-expanded={sidebarOpen} onClick={() => setSidebarOpen(true)}><FiMenu aria-hidden="true" /></button>

          <div className="global-search"><FiSearch aria-hidden="true" /><input aria-label="Search modules" value={globalQuery} onChange={(event) => setGlobalQuery(event.target.value)} placeholder="Search" />{globalResults.length > 0 && <div className="global-search-results">{globalResults.map(([label, to]) => <Link to={to} key={to} onClick={() => setGlobalQuery('')}>{label}</Link>)}</div>}</div>

          <div className="dashboard-header__actions">
          <div className="dashboard-header__college">
            <span className="dashboard-header__college-label">College</span>
            <AcademicContextSelect kind="college" compact />
          </div>
          <HeaderAcademicYear />
          <ThemeColorPicker />

          <details className="account-menu" ref={accountMenuRef}>
            <summary aria-label="Open account menu">
              <span className="account-avatar">
                <FiUser aria-hidden="true" />
              </span>

              <span>
                <strong>{account.name || roleLabel}</strong>
                <small>{roleLabel}</small>
              </span>

              <i className="account-menu__chevron" aria-hidden="true" />
            </summary>

            <div className="account-menu__panel">
              <button type="button" onClick={() => navigate('/my-profile')}>
                <FiUser aria-hidden="true" />
                My Profile
              </button>

              <button
                ref={triggerRef}
                type="button"
                onClick={(event) => {
                  event.currentTarget
                    .closest('details')
                    ?.removeAttribute('open')
                  setOpen(true)
                }}
              >
                <FiLock aria-hidden="true" />
                Change Password
              </button>

              <button
                type="button"
                className="account-menu__signout"
                onClick={requestSignOut}
              >
                <FiLogOut aria-hidden="true" />
                Sign Out
              </button>
            </div>
          </details>
          </div>
        </header>

        <section className="page-content"><PageErrorNotices pathname={pathname} />{!(pathname === '/faculty' || pathname.startsWith('/faculty/')) && <nav className="app-breadcrumb" aria-label="Breadcrumb"><Link to="/dashboard">Home</Link>{financeBreadcrumbs ? financeBreadcrumbs.map((crumb, index) => <span className="app-breadcrumb__item" key={`${crumb.label}:${index}`}><span aria-hidden="true">/</span>{index === financeBreadcrumbs.length - 1 ? <strong>{crumb.label}</strong> : crumb.to ? <Link to={crumb.to}>{crumb.label}</Link> : <span>{crumb.label}</span>}</span>) : <><span aria-hidden="true">/</span><span>{breadcrumbSection}</span>{pageName !== breadcrumbSection && <><span aria-hidden="true">/</span><strong>{pageName}</strong></>}</>}</nav>}{children}</section>
        <DeactivationBlockedDialog />

        {/* Logout Confirmation Modal */}
        {showLogoutConfirmation && (
          <div
            className="logout-confirmation-backdrop"
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) {
                setShowLogoutConfirmation(false)
              }
            }}
          >
            <section
              className="logout-confirmation"
              role="dialog"
              aria-modal="true"
              aria-labelledby="logout-confirmation-title"
              aria-describedby="logout-confirmation-description"
            >
              <div className="logout-confirmation__icon" aria-hidden="true">
                <FiLogOut aria-hidden="true" />
              </div>

              <p className="logout-confirmation__eyebrow">Account access</p>
              <h2 id="logout-confirmation-title">Sign out of your account?</h2>
              <p id="logout-confirmation-description">
                You’ll need to sign in again to access your dashboard.
              </p>

              <div className="logout-confirmation__actions">
                <button
                  type="button"
                  className="logout-confirmation__cancel"
                  onClick={() => setShowLogoutConfirmation(false)}
                >
                  Stay signed in
                </button>

                <button
                  type="button"
                  className="logout-confirmation__confirm"
                  onClick={handleSignOut}
                >
                  Sign out
                </button>
              </div>
            </section>
          </div>
        )}

        {/* Change Password Modal */}
        {open && (
          <div
            className="password-modal-backdrop"
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) {
                closeModal()
              }
            }}
          >
            <section
              className="password-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="password-modal-title"
            >
              <button
                ref={closeRef}
                className="password-modal__close"
                onClick={closeModal}
                disabled={submitting}
                aria-label="Close change password dialog"
              >
                ×
              </button>

              {success ? (
                <div className="password-modal__success">
                  <span aria-hidden="true">✓</span>
                  <p>Security Settings</p>
                  <h2>Password Updated</h2>
                  <div>Your password has been changed successfully.</div>
                  <button
                    className="password-modal__primary"
                    onClick={closeModal}
                  >
                    Done
                  </button>
                </div>
              ) : (
                <>
                  <p className="password-modal__eyebrow">Security Settings</p>
                  <h2 id="password-modal-title">Change Password</h2>
                  <p className="password-modal__subtitle">
                    Keep your account secure by creating a strong new password.
                  </p>

                  <form onSubmit={submit} noValidate>
                    {field(
                      'currentPassword',
                      'Current Password',
                      'Enter current password'
                    )}

                    {field(
                      'newPassword',
                      'New Password',
                      'Create a new password'
                    )}

                    <div className="password-modal__strength">
                      <div>
                        <span>Password Strength</span>
                        <strong>{strength}</strong>
                      </div>
                      <i className={`level-${met}`} />
                      <ul>
                        {rules.map((item) => (
                          <li className={item[1] ? 'met' : ''} key={item[0]}>
                            <b>{item[1] ? '✓' : '○'}</b> {item[0]}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {field(
                      'confirmPassword',
                      'Confirm New Password',
                      'Confirm the new password'
                    )}

                    <footer>
                      <button
                        type="button"
                        onClick={closeModal}
                        disabled={submitting}
                      >
                        Cancel
                      </button>

                      <button
                        type="submit"
                        className="password-modal__primary"
                        disabled={submitting}
                      >
                        {submitting
                          ? 'Updating Password...'
                          : 'Update Password'}
                      </button>
                    </footer>
                  </form>
                </>
              )}
            </section>
          </div>
        )}
      </main>
    </div>
  )
}
