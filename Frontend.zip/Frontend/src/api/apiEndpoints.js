import { accountInvitationFailure, invitationDeliveryMessage } from '../utils/accountInvitationFailure.js'
import { GENERIC_ERROR_MESSAGE, userErrorMessage } from '../utils/userError.js'
import { collegeRequest } from '../utils/collegeRequest.js'
import { selectedCollegeId, createCollegeScope, collegeField } from '../utils/collegeScope.js'
import { markApiResult } from '../utils/exportProvenance.js'
import { readSubjectPages } from '../utils/subjectApiData'
import { getAccessToken, getAuthStorage, getRefreshToken, signOut } from '../auth/auth'
import { createApiUnavailableError, notifyApiUnavailable } from './apiFailureNotice'

if (typeof window !== 'undefined' && window.localStorage) {
  try {
    ['pirnav-local-admissions-v2', 'pirnav-local-student-profiles-v2', 'pirnav-department-hod-names-v1'].forEach(key => {
      localStorage.removeItem(key)
    })
  } catch { /* ignore */ }
}

const normalizeBaseUrl = (value = '') => value.trim().replace(/\/+$/, '')
const DEFAULT_API_BASE_URL = 'https://movable-swampland-tinderbox.ngrok-free.dev'

// Results endpoints are optional until the institution's result service is integrated.
export const RESULTS_API_ENABLED = String(import.meta.env.VITE_RESULTS_API_ENABLED || '').toLowerCase() === 'true'

export const API_BASE_URL = import.meta.env.DEV
  ? ''
  : normalizeBaseUrl(import.meta.env.VITE_API_BASE_URL || DEFAULT_API_BASE_URL)

// Keep local login on the same Vite /api proxy as the rest of the app. Using
// the old public tunnel directly in development makes login fail when that
// tunnel changes or is unavailable, even though the local proxy is configured.
const AUTH_LOGIN_URL = import.meta.env.DEV
  ? '/api/v1/auth/login'
  : normalizeBaseUrl(import.meta.env.VITE_AUTH_API_URL || `${DEFAULT_API_BASE_URL}/api/v1/auth/login`)
const hasConfiguredAuthLoginUrl = Boolean(AUTH_LOGIN_URL || API_BASE_URL)

const endpoint = (path) => `${API_BASE_URL}${path}`

export const SCREEN_EXPORT_ENDPOINTS = Object.freeze(Object.fromEntries([
  'colleges', 'college-settings', 'academic-years', 'academic-levels',
  'departments', 'courses', 'branches', 'semester', 'sections',
  'course-structures', 'students', 'student-profiles', 'student-admissions',
  'promotions', 'users', 'roles', 'faculty', 'fee-structures', 'hostel-fees', 'transport-fees',
].map(screen => {
  const prefix = ['college-settings', 'academic-levels', 'semester', 'roles'].includes(screen) ? '/api' : '/api/v1'
  return [screen, Object.freeze({ download: endpoint(`${prefix}/${screen}/download`), export: endpoint(`${prefix}/${screen}/export`) })]
})))

export class AuthRequestError extends Error {
  constructor(message, status = 0) {
    super(typeof userErrorMessage === 'function' ? userErrorMessage(message, status) : (message || 'Something went wrong. Please try again.'))
    this.name = 'AuthRequestError'
    this.status = status
  }
}

export const API_ENDPOINTS = Object.freeze({
  exports: Object.freeze({
    list: endpoint('/api/v1/exports'),
    screen: screen => endpoint(`/api/v1/exports/${encodeURIComponent(screen === 'semester' ? 'semesters' : screen)}`),
  }),
  auth: Object.freeze({
    login: AUTH_LOGIN_URL || endpoint('/api/v1/auth/login'),
    refresh: endpoint('/api/v1/auth/refresh'),
    changePassword: endpoint('/api/v1/auth/change-password'),
    forgotPassword: endpoint('/api/v1/auth/forgot-password'),
    completeAccountSetup: endpoint('/api/v1/auth/complete-account-setup'),
  }),
  profile: Object.freeze({
    get: endpoint('/api/v1/profile'),
    update: endpoint('/api/v1/profile'),
    photo: endpoint('/api/v1/profile/photo'),
  }),
  academicYears: Object.freeze({
    create: endpoint('/api/v1/academic-years'),
    list: endpoint('/api/v1/academic-years'),
    detail: (id) => endpoint(`/api/v1/academic-years/${id}`),
    update: (id) => endpoint(`/api/v1/academic-years/${id}`),
    activate: (id) => endpoint(`/api/v1/academic-years/${id}/activate`),
    deactivate: (id) => endpoint(`/api/v1/academic-years/${id}/deactivate`),
  }),
  branches: Object.freeze({
    create: endpoint('/api/v1/branches'),
    list: endpoint('/api/v1/branches'),
    byCourse: (courseId) => endpoint(`/api/v1/branches/course/${courseId}`),
    detail: (id) => endpoint(`/api/v1/branches/${id}`),
    update: (id) => endpoint(`/api/v1/branches/${id}`),
    status: (id) => endpoint(`/api/v1/branches/${id}/status`),
  }),
  courses: Object.freeze({
    list: endpoint('/api/v1/courses'),
    detail: (id) => endpoint(`/api/v1/courses/${id}`),
  }),
  departments: Object.freeze({
    list: endpoint('/api/v1/departments'),
  }),
  courseStructures: Object.freeze({
    create: endpoint('/api/v1/course-structures'),
    list: endpoint('/api/v1/course-structures'),
    byCourse: (courseId) => endpoint(`/api/v1/course-structures/course/${courseId}`),
    detail: (id) => endpoint(`/api/v1/course-structures/${id}`),
    update: (id) => endpoint(`/api/v1/course-structures/${id}`),
  }),
  sectionAssignments: Object.freeze({
    list: endpoint('/api/v1/section-assignments'),
    assign: (sectionId) => endpoint(`/api/v1/sections/${sectionId}/students`),
    remove: (sectionId, assignmentId) => endpoint(`/api/v1/sections/${sectionId}/students/${assignmentId}`),
  }),
  sections: Object.freeze({
    create: endpoint('/api/v1/sections'),
    list: endpoint('/api/v1/sections'),
    detail: (id) => endpoint(`/api/v1/sections/${id}`),
    update: (id) => endpoint(`/api/v1/sections/${id}`),
    remove: (id) => endpoint(`/api/v1/sections/${id}`),
    search: endpoint('/api/v1/sections/search'),
    status: (id) => endpoint(`/api/v1/sections/${id}/status`),
    validateCapacity: endpoint('/api/v1/sections/validate-capacity'),
    summary: endpoint('/api/v1/sections/summary'),
    classTeacher: (id) => endpoint(`/api/v1/sections/${id}/class-teacher`),
    classTeacherCandidates: (id) => endpoint(`/api/v1/sections/${id}/class-teacher-candidates`),
    studentCandidates: (id) => endpoint(`/api/v1/sections/${id}/student-candidates`),
    capacity: (id) => endpoint(`/api/v1/sections/${id}/capacity`),
    students: (id) => endpoint(`/api/v1/sections/${id}/students`),
    assignStudents: (id) => endpoint(`/api/v1/sections/${id}/students/assign`),
    student: (sectionId, studentId) => endpoint(`/api/v1/sections/${sectionId}/students/${studentId}`),
  }),
  studentAdmissions: Object.freeze({
    approve: (id) => endpoint(`/api/Admissions/${id}/approve`),
    list: endpoint('/api/v1/student-admissions'), create: endpoint('/api/v1/student-admissions'),
    detail: (id) => endpoint(`/api/v1/student-admissions/${id}`), update: (id) => endpoint(`/api/v1/student-admissions/${id}`),
    academicDetails: (id) => endpoint(`/api/v1/student-admissions/${id}/academic-details`),
    previousEducation: (id) => endpoint(`/api/v1/student-admissions/${id}/previous-education`),
    status: (id) => endpoint(`/api/v1/student-admissions/${id}/status`), submit: (id) => endpoint(`/api/v1/student-admissions/${id}/submit`),
    feeSummary: (id) => endpoint(`/api/v1/student-admissions/${id}/fee-summary`), feeStructure: (id) => endpoint(`/api/v1/student-admissions/${id}/fee-structure`),
    matchingFeePlans: endpoint('/api/v1/student-admissions/fee-plans'),
  }),
  academicFeePlans: Object.freeze({
    list: endpoint('/api/v1/academic-fee-plans'),
    create: endpoint('/api/v1/academic-fee-plans'),
    submit: (id, collegeId) => withQuery(endpoint(`/api/v1/academic-fee-plans/${encodeURIComponent(id)}/submit`), { collegeId }),
  }),
  feeConfiguration: Object.freeze({
    categories: endpoint('/api/v1/fee-categories'),
  }),
  studentAcademicInformation: Object.freeze({ detail: (id) => endpoint(`/api/v1/student-academic-information/${id}`), update: (id) => endpoint(`/api/v1/student-academic-information/${id}`) }),
  students: Object.freeze({
    list: endpoint('/api/v1/students'), create: endpoint('/api/v1/students'), search: endpoint('/api/v1/students/search'),
    detail: (id) => endpoint(`/api/v1/students/${id}`), update: (id) => endpoint(`/api/v1/students/${id}`), status: (id) => endpoint(`/api/v1/students/${id}/status`),
    parent: (id) => endpoint(`/api/student-parents/${id}`), documents: (id) => endpoint(`/api/v1/students/${id}/documents`),
    document: (studentId, documentId) => endpoint(`/api/v1/students/${studentId}/documents/${documentId}`),
    downloadDocument: (studentId, documentId) => endpoint(`/api/v1/students/${studentId}/documents/${documentId}/download`),
    personalInformation: (id) => endpoint(`/api/v1/students/${id}/profile/personal-information`), examResults: (id) => endpoint(`/api/v1/students/${id}/profile/exam-results`),
  }),
  studentProfiles: Object.freeze({ list: endpoint('/api/v1/student-profiles'), preview: (id) => endpoint(`/api/v1/student-profiles/${id}/preview`), update: (id) => endpoint(`/api/v1/student-profiles/${id}`), myProfile: endpoint('/api/StudentProfile/my-profile') }),
  faculty: Object.freeze({
    list: endpoint('/api/v1/faculty'),
    create: endpoint('/api/v1/faculty'),
    search: endpoint('/api/v1/faculty/search'),
    detail: (id) => endpoint(`/api/v1/faculty/${id}`),
    update: (id) => endpoint(`/api/v1/faculty/${id}`),
    workload: (id) => endpoint(`/api/v1/faculty/${id}/workload`),
    profilePhoto: (id) => endpoint(`/api/v1/faculty/${id}/profile-photo`),
    status: (id) => endpoint(`/api/v1/faculty/${id}/status`),
    statusHistory: (id) => endpoint(`/api/v1/faculty/${id}/status-history`),
    summary: endpoint('/api/v1/faculty/summary'),
  }),
  facultyProfiles: Object.freeze({
    detail: (facultyId) => endpoint(`/api/v1/faculty-profile/${facultyId}`),
    create: (facultyId) => endpoint(`/api/v1/faculty-profile/${facultyId}`),
    update: (facultyId) => endpoint(`/api/v1/faculty-profile/${facultyId}`),
  }),
  facultyDocuments: Object.freeze({
    list: (facultyId) => endpoint(`/api/v1/faculty-documents/faculty/${facultyId}`),
    upload: (facultyId) => endpoint(`/api/v1/faculty-documents/faculty/${facultyId}`),
    detail: (documentId) => endpoint(`/api/v1/faculty-documents/${documentId}`),
  }),
  facultySubjectAllocations: Object.freeze({
    list: endpoint('/api/v1/faculty-subject-allocations'),
    create: endpoint('/api/v1/faculty-subject-allocations'),
    detail: (allocationId) => endpoint(`/api/v1/faculty-subject-allocations/${allocationId}`),
  }),
  facultyAttendance: Object.freeze({
    list: endpoint('/api/v1/faculty-attendance'),
    create: endpoint('/api/v1/faculty-attendance'),
    detail: (attendanceId) => endpoint(`/api/v1/faculty-attendance/${attendanceId}`),
    update: (attendanceId) => endpoint(`/api/v1/faculty-attendance/${attendanceId}`),
    checkIn: (attendanceId) => endpoint(`/api/v1/faculty-attendance/${attendanceId}/check-in`),
    checkOut: (attendanceId) => endpoint(`/api/v1/faculty-attendance/${attendanceId}/check-out`),
    daily: endpoint('/api/v1/faculty-attendance/daily'),
    bulk: endpoint('/api/v1/faculty-attendance/bulk'),
    weekly: endpoint('/api/v1/faculty-attendance/reports/weekly'),
    monthly: endpoint('/api/v1/faculty-attendance/reports/monthly'),
    reports: endpoint('/api/v1/faculty-attendance/reports'),
    export: endpoint('/api/v1/faculty-attendance/export'),
  }),
  facultyLeave: Object.freeze({
    requests: endpoint('/api/v1/faculty-leave/requests'),
    request: id => endpoint('/api/v1/faculty-leave/requests/' + id),
    approve: id => endpoint('/api/v1/faculty-leave/requests/' + id + '/approve'),
    reject: id => endpoint('/api/v1/faculty-leave/requests/' + id + '/reject'),
    history: endpoint('/api/v1/faculty-leave/history'),
    balances: endpoint('/api/v1/faculty-leave/balances'),
    types: endpoint('/api/v1/faculty-leave/types'),
    type: id => endpoint('/api/v1/faculty-leave/types/' + id),
    policies: endpoint('/api/v1/faculty-leave/policies'),
    policy: id => endpoint('/api/v1/faculty-leave/policies/' + id),
    activate: id => endpoint('/api/v1/faculty-leave/policies/' + id + '/activate'),
    deactivate: id => endpoint('/api/v1/faculty-leave/policies/' + id + '/deactivate'),
  }),
  facultyPayroll: Object.freeze({
    list: endpoint('/api/v1/faculty-payroll'),
    detail: id => endpoint('/api/v1/faculty-payroll/' + id),
    salaries: endpoint('/api/v1/faculty-payroll/salary-records'),
    payslips: endpoint('/api/v1/faculty-payroll/payslips'),
    hold: id => endpoint('/api/v1/faculty-payroll/' + id + '/hold'),
    export: endpoint('/api/v1/faculty-payroll/export'),
  }),
  subjectManagementSubjects: Object.freeze({
    list: endpoint('/api/v1/subjects'),
    search: endpoint('/api/v1/subjects/search'),
    detail: id => endpoint(`/api/v1/subjects/${id}`),
    status: id => endpoint(`/api/v1/subject-management/subjects/${id}/status`),
    dependencies: id => endpoint(`/api/v1/subject-management/subjects/${id}/dependencies`),
    lookups: endpoint('/api/v1/subject-management/subjects/lookups'),
    summary: endpoint('/api/v1/subject-management/subjects/summary'),
    export: endpoint('/api/v1/subject-management/subjects/export'),
    download: endpoint('/api/v1/subject-management/subjects/download'),
  }),
  studentAttendance: Object.freeze({
    list: endpoint('/api/v1/student-attendance/sessions'),
    create: endpoint('/api/v1/student-attendance/sessions'),
    detail: (sessionId) => endpoint(`/api/v1/student-attendance/sessions/${sessionId}`),
    students: (sessionId) => endpoint(`/api/v1/student-attendance/sessions/${sessionId}/students`),
    mark: (sessionId) => endpoint(`/api/v1/student-attendance/sessions/${sessionId}/mark`),
    status: (sessionId) => endpoint(`/api/v1/student-attendance/sessions/${sessionId}/status`),
    daily: endpoint('/api/v1/student-attendance/reports/daily'),
    subjectReport: endpoint('/api/v1/student-attendance/reports/subject'),
    monthly: endpoint('/api/v1/student-attendance/reports/monthly'),
  }),
  credits: Object.freeze({
    dashboard: endpoint('/api/v1/credits/dashboard'),
    configurations: endpoint('/api/v1/credits/configurations'),
    configuration: id => endpoint(`/api/v1/credits/configurations/${id}`),
    registrations: endpoint('/api/v1/credits/registrations'),
    registration: id => endpoint(`/api/v1/credits/registrations/${id}`),
    summary: endpoint('/api/v1/credits/summary'),
  }),
  electives: Object.freeze({
    groups: endpoint('/api/v1/electives/groups'),
    groupSubjects: id => endpoint(`/api/v1/electives/groups/${id}/subjects`),
    studentSelections: id => endpoint(`/api/v1/students/${id}/electives`),
    approvals: endpoint('/api/v1/elective-approvals'),
    approval: id => endpoint(`/api/v1/elective-approvals/${id}`),
    allocations: endpoint('/api/v1/elective-allocations'),
    allocation: id => endpoint(`/api/v1/elective-allocations/${id}`),
  }),
  results: Object.freeze({
    list: endpoint('/api/v1/results'),
    create: endpoint('/api/v1/results'),
    transcript: (studentId) => endpoint(`/api/v1/results/students/${studentId}/transcript`),
  }),
  marks: Object.freeze({
    list: endpoint('/api/v1/marks'),
    detail: id => endpoint(`/api/v1/marks/${id}`),
    bulkPreview: endpoint('/api/v1/marks/bulk/preview'),
    bulkUpload: endpoint('/api/v1/marks/bulk/upload'),
    bulkFilePreview: endpoint('/api/v1/marks/bulk/file-preview'),
    summaryReport: endpoint('/api/v1/marks/reports/summary'),
    studentReport: endpoint('/api/v1/marks/reports/student'),
    subjectReport: endpoint('/api/v1/marks/reports/subjects'),
    pendingApprovals: endpoint('/api/v1/marks/approvals/pending'),
    updateApproval: id => endpoint(`/api/v1/marks/approvals/${id}`),
    workflow: action => endpoint(`/api/v1/marks/workflow/${action}`),
    approvalHistory: id => endpoint(`/api/v1/marks/${id}/approval-history`),
    download: endpoint('/api/v1/marks/download'),
    export: endpoint('/api/v1/marks/export'),
  }),
  promotions: Object.freeze({
    dashboard: endpoint('/api/v1/promotions/dashboard'), directory: endpoint('/api/v1/promotions/directory'), history: endpoint('/api/v1/promotions/history'),
    eligibleStudents: endpoint('/api/v1/promotions/eligible-students'), eligibility: (id) => endpoint(`/api/v1/promotions/student-eligibility/${id}`), eligibilityStatus: (id) => endpoint(`/api/v1/promotions/eligibility-status/${id}`),
    promote: endpoint('/api/v1/promotions/promote'), promoteBulk: endpoint('/api/v1/promotions/promote-bulk'), promoteBulkAtomic: endpoint('/api/v1/promotions/promote-bulk-atomic'), promotedStudents: endpoint('/api/v1/promotions/promoted-students'),
    studentHistory: (id) => endpoint(`/api/v1/promotions/student/${id}/history`), historyByStudent: (id) => endpoint(`/api/v1/promotions/history/${id}`),
  }),
  authorizationTest: Object.freeze({
    authenticated: endpoint('/api/v1/authorization-test/authenticated'),
    admin: endpoint('/api/v1/authorization-test/admin'),
    faculty: endpoint('/api/v1/authorization-test/faculty'),
    student: endpoint('/api/v1/authorization-test/student'),
    adminFaculty: endpoint('/api/v1/authorization-test/admin-faculty'),
  }),
  roles: Object.freeze({
    list: endpoint('/api/roles'),
    create: endpoint('/api/roles'),
    detail: (id) => endpoint(`/api/roles/${id}`),
    update: (id) => endpoint(`/api/roles/${id}`),
    delete: (id) => endpoint(`/api/roles/${id}`),
  }),
  rooms: Object.freeze({
    list: endpoint('/api/v1/rooms'),
    create: endpoint('/api/v1/rooms'),
    options: endpoint('/api/v1/rooms/options'),
    detail: (classroomId) => endpoint(`/api/v1/rooms/${classroomId}`),
    update: (classroomId) => endpoint(`/api/v1/rooms/${classroomId}`),
    delete: (classroomId) => endpoint(`/api/v1/rooms/${classroomId}`),
    allocation: (classroomId) => endpoint(`/api/v1/rooms/${classroomId}/allocation`),
  }),
})

const readBody = async (response) => {
  try { return await response.json() } catch { return null }
}

const extractListResponse = (response) => {
  let current = response
  for (let depth = 0; depth < 5 && current && typeof current === 'object'; depth += 1) {
    if (Array.isArray(current)) return current
    const list = current.items ?? current.content ?? current.results ?? current.records ?? current.academicYears ?? current.years ?? current.rows ?? current.roles ?? current.users ?? current.userList ?? (Array.isArray(current.data) ? current.data : undefined)
    if (Array.isArray(list)) return list
    current = current.data ?? current.result ?? current.payload
  }
  return null
}
const listResponse = (response) => extractListResponse(response) ?? []

const validationMessage = (body) => {
  const errors = body?.errors || body?.data?.errors
  if (errors && typeof errors === 'object') {
    const messages = Object.entries(errors).flatMap(([field, value]) => (Array.isArray(value) ? value : [value]).filter((message) => typeof message === 'string').map((message) => field === '$' ? message : `${field}: ${message}`))
    if (messages.length) return messages.join(' ')
  }
  return body?.message || body?.detail || body?.title || body?.data?.message || body?.data?.detail || body?.data?.title || ''
}

let refreshRequestInFlight = null

const refreshAccessToken = async () => {
  if (refreshRequestInFlight) return refreshRequestInFlight

  const refreshToken = getRefreshToken()
  if (!refreshToken) {
    signOut()
    if (typeof window !== 'undefined') window.location.replace('/login')
    throw new AuthRequestError('Your session has expired. Please sign in again.', 401)
  }

  refreshRequestInFlight = (async () => {
    let response
    try {
      response = await fetch(API_ENDPOINTS.auth.refresh, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' },
        body: JSON.stringify({ refreshToken }),
      })
    } catch {
      throw createApiUnavailableError()
    }
    if (response.status >= 500) notifyApiUnavailable({ status: response.status, url: API_ENDPOINTS.auth.refresh, method: 'POST', response })

    const body = await readBody(response)
    if (!response.ok || !body?.data?.accessToken) {
      signOut()
      if (typeof window !== 'undefined') window.location.replace('/login')
      throw new AuthRequestError(body?.message || 'Your session has expired. Please sign in again.', response.status || 401)
    }

    const storage = getAuthStorage()
    storage.setItem('btech-access-token', body.data.accessToken)
    if (body.data.refreshToken) storage.setItem('btech-refresh-token', body.data.refreshToken)

    return body.data.accessToken
  })()

  try {
    return await refreshRequestInFlight
  } finally {
    refreshRequestInFlight = null
  }
}

const pendingGetRequests = new Map()
const request = async (url, options = {}, retried = false, bypassDedupe = false, suppressApiFailureNotice = false) => {
  suppressApiFailureNotice = suppressApiFailureNotice || options.suppressApiFailureNotice === true
  if (options.suppressApiFailureNotice !== undefined) {
    options = { ...options }
    delete options.suppressApiFailureNotice
  }
  if (!retried && !bypassDedupe && typeof collegeRequest === 'function') ({ url, options } = collegeRequest(url, options))
  const method = String(options.method || 'GET').toUpperCase()
  if (method === 'GET' && !bypassDedupe) {
    const key = `${getAccessToken()}:${method}:${url}`
    if (pendingGetRequests.has(key)) return pendingGetRequests.get(key)
    const pending = request(url, options, retried, true, suppressApiFailureNotice).finally(() => pendingGetRequests.delete(key))
    pendingGetRequests.set(key, pending)
    return pending
  }
  const token = getAccessToken()
  let response
  try {
    response = await fetch(url, {
      ...options,
      headers: { 'ngrok-skip-browser-warning': 'true', ...options.headers, ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    })
  } catch {
    throw createApiUnavailableError(0, !suppressApiFailureNotice)
  }
  if (response.status === 401 && !retried && url !== API_ENDPOINTS.auth.refresh) {
    await refreshAccessToken()
    return request(url, options, true, true, suppressApiFailureNotice)
  }
  const body = await readBody(response)
  if (!response.ok || body?.success === false) {
    // Some read APIs are deliberately optional. Their callers can provide the
    // statuses that mean "no related record yet" so an expected absence does
    // not look like a failed request in the browser console.
    const silentStatuses = Array.isArray(options.silentStatuses) ? options.silentStatuses : []
    if (!silentStatuses.includes(response.status)) {
      console.error('API request failed', { url, method: options.method || 'GET', status: response.status })
    }
    const deliveryFailure = /\/api\/v1\/admin\/users\/(?:onboard-college|[0-9]+\/resend-invitation)(?:[?#]|$)/.test(url) ? accountInvitationFailure(body) : null
    if (deliveryFailure) {
      const error = new Error(invitationDeliveryMessage(deliveryFailure))
      error.status = response.status
      error.code = deliveryFailure.code
      error.invitationFailure = deliveryFailure
      error.correlationId = deliveryFailure.correlationId
      throw error
    }
    if (response.status >= 500) {
      if (!suppressApiFailureNotice) notifyApiUnavailable({ status: response.status, url, method, body, response })
      const genericMsg = typeof GENERIC_ERROR_MESSAGE !== 'undefined' ? GENERIC_ERROR_MESSAGE : 'Something went wrong. Please try again.'
      const error = new Error(url.includes('/api/v1/timetable-management') ? validationMessage(body) || genericMsg : genericMsg)
      error.status = response.status
      error.backendMessage = validationMessage(body)
      error.correlationId = typeof body?.correlationId === 'string' ? body.correlationId : undefined
      throw error
    }
    const genericMsg = typeof GENERIC_ERROR_MESSAGE !== 'undefined' ? GENERIC_ERROR_MESSAGE : 'Something went wrong. Please try again.'
    const fallback = {
      400: 'Please check the submitted information.',
      401: 'Your session has expired. Please sign in again.',
      403: "You don't have permission to update this profile.",
      404: 'Record not found.',
      409: 'The email or mobile number is already in use.',
      422: 'Some submitted values are invalid.',
      500: genericMsg,
    }[response.status] || 'The request could not be completed.'
    const backendMessage = validationMessage(body) || fallback
    const error = new Error(url.includes('/api/v1/timetable-management') ? backendMessage : (typeof userErrorMessage === 'function' ? userErrorMessage(backendMessage, response.status) : backendMessage))
    error.status = response.status
    error.validationErrors = body?.errors && typeof body.errors === 'object' ? body.errors : undefined
    error.code = typeof body?.code === 'string' ? body.code : undefined
    error.backendMessage = backendMessage
    error.correlationId = typeof body?.correlationId === 'string' ? body.correlationId : undefined
    throw error
  }
  return body
}

const requiredId = (value, label) => {
  if (value === undefined || value === null || String(value).trim() === '') throw new Error(`${label} is required.`)
  return encodeURIComponent(String(value).trim())
}
const withQuery = (url, params = {}) => {
  const query = new URLSearchParams(Object.entries(params || {}).filter(([, value]) => value !== '' && value !== undefined && value !== null))
  return query.size ? `${url}?${query}` : url
}
// Reuse authenticated transport in the campus and examination integrations.
export { request as authenticatedRequest }
const dataResponse = (response) => response?.data?.data ?? response?.data ?? response ?? null
const listData = (response) => listResponse(response)

const blobRequest = async (url, options = {}, retried = false) => {
  const token = getAccessToken()
  let response
  try { response = await fetch(url, { ...options, headers: { 'ngrok-skip-browser-warning': 'true', ...options.headers, ...(token ? { Authorization: `Bearer ${token}` } : {}) } }) }
  catch { throw createApiUnavailableError() }
  if (response.status === 401 && !retried && url !== API_ENDPOINTS.auth.refresh) { await refreshAccessToken(); return blobRequest(url, options, true) }
  if (!response.ok) {
    const body = await readBody(response)
    if (response.status >= 500) notifyApiUnavailable({ status: response.status, url, method: options.method || 'GET', body, response })
    throw new AuthRequestError(response.status >= 500 ? GENERIC_ERROR_MESSAGE : validationMessage(body) || 'The download request could not be completed.', response.status)
  }
  return { blob: await response.blob(), contentDisposition: response.headers.get('content-disposition') || '', contentType: response.headers.get('content-type') || '' }
}

export const screenExportsApi = {
  list: params => request(withQuery(API_ENDPOINTS.exports.list, params)),
  getScreen: (screen, params) => {
    if (!String(screen || '').trim()) throw new Error('Screen is required.')
    return readExportFile(withQuery(API_ENDPOINTS.exports.screen(screen), params))
  },
  download: (screen, params) => requestScreenFile(screen, 'download', params),
  export: (screen, params) => requestScreenFile(screen, 'export', params),
  save: async (screen, params) => {
    for (const action of ['export', 'download']) {
      try { return await requestScreenFile(screen, action, params) }
      catch (error) { if (![404, 405].includes(error.status)) throw error }
    }
    return screenExportsApi.getScreen(screen, params)
  },
}

export const userDirectoryApi = {
  getAll: async (params = {}) => {
    const response = await request(withQuery(endpoint('/api/v1/admin/users'), params))
    const rows = extractListResponse(response)
    if (!rows) throw new Error('The user directory returned an unexpected response.')
    return rows.map(row => {
      const roles = row.roleNames ?? row.roles ?? row.roleCodes ?? (row.roleName ? [row.roleName] : [])
      const accountStatus = row.accountStatus ?? row.statusLabel ?? (
        row.deletedAt ? 'Deactivated' :
          row.status === 1 || row.status === true || String(row.status).toLowerCase() === 'active' ? 'Active' :
            row.mustChangePassword ? 'Pending Invitation' : 'Suspended'
      )
      return {
        ...row,
        roleId: row.roleId ?? row.roleIds?.[0] ?? '',
        roleName: Array.isArray(roles) ? roles.join(', ') : String(roles || ''),
        accountStatus,
        academicYearIds: row.academicYearIds ?? [],
        permissions: row.permissions ?? {},
      }
    })
  },
  lookups: async collegeId => (await request(withQuery(endpoint('/api/v1/admin/users/lookups'), collegeId ? { collegeId } : {})))?.data,
  onboardCollege: body => request(endpoint('/api/v1/admin/users/onboard-college'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
  getRolePermissions: async roleId => (await request(endpoint(`/api/v1/access-governance/roles/${encodeURIComponent(roleId)}/permissions`)))?.data ?? {},
  create: body => request(endpoint('/api/v1/admin/users'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
  update: (id, body) => request(endpoint(`/api/v1/admin/users/${encodeURIComponent(id)}`), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
  setStatus: (id, status) => request(endpoint(`/api/v1/admin/users/${encodeURIComponent(id)}/status`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) }),
  invitations: async (params = {}) => {
    const response = await request(withQuery(endpoint('/api/v1/admin/users/invitations'), params))
    const rows = extractListResponse(response)
    if (!rows) throw new Error('The invitation list returned an unexpected response.')
    return rows
  },
  resendInvitation: id => request(endpoint(`/api/v1/admin/users/${encodeURIComponent(id)}/resend-invitation`), { method: 'POST' }),
  resetPassword: id => request(endpoint(`/api/v1/admin/users/${encodeURIComponent(id)}/reset-password`), { method: 'POST' }),
  activity: async (id, params = {}) => (await request(withQuery(endpoint(`/api/v1/admin/users/${encodeURIComponent(id)}/activity`), params)))?.data ?? [],
  exportCsv: params => screenExportsApi.download('users', { Format: 'csv', ...params }),
}

export const authAccessApi = {
  get: async collegeId => (await request(withQuery(endpoint('/api/auth/me/access'), collegeId ? { collegeId } : {})))?.data,
}

export async function completeAccountSetup({ loginId, token, newPassword, confirmNewPassword }) {
  // Public one-time-link operation: never attach an old account's session or
  // refresh/sign out another session when an invitation is rejected.
  let response
  try {
    response = await fetch(API_ENDPOINTS.auth.completeAccountSetup, { method: 'POST', headers: { 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' }, body: JSON.stringify({ loginId, token, newPassword, confirmNewPassword }) })
  } catch { throw new AuthRequestError('Account setup could not be reached. Check your connection and try again.') }
  const body = await readBody(response)
  const unconfirmed = 'Account activation was not confirmed. Open the latest invitation email or ask your administrator to resend it.'
  if (!response.ok || body?.success === false) throw new AuthRequestError(validationMessage(body) || unconfirmed, response.status)
  if (body?.success !== true) throw new AuthRequestError(unconfirmed, response.status)
  return body
}

async function requestScreenFile(screen, action, params) {
  const routes = SCREEN_EXPORT_ENDPOINTS[screen]
  if (!routes) throw new Error('This screen does not support server exports.')
  return readExportFile(withQuery(routes[action], params))
}

async function readExportFile(url) {
  const result = await blobRequest(url)
  if (/json|text\/html/i.test(result.contentType)) {
    let body
    try { body = JSON.parse(await result.blob.text()) } catch { /* Unexpected gateway page. */ }
    throw new Error(validationMessage(body) || 'The server did not return an export file.')
  }
  if (!result.blob.size) throw new Error('The server did not return an export file.')
  return result
}

const normalizeFrontendRole = (roleValue) => {
  const rawRole = Array.isArray(roleValue) ? roleValue.find(role => ['super_admin','superadmin','admin','college_admin','collegeadmin'].includes(String(role).trim().toLowerCase().replace(/[\s-]+/g, '_'))) || roleValue[0] : roleValue
  const normalized = String(rawRole || '').trim().toLowerCase().replace(/[\s-]+/g, '_')

  if (['admin', 'college_admin', 'super_admin', 'collegeadmin', 'superadmin'].includes(normalized)) {
    return 'admin'
  }

  if (['principal','hod','accountant','librarian','non_teaching','non_teaching_staff'].includes(normalized)) return 'staff'

  return normalized || 'student'
}

export async function login({ identifier, password, rememberMe = false }) {
  if (!hasConfiguredAuthLoginUrl) {
    throw new AuthRequestError('Sign in is temporarily unavailable. Please try again later.')
  }

  let response
  try {
    response = await fetch(API_ENDPOINTS.auth.login, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'ngrok-skip-browser-warning': 'true',
      },
      body: JSON.stringify({ loginId: identifier, password, rememberMe: Boolean(rememberMe) }),
    })
  } catch {
    notifyApiUnavailable()
    throw new AuthRequestError('We’re having trouble signing you in right now. Please try again shortly.')
  }
  const body = await readBody(response)
  if (!response.ok || body?.success === false) {
    if (response.status >= 500) notifyApiUnavailable({ status: response.status, url: API_ENDPOINTS.auth.login, method: 'POST', body, response })
    const message = response.status === 401
      ? 'The email, mobile number, or password is incorrect.'
      : response.status === 429
        ? 'Too many sign-in attempts. Please wait a moment and try again.'
        : 'We couldn’t sign you in right now. Please try again.'
    throw new AuthRequestError(message, response.status || 400)
  }
  const data = body?.data
  if (!data?.accessToken || !data?.refreshToken) throw new AuthRequestError('We couldn’t complete sign in. Please try again.')

  const roleValue = data.roles ?? data.role
  return {
    ...data,
    roles: Array.isArray(roleValue) ? roleValue : roleValue ? [roleValue] : [],
    user: {
      id: data.userId,
      name: data.fullName,
      role: normalizeFrontendRole(roleValue),
      collegeId: data.collegeId,
      mustChangePassword: data.mustChangePassword,
      profileCompleted: data.profileCompleted !== false,
    },
  }
}

export async function changePassword({ currentPassword, newPassword, confirmNewPassword }) {
  return request(API_ENDPOINTS.auth.changePassword, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ currentPassword, newPassword, confirmNewPassword }),
  })
}

const normalizeProfile = (source) => {
  const data = source && typeof source === 'object' ? source : {}
  const academic = data.academic && typeof data.academic === 'object' ? data.academic : {}
  const application = data.application && typeof data.application === 'object' ? data.application : {}
  const lastLoginAt = data.lastLoginAt ?? data.last_login_at ?? data.LastLoginAt ?? data.lastLogin ?? data.last_login ?? ''
  return {
    id: data.userId ?? data.studentId ?? '', facultyId: data.facultyId ?? '', identifier: data.employeeUserId ?? data.studentCode ?? data.studentId ?? '', fullName: data.fullName ?? data.studentName ?? '', collegeName: data.collegeName ?? '', collegeType: data.collegeType ?? '', universityName: data.universityName ?? '', collegeEmail: data.collegeEmail ?? '', collegeMobile: data.collegeMobile ?? '', collegePhone: data.collegePhone ?? '', collegeAddressLine1: data.collegeAddressLine1 ?? '', collegeAddressLine2: data.collegeAddressLine2 ?? '', collegeCity: data.collegeCity ?? '', collegeDistrict: data.collegeDistrict ?? '', collegeState: data.collegeState ?? '', collegeCountry: data.collegeCountry ?? '', collegePincode: data.collegePincode ?? '', collegeWebsite: data.collegeWebsite ?? '', profileImagePath: data.profileImagePath ?? '',
    email: data.email ?? '', mobile: data.mobile ?? '', role: Array.isArray(data.roles) ? data.roles.join(', ') : String(data.role ?? ''),
    dateOfBirth: data.dateOfBirth ?? '', gender: data.gender ?? '', department: data.department ?? data.departmentName ?? '', departmentId: data.departmentId ?? '',
    designation: data.designation ?? '', houseNumber: data.houseNumber ?? data.currentHouseNumber ?? '', address: data.address ?? data.currentAddress ?? '', permanentHouseNumber: data.permanentHouseNumber ?? '', permanentAddress: data.permanentAddress ?? '', postalCode: data.postalCode ?? '',
    pincode: data.pincode ?? data.postalCode ?? '', city: data.city ?? '', district: data.district ?? '', state: data.state ?? '', permanentPincode: data.permanentPincode ?? '', permanentCity: data.permanentCity ?? '', permanentDistrict: data.permanentDistrict ?? '', permanentState: data.permanentState ?? '', bio: data.bio ?? data.aboutMe ?? '',
    lastLoginAt,
    updatedAt: data.updatedAt ?? '',
    status: data.status ?? (data.accountStatus === 1 || data.accountStatus === undefined ? 'Active' : 'Inactive'),
    accountStatus: data.accountStatus ?? 1, collegeId: data.collegeId ?? '', mustChangePassword: Boolean(data.mustChangePassword), profileCompleted: data.profileCompleted !== false,
    registrationNumber: data.registrationNumber ?? application.registrationNumber ?? application.number ?? '', admissionNumber: data.admissionNumber ?? application.admissionNumber ?? '',
    rollNumber: data.rollNumber ?? academic.rollNumber ?? '', course: data.course ?? data.courseName ?? academic.course ?? '', branch: data.branch ?? data.branchName ?? academic.branch ?? '',
    academicYear: data.academicYear ?? data.academicYearName ?? academic.academicYear ?? '', semester: data.semester ?? data.semesterName ?? academic.semester ?? '', section: data.section ?? data.sectionName ?? academic.section ?? '', batch: data.batch ?? academic.batch ?? '',
  }
}

export const profileApi = {
  getProfile: async () => {
    const response = await request(API_ENDPOINTS.profile.get)
    if (!response?.data) throw new Error('We couldn’t load your profile right now. Please try again.')
    return { ...normalizeProfile(response.data), profileCompleted: response.data.profileCompleted ?? response.data.isProfileCompleted }
  },
  updateProfile: async (profile) => {
    const response = await request(API_ENDPOINTS.profile.update, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fullName: String(profile.fullName || '').trim(),
        email: String(profile.email || '').trim(),
        mobile: String(profile.mobile || '').trim(),
        dateOfBirth: profile.dateOfBirth || null,
        gender: profile.gender || null,
        departmentId: profile.departmentId ? Number(profile.departmentId) : null,
        designation: String(profile.designation || '').trim() || null,
        collegeType: String(profile.collegeType || '').trim() || null,
        universityName: String(profile.universityName || '').trim() || null,
        collegeEmail: String(profile.collegeEmail || '').trim() || null,
        collegeMobile: String(profile.collegeMobile || '').trim() || null,
        collegePhone: String(profile.collegePhone || '').trim() || null,
        collegeAddressLine1: String(profile.collegeAddressLine1 || '').trim() || null,
        collegeAddressLine2: String(profile.collegeAddressLine2 || '').trim() || null,
        collegeCity: String(profile.collegeCity || '').trim() || null,
        collegeDistrict: String(profile.collegeDistrict || '').trim() || null,
        collegeState: String(profile.collegeState || '').trim() || null,
        collegeCountry: String(profile.collegeCountry || '').trim() || null,
        collegePincode: String(profile.collegePincode || '').trim() || null,
        collegeWebsite: String(profile.collegeWebsite || '').trim() || null,
        houseNumber: String(profile.houseNumber || '').trim() || null,
        address: String(profile.address || '').trim() || null,
        permanentHouseNumber: String(profile.permanentHouseNumber || '').trim() || null,
        permanentAddress: String(profile.permanentAddress || '').trim() || null,
        permanentPincode: String(profile.permanentPincode || '').trim() || null,
        permanentCity: String(profile.permanentCity || '').trim() || null,
        permanentDistrict: String(profile.permanentDistrict || '').trim() || null,
        permanentState: String(profile.permanentState || '').trim() || null,
        permanentCountry: String(profile.permanentCountry || '').trim() || null,
        pincode: String(profile.pincode || profile.postalCode || '').trim() || null,
        city: String(profile.city || '').trim() || null,
        district: String(profile.district || '').trim() || null,
        state: String(profile.state || '').trim() || null,
        aboutMe: String(profile.bio || profile.aboutMe || '').trim() || null,
      }),
    })
    const data = response?.data || {}
    return { ...normalizeProfile(data), profileCompleted: data.profileCompleted ?? data.isProfileCompleted }
  },
  uploadPhoto: async file => {
    const form = new FormData()
    form.append('file', file)
    const response = await request(API_ENDPOINTS.profile.photo, { method: 'POST', body: form })
    return response?.data?.profileImagePath || ''
  },
}

const academicYearPayload = (year) => {
  const name = String(year.name || year.academicYearName || year.AcademicYearName || '').trim()
  const rawStart = year.startDate ?? year.StartDate ?? year.start_date ?? year.fromDate ?? year.FromDate ?? ''
  const rawEnd = year.endDate ?? year.EndDate ?? year.end_date ?? year.toDate ?? year.ToDate ?? ''
  const normalize = (val) => {
    if (!val) return ''
    const str = String(val).trim()
    const match = str.match(/^(\d{4}-\d{2}-\d{2})/)
    if (match) return match[1]
    const dmy = str.match(/^(\d{2})[-/](\d{2})[-/](\d{4})/)
    if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`
    const d = new Date(str)
    return isNaN(d.getTime()) ? str.slice(0, 10) : d.toISOString().slice(0, 10)
  }
  return {
    academicYearName: name,
    startDate: normalize(rawStart),
    endDate: normalize(rawEnd),
  }
}

const normalizeAcademicYearRecord = (year = {}) => {
  const id = year.academicYearId ?? year.AcademicYearId ?? year.id ?? year.Id ?? ''
  const name = year.academicYearName ?? year.AcademicYearName ?? year.name ?? year.Name ?? year.academicYear ?? ''
  const startDate = year.startDate ?? year.StartDate ?? year.start_date ?? year.fromDate ?? year.FromDate ?? ''
  const endDate = year.endDate ?? year.EndDate ?? year.end_date ?? year.toDate ?? year.ToDate ?? ''
  const rawStatus = year.status ?? year.Status ?? year.academicYearStatus ?? year.AcademicYearStatus ?? ''
  const status = String(rawStatus).trim().toLowerCase()
  const rawActive = year.isActive ?? year.IsActive ?? year.is_active
  const rawCurrent = year.isCurrent ?? year.IsCurrent
  const activeFlag = rawActive === true || Number(rawActive) === 1 || ['true', 'active', 'current'].includes(String(rawActive ?? '').trim().toLowerCase())
  const currentFlag = rawCurrent === true || Number(rawCurrent) === 1 || String(rawCurrent ?? '').trim().toLowerCase() === 'true'
  const today = new Date()
  const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
  const dateCurrent = Boolean(startDate && endDate && todayKey >= String(startDate).slice(0, 10) && todayKey <= String(endDate).slice(0, 10))
  const hasActiveValue = rawActive !== undefined && rawActive !== null && rawActive !== ''
  const isInactive = rawActive === false || String(rawActive ?? '').trim().toLowerCase() === 'false' || (hasActiveValue && Number(rawActive) === 0) || ['0', 'false', 'inactive', 'deactive', 'deactivated', 'disabled', 'archived'].includes(status) || Number(year.isArchived ?? year.IsArchived) === 1 || Boolean(year.deletedAt ?? year.DeletedAt)
  const isCurrent = !isInactive && (activeFlag || currentFlag || ['active', 'current', '1'].includes(status) || dateCurrent)
  return {
    ...year,
    id: id === null || id === undefined ? '' : String(id),
    academicYearId: id,
    name: String(name ?? '').trim(),
    academicYearName: String(name ?? '').trim(),
    backendStatus: rawStatus,
    startDate,
    endDate,
    status: isCurrent ? 'Active' : isInactive ? 'Inactive' : rawStatus,
    isActive: isCurrent ? true : isInactive ? false : rawActive,
    isCurrent,
  }
}

export const academicYearApi = {
  getAll: async (options = {}) => {
    const collegeId = selectedCollegeId()
    if (!collegeId) return []
    const response = await request(withQuery(API_ENDPOINTS.academicYears.list, { collegeId }), options)
    if (selectedCollegeId() !== collegeId) return []
    const years = listResponse(response).map(normalizeAcademicYearRecord)
    const scopedYears = createCollegeScope(collegeId)(years)
    const allYearsUnmapped = years.length > 0 && years.every(year => !collegeField(year, 'college'))
    if (allYearsUnmapped) return years
    if (!scopedYears.length && years.some(year => !collegeField(year, 'college'))) {
      throw new Error('Existing academic years have no college mapping. Apply the college academic-year database migration and update the backend before generating another year.')
    }
    return scopedYears
  },
  getById: async (id) => {
    const response = await request(API_ENDPOINTS.academicYears.detail(id))
    return response?.data
  },
  create: async (year) => {
    const response = await request(API_ENDPOINTS.academicYears.create, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(academicYearPayload(year)),
    })
    return response?.data
  },
  update: async (id, year) => {
    const response = await request(API_ENDPOINTS.academicYears.update(id), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(academicYearPayload(year)),
    })
    return response?.data
  },
  activate: async (id) => {
    const response = await request(API_ENDPOINTS.academicYears.activate(id), { method: 'PATCH' })
    return response?.data
  },
  deactivate: async (id) => {
    const response = await request(API_ENDPOINTS.academicYears.deactivate(id), { method: 'PATCH' })
    return response?.data
  },
}

const branchPayload = (branch) => ({
  courseId: Number(branch.courseId),
  branchCode: String(branch.code || branch.branchCode || '').trim().toUpperCase(),
  branchName: String(branch.name || branch.branchName || '').trim(),
  shortName: String(branch.shortName || '').trim() || null,
  specialization: branch.specialization || null,
  ...(branch.departmentId ? { departmentId: Number(branch.departmentId) } : {}),
  branchType: branch.branchType || 'Core',
  duration: branch.duration || branch.durationValue ? Number(branch.duration || branch.durationValue) : null,
  totalSemesters: branch.totalSemesters || branch.semesters ? Number(branch.totalSemesters || branch.semesters) : null,
  intakeCapacity: Number(branch.intakeCapacity ?? branch.intake),
  startingAcademicYearId: branch.startingAcademicYearId || null,
  description: String(branch.description || '').trim() || null,
  status: branch.status === 'Inactive' || Number(branch.status) === 0 ? 0 : 1,
})

export const branchApi = {
  getAll: async () => {
    const response = await request(API_ENDPOINTS.branches.list)
    return listResponse(response)
  },
  getByCourse: async (courseId) => {
    const response = await request(API_ENDPOINTS.branches.byCourse(courseId))
    return Array.isArray(response?.data) ? response.data : []
  },
  getById: async (id) => {
    const response = await request(API_ENDPOINTS.branches.detail(id))
    return response?.data
  },
  create: async (branch) => {
    const response = await request(API_ENDPOINTS.branches.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(branchPayload(branch)) })
    return response?.data
  },
  update: async (id, branch) => {
    const response = await request(API_ENDPOINTS.branches.update(id), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(branchPayload(branch)) })
    return response?.data
  },
  updateStatus: async (id, status) => request(API_ENDPOINTS.branches.status(id), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: status === 'Active' || status === 1 || status === true }) }),
  delete: async (id) => request(API_ENDPOINTS.branches.detail(id), { method: 'DELETE' }),
}

export const departmentApi = {
  getAll: async () => {
    const response = await request(API_ENDPOINTS.departments.list)
    return listResponse(response)
  },
  getById: async (id) => (await request(endpoint(`/api/v1/departments/${id}`)))?.data,
  create: async (data) => (await request(API_ENDPOINTS.departments.list, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }))?.data,
  update: async (id, data) => (await request(endpoint(`/api/v1/departments/${id}`), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }))?.data,
  delete: async (id) => request(endpoint(`/api/v1/departments/${id}`), { method: 'DELETE' }),
  updateStatus: async (id, status) => request(endpoint(`/api/v1/departments/${id}/status`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: status === 1 || status === 'Active' || status === true ? 1 : 0 }) }),
}

export const courseApi = {
  getAll: async (params) => {
    const response = await request(withQuery(API_ENDPOINTS.courses.list, params))
    return listResponse(response)
  },
  getById: async (id) => (await request(API_ENDPOINTS.courses.detail(id)))?.data,
  create: async (data) => (await request(API_ENDPOINTS.courses.list, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }))?.data,
  update: async (id, data) => (await request(API_ENDPOINTS.courses.detail(id), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }))?.data,
  delete: async (id) => request(API_ENDPOINTS.courses.detail(id), { method: 'DELETE' }),
  updateStatus: async (id, status) => request(endpoint(`/api/v1/courses/${id}/status`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: status === 1 || status === 'Active' || status === true ? 1 : 0 }) }),
}

const courseStructurePayload = (structure) => ({
  courseId: Number(structure.courseId),
  branchId: Number(structure.branchId),
  academicYearId: Number(structure.academicYearId),
  yearNumber: Number(structure.yearNumber),
  semesterNumber: Number(structure.semesterNumber),
  semesterName: String(structure.semesterName || `Semester ${structure.semesterNumber}`).trim(),
  ...(structure.status !== undefined ? { status: Number(structure.status) === 0 || structure.status === 'Inactive' ? 0 : 1 } : {}),
})

export const courseStructureApi = {
  getAll: async () => {
    const response = await request(API_ENDPOINTS.courseStructures.list)
    return listResponse(response)
  },
  getByCourse: async (courseId) => {
    const response = await request(API_ENDPOINTS.courseStructures.byCourse(courseId))
    return listResponse(response)
  },
  getById: async (id) => (await request(API_ENDPOINTS.courseStructures.detail(id)))?.data,
  create: async (structure) => (await request(API_ENDPOINTS.courseStructures.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(courseStructurePayload(structure)) }))?.data,
  update: async (id, structure) => (await request(API_ENDPOINTS.courseStructures.update(id), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(courseStructurePayload(structure)) }))?.data,
}

export const sectionAssignmentApi = {
  list: async () => {
    const response = await request(API_ENDPOINTS.sectionAssignments.list)
    return listResponse(response)
  },
  assign: async (sectionId, assignment) => request(API_ENDPOINTS.sections.assignStudents(sectionId), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ studentIds: [Number(assignment.studentId)] }) }),
  assignMany: async (sectionId, studentIds) => request(API_ENDPOINTS.sections.assignStudents(sectionId), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ studentIds: [...new Set(studentIds.map(Number))] }) }),
  remove: async (sectionId, studentId) => {
    await request(API_ENDPOINTS.sections.student(sectionId, studentId), { method: 'DELETE' })
  },
  listBySection: async (sectionId) => listResponse(await request(API_ENDPOINTS.sections.students(sectionId))),
  getStudentCandidates: async (sectionId, search = '') => listResponse(await request(withQuery(API_ENDPOINTS.sections.studentCandidates(sectionId), { search }))),
}

export const sectionAllocationApi = {
  getTeacher: async (sectionId) => (await request(API_ENDPOINTS.sections.classTeacher(sectionId)))?.data,
  getTeacherCandidates: async (sectionId) => listResponse(await request(API_ENDPOINTS.sections.classTeacherCandidates(sectionId))),
  getFormTeacherCandidates: async (sectionId, sections = []) => {
    if (sectionId) return sectionAllocationApi.getTeacherCandidates(sectionId)
    const sectionIds = [...new Set(sections.map((section) => section.sectionId ?? section.id).filter((id) => Number(id) > 0))]
    const results = await Promise.allSettled(sectionIds.map((id) => sectionAllocationApi.getTeacherCandidates(id)))
    const candidates = new Map()
    for (const result of results) {
      if (result.status !== 'fulfilled') continue
      for (const candidate of result.value) {
        if (candidate.employeeProfileId) candidates.set(String(candidate.employeeProfileId), candidate)
      }
    }
    if (results.length && results.every((result) => result.status === 'rejected')) throw results[0].reason
    return [...candidates.values()]
  },
  assignTeacher: async (sectionId, employeeProfileId) => (await request(API_ENDPOINTS.sections.classTeacher(sectionId), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ employeeProfileId: Number(employeeProfileId) }) }))?.data,
  removeTeacher: async (sectionId) => request(API_ENDPOINTS.sections.classTeacher(sectionId), { method: 'DELETE' }),
  getCapacity: async (sectionId) => (await request(API_ENDPOINTS.sections.capacity(sectionId)))?.data,
}

const sectionPayload = (section) => ({
  sectionCode: String(section.code || section.sectionCode || '').trim().toUpperCase(),
  sectionName: String(section.name || section.sectionName || '').trim(),
  capacity: Number(section.capacity),
  facultyAdvisorEmployeeProfileId: section.facultyAdvisorEmployeeProfileId || null,
  room: String(section.room || '').trim() || null,
  shift: section.shift || 'Morning',
  sectionType: section.type || section.sectionType || 'Regular',
})

const sectionUpdatePayload = (section) => ({
  sectionCode: String(section.code || section.sectionCode || '').trim().toUpperCase(),
  sectionName: String(section.name || section.sectionName || '').trim(),
  capacity: Number(section.capacity),
  facultyAdvisorEmployeeProfileId: section.facultyAdvisorEmployeeProfileId ? Number(section.facultyAdvisorEmployeeProfileId) : null,
  room: String(section.room || '').trim() || null,
  shift: section.shift || 'Morning',
  sectionType: section.type || section.sectionType || 'Regular',
})

export const sectionApi = {
  getAll: async () => listResponse(await request(API_ENDPOINTS.sections.list)),
  getById: async (id) => (await request(API_ENDPOINTS.sections.detail(id)))?.data,
  create: async (section) => {
    let academicYearId = Number(section.academicYearId || 0)
    if (!academicYearId && section.academicYear) {
      const yearRows = listResponse(await request(API_ENDPOINTS.academicYears.list))
      const selectedYear = yearRows.find((year) => String(year.academicYearName ?? year.name ?? '').trim().toLowerCase() === String(section.academicYear).trim().toLowerCase())
      academicYearId = Number(selectedYear?.academicYearId ?? selectedYear?.id ?? 0)
    }
    const ids = { collegeId: Number(section.collegeId), academicYearId, courseId: Number(section.courseId), branchId: Number(section.branchId), semesterId: Number(section.semesterId) }
    const requiredIds = ['collegeId', 'academicYearId', 'courseId', 'branchId', 'semesterId']
    const missing = requiredIds.filter((key) => !Number.isInteger(ids[key]) || ids[key] <= 0)
    if (missing.length) throw new Error('Select a valid college, academic year, course, branch, and semester.')
    const deptId = Number(section.departmentId)
    const sectionBody = { ...sectionPayload(section), ...ids, departmentId: Number.isInteger(deptId) && deptId > 0 ? deptId : null }
    const response = await request(API_ENDPOINTS.sections.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(sectionBody) })
    const id = response?.data?.sectionId ?? response?.sectionId
    return { ...section, ...(response?.data || {}), id: id || response?.data?.id || section.id }
  },
  update: async (id, section) => { const response = await request(API_ENDPOINTS.sections.update(id), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(sectionUpdatePayload(section)) }); return { ...section, ...(response?.data || {}), id } },
  remove: async (id) => request(API_ENDPOINTS.sections.remove(id), { method: 'DELETE' }),
  updateStatus: async (id, status) => request(API_ENDPOINTS.sections.status(id), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: status === 'Active' }) }),
  search: async (params) => { const query = new URLSearchParams(Object.entries(params).filter(([, value]) => value !== '' && value != null)); return listResponse(await request(`${API_ENDPOINTS.sections.search}?${query}`)) },
  summary: async () => { const response = await request(API_ENDPOINTS.sections.summary); return response?.data?.data ?? response?.data ?? null },
  validateCapacity: async (sectionId, capacity) => (await request(`${API_ENDPOINTS.sections.validateCapacity}?sectionId=${sectionId}&capacity=${capacity}`))?.data,
}

const compact = (object) => Object.fromEntries(Object.entries(object).filter(([, value]) => value !== undefined))
// API DTOs define academic references as nullable Int64 values.  Form controls
// use an empty string while no option is selected, which cannot be deserialized
// by ASP.NET as a nullable number.  Omit empty values and normalize valid IDs.
const nullableNumericId = (value) => {
  if (value === undefined || value === null || String(value).trim() === '') return undefined
  const parsed = Number(value)
  return Number.isInteger(parsed) && parsed > 0 ? parsed : undefined
}
const normalizeRecord = (source) => dataResponse(source) || {}
export const normalizeAdmission = (source) => {
  const { currentStatus, admissionStatus, applicationStatus, ...record } = normalizeRecord(source)
  return { ...record, status: currentStatus ?? admissionStatus ?? applicationStatus ?? record.status }
}
export const normalizeStudent = (source) => normalizeRecord(source)
export const normalizeStudentProfile = (source) => normalizeRecord(source)
export const normalizeAcademicDetails = (source) => normalizeRecord(source)
export const normalizePreviousEducation = (source) => normalizeRecord(source)
export const normalizeParent = (source) => normalizeRecord(source)
export const normalizeDocument = (source) => normalizeRecord(source)
export const normalizePromotion = (source) => normalizeRecord(source)

// Faculty APIs deliberately keep payloads transparent: the faculty module has
// several independently versioned DTOs (master, profile, attendance, and
// allocations), so callers can pass the schema supplied by the API contract.
const jsonRequest = (url, method, payload) => request(url, {
  method,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
})
const multipartRequest = (url, form) => request(url, { method: 'POST', body: form })

export const facultyApi = {
  getAll: async (params, requestOptions) => listData(await request(withQuery(API_ENDPOINTS.faculty.list, params), requestOptions)),
  search: async (params, requestOptions) => listData(await request(withQuery(API_ENDPOINTS.faculty.search, params), requestOptions)),
  getById: async (facultyId) => normalizeRecord(await request(API_ENDPOINTS.faculty.detail(requiredId(facultyId, 'Faculty ID')))),
  create: async (payload, collegeId = payload?.collegeId) => {
    const resolvedCollegeId = Number(collegeId)
    if (!Number.isSafeInteger(resolvedCollegeId) || resolvedCollegeId <= 0) throw new Error('College is required. Select a valid college.')
    const body = { ...payload, collegeId: resolvedCollegeId }
    const url = withQuery(API_ENDPOINTS.faculty.create, { collegeId: resolvedCollegeId })
    console.log('Faculty Create Query collegeId:', resolvedCollegeId)
    console.log('Faculty Create Body collegeId:', body.collegeId)
    console.log('Faculty Create Payload:', body)
    return normalizeRecord(await request(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }, false, true))
  },
  update: async (facultyId, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.faculty.update(requiredId(facultyId, 'Faculty ID')), 'PUT', payload)),
  getWorkload: async (facultyId, params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.faculty.workload(requiredId(facultyId, 'Faculty ID')), params))),
  uploadProfilePhoto: async (facultyId, file, metadata = {}) => {
    if (!(file instanceof File)) throw new Error('Choose a profile photo to upload.')
    const form = new FormData()
    form.append('file', file)
    Object.entries(metadata).filter(([, value]) => value !== undefined && value !== null && value !== '').forEach(([key, value]) => form.append(key, String(value)))
    return normalizeRecord(await multipartRequest(API_ENDPOINTS.faculty.profilePhoto(requiredId(facultyId, 'Faculty ID')), form))
  },
  updateStatus: async (facultyId, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.faculty.status(requiredId(facultyId, 'Faculty ID')), 'PATCH', typeof payload === 'object' ? payload : { status: payload })),
  getStatusHistory: async (facultyId, params) => listData(await request(withQuery(API_ENDPOINTS.faculty.statusHistory(requiredId(facultyId, 'Faculty ID')), params))),
  getSummary: async (params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.faculty.summary, params))),
}

export const facultyProfileApi = {
  // The faculty master record may exist before its optional extended profile.
  // The current API returns 409 for that state in some deployments; treat it
  // like a normal missing profile while keeping all other failures visible.
  get: async (facultyId, requestOptions = {}) => normalizeRecord(await request(API_ENDPOINTS.facultyProfiles.detail(requiredId(facultyId, 'Faculty ID')), { silentStatuses: [404, 409], ...requestOptions })),
  create: async (facultyId, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyProfiles.create(requiredId(facultyId, 'Faculty ID')), 'POST', payload)),
  update: async (facultyId, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyProfiles.update(requiredId(facultyId, 'Faculty ID')), 'PUT', payload)),
}

export const facultyDocumentApi = {
  getAll: async (facultyId, params) => listData(await request(withQuery(API_ENDPOINTS.facultyDocuments.list(requiredId(facultyId, 'Faculty ID')), params))),
  upload: async (facultyId, file, metadata = {}) => {
    if (!(file instanceof File)) throw new Error('Choose a document to upload.')
    const form = new FormData()
    form.append('file', file)
    Object.entries(metadata).filter(([, value]) => value !== undefined && value !== null && value !== '').forEach(([key, value]) => form.append(key, String(value)))
    return normalizeRecord(await multipartRequest(API_ENDPOINTS.facultyDocuments.upload(requiredId(facultyId, 'Faculty ID')), form))
  },
  remove: async (facultyDocumentId) => request(API_ENDPOINTS.facultyDocuments.detail(requiredId(facultyDocumentId, 'Faculty document ID')), { method: 'DELETE' }),
}

export const facultySubjectAllocationApi = {
  getAll: async (params) => listData(await request(withQuery(API_ENDPOINTS.facultySubjectAllocations.list, params))),
  create: async (payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultySubjectAllocations.create, 'POST', payload)),
  update: async (allocationId, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultySubjectAllocations.detail(requiredId(allocationId, 'Allocation ID')), 'PUT', payload)),
  remove: async (allocationId) => request(API_ENDPOINTS.facultySubjectAllocations.detail(requiredId(allocationId, 'Allocation ID')), { method: 'DELETE' }),
}

export const facultyAttendanceApi = {
  getDaily: async (params, requestOptions) => listData(await request(withQuery(API_ENDPOINTS.facultyAttendance.daily, params), requestOptions)),
  bulk: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyAttendance.bulk, 'POST', payload)),
  getWeekly: async params => listData(await request(withQuery(API_ENDPOINTS.facultyAttendance.weekly, params))),
  getMonthly: async params => listData(await request(withQuery(API_ENDPOINTS.facultyAttendance.monthly, params))),
  getAll: async (params) => listData(await request(withQuery(API_ENDPOINTS.facultyAttendance.list, params))),
  getById: async (attendanceId) => normalizeRecord(await request(API_ENDPOINTS.facultyAttendance.detail(requiredId(attendanceId, 'Attendance ID')))),
  create: async (payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyAttendance.create, 'POST', payload)),
  update: async (attendanceId, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyAttendance.update(requiredId(attendanceId, 'Attendance ID')), 'PUT', payload)),
  checkIn: async (attendanceId, payload = {}) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyAttendance.checkIn(requiredId(attendanceId, 'Attendance ID')), 'POST', payload)),
  checkOut: async (attendanceId, payload = {}) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyAttendance.checkOut(requiredId(attendanceId, 'Attendance ID')), 'POST', payload)),
  getReports: async (params) => listData(await request(withQuery(API_ENDPOINTS.facultyAttendance.reports, params))),
  export: async (params) => blobRequest(withQuery(API_ENDPOINTS.facultyAttendance.export, params)),
}

export const apiAssetUrl = (value) => {
  if (!value || ['string', 'null', 'undefined'].includes(String(value).trim().toLowerCase())) return ''
  if (/^(?:https?:|data:|blob:)/i.test(value)) return value
  const base = String(import.meta.env.VITE_API_BASE_URL || '').replace(/\/+$/, '')
  return import.meta.env.DEV ? value : `${base}/${String(value).replace(/^\/+/, '')}`
}

const addressText = (address) => {
  if (typeof address === 'string') return address.trim()
  if (!address || typeof address !== 'object') return undefined
  return [address.line1 ?? address.addressLine1, address.line2 ?? address.addressLine2, address.town ?? address.village, address.city, address.district, address.state, address.pincode ?? address.postalCode].filter(value => value !== undefined && value !== null && String(value).trim() !== '').join(', ')
}

const studentAdmissionPayload = (form = {}, { feePlanChangeReason } = {}) => {
  const currentAddress = form.currentAddress ?? form.contact?.currentAddress
  const permanentAddress = form.permanentAddress ?? form.contact?.permanentAddress
  const parents = form.parents ?? {}
  const personal = form.personal ?? {}
  const contact = form.contact ?? {}
  const academic = form.academic ?? {}
  const admission = form.admission ?? {}
  const fees = form.fees ?? {}
  const previous = form.previousEducation ?? {}
  const application = form.application ?? {}
  // Canonical forms retain the original API fields alongside editable sections.
  // The editable values must win, including an explicitly cleared selection.
  form = { ...form }
  for (const key of ['firstName', 'middleName', 'lastName', 'gender', 'bloodGroup', 'nationality']) {
    if (Object.hasOwn(personal, key)) form[key] = personal[key]
  }
  if (Object.hasOwn(personal, 'dob')) form.dateOfBirth = personal.dob
  if (Object.hasOwn(personal, 'aadhaar')) form.aadhaarNumber = personal.aadhaar
  for (const key of ['academicYearId', 'departmentId', 'courseId', 'branchId', 'semesterId', 'sectionId', 'admissionType', 'quota', 'quotaOther', 'courseCode', 'branchCode', 'entryType', 'regulation', 'studentCategory']) {
    if (Object.hasOwn(academic, key)) form[key] = academic[key]
  }
  if (Object.hasOwn(admission, 'collegeId')) form.collegeId = admission.collegeId
  const { formData: savedFormData, ...currentForm } = form
  const formData = { ...(savedFormData && typeof savedFormData === 'object' ? savedFormData : {}), ...currentForm }
  const feeStructureId = [form.feeStructureId, fees.feeStructureId, fees.structureId]
    .map(nullableNumericId).find(value => value !== undefined)
  formData.feeStructureId = feeStructureId
  if (formData.fees) formData.fees = { ...formData.fees, feeStructureId, structureId: feeStructureId }
  const photo = form.studentPhoto ?? form.photo ?? personal.photo ?? personal.photoUrl
  // Deployed admission procedures accept a URL (VARCHAR(500)), not base64.
  // Preserve inline uploads in formData. Send an explicit empty legacy field:
  // null/omission lets older services hydrate it back from personal.photo.
  const legacyPhoto = /^data:/i.test(String(photo ?? '').trim()) ? '' : photo

  return compact({
    registrationNumber: form.registrationNumber ?? application.registrationNumber ?? application.number ?? form.number,
    registrationNo: form.registrationNo ?? form.registrationNumber ?? application.registrationNumber ?? application.number ?? form.number,
    registrationDate: form.registrationDate ?? application.registrationDate ?? application.date,
    admissionNumber: form.admissionNumber ?? application.admissionNumber,
    admissionNo: form.admissionNo ?? form.admissionNumber ?? application.admissionNumber,
    admissionDate: form.admissionDate ?? application.admissionDate,
    firstName: form.firstName ?? personal.firstName,
    middleName: form.middleName ?? personal.middleName,
    lastName: form.lastName ?? personal.lastName,
    fullName: form.fullName ?? personal.fullName,
    gender: form.gender ?? personal.gender,
    photo: legacyPhoto,
    studentPhoto: legacyPhoto,
    dateOfBirth: form.dateOfBirth ?? form.dob ?? personal.dob ?? personal.dateOfBirth,
    bloodGroup: form.bloodGroup ?? personal.bloodGroup,
    nationality: form.nationality ?? personal.nationality,
    aadhaarNumber: form.aadhaarNumber ?? form.aadhaar ?? personal.aadhaar ?? personal.aadhaarNumber,
    mobile: form.mobile ?? contact.mobile,
    mobileNumber: form.mobileNumber ?? form.mobile ?? contact.mobile,
    alternateMobile: form.alternateMobile ?? contact.alternateMobile,
    email: form.email ?? contact.email,
    studentEmail: form.studentEmail ?? form.email ?? contact.email,
    alternateEmail: form.alternateEmail ?? contact.alternateEmail,
    sameAddress: form.sameAddress ?? contact.sameAddress,
    currentAddress,
    permanentAddress,
    currentAddressLine1: currentAddress?.line1 ?? currentAddress?.addressLine1,
    currentAddressLine2: currentAddress?.line2 ?? currentAddress?.addressLine2,
    currentTown: currentAddress?.town ?? currentAddress?.village ?? currentAddress?.townVillage,
    currentCity: currentAddress?.city,
    currentDistrict: currentAddress?.district,
    currentState: currentAddress?.state,
    currentCountry: currentAddress?.country,
    currentPincode: currentAddress?.pincode ?? currentAddress?.postalCode,
    permanentAddressLine1: permanentAddress?.line1 ?? permanentAddress?.addressLine1,
    permanentAddressLine2: permanentAddress?.line2 ?? permanentAddress?.addressLine2,
    permanentTown: permanentAddress?.town ?? permanentAddress?.village ?? permanentAddress?.townVillage,
    permanentCity: permanentAddress?.city,
    permanentDistrict: permanentAddress?.district,
    permanentState: permanentAddress?.state,
    permanentCountry: permanentAddress?.country,
    permanentPincode: permanentAddress?.pincode ?? permanentAddress?.postalCode,
    addressLine1: currentAddress?.line1 ?? currentAddress?.addressLine1,
    addressLine2: currentAddress?.line2 ?? currentAddress?.addressLine2,
    town: currentAddress?.town ?? currentAddress?.village,
    address: form.address ?? addressText(currentAddress),
    city: form.city ?? currentAddress?.city,
    district: form.district ?? currentAddress?.district,
    state: form.state ?? currentAddress?.state,
    country: form.country ?? currentAddress?.country ?? 'India',
    pincode: form.pincode ?? currentAddress?.pincode ?? currentAddress?.postalCode,
    admissionType: form.admissionType ?? academic.admissionType,
    admissionQuota: form.admissionQuota ?? form.quota ?? academic.quota,
    academicYearId: nullableNumericId(form.academicYearId ?? academic.academicYearId),
    departmentId: nullableNumericId(form.departmentId ?? academic.departmentId),
    courseId: nullableNumericId(form.courseId ?? academic.courseId),
    branchId: nullableNumericId(form.branchId ?? academic.branchId),
    semesterId: nullableNumericId(form.semesterId ?? academic.semesterId),
    sectionId: nullableNumericId(form.sectionId ?? academic.sectionId),
    quota: form.quota ?? academic.quota,
    quotaOther: form.quotaOther ?? academic.quotaOther,
    courseCode: form.courseCode ?? academic.courseCode,
    branchCode: form.branchCode ?? academic.branchCode,
    entryType: form.entryType ?? academic.entryType,
    regulation: form.regulation ?? academic.regulation,
    studentCategory: form.studentCategory ?? academic.studentCategory,
    collegeId: nullableNumericId(form.collegeId ?? admission.collegeId),
    college: form.college ?? admission.college,
    batch: form.batch ?? admission.batch,
    fatherName: form.fatherName ?? parents.father?.name ?? form.father?.name,
    parentMobile: form.parentMobile ?? form.fatherMobile ?? parents.father?.mobile ?? form.father?.mobile,
    fatherMobile: form.fatherMobile ?? form.parentMobile ?? parents.father?.mobile ?? form.father?.mobile,
    fatherEmail: form.fatherEmail ?? parents.father?.email ?? form.father?.email,
    fatherOccupation: form.fatherOccupation ?? form.occupation ?? parents.father?.occupation ?? form.father?.occupation,
    fatherQualification: form.fatherQualification ?? parents.father?.qualification ?? form.father?.qualification,
    fatherIncome: form.fatherIncome ?? form.annualIncome ?? parents.father?.income ?? form.father?.income,
    motherName: form.motherName ?? parents.mother?.name ?? form.mother?.name,
    motherMobile: form.motherMobile ?? parents.mother?.mobile ?? form.mother?.mobile,
    motherEmail: form.motherEmail ?? parents.mother?.email ?? form.mother?.email,
    motherOccupation: form.motherOccupation ?? parents.mother?.occupation ?? form.mother?.occupation,
    motherQualification: form.motherQualification ?? parents.mother?.qualification ?? form.mother?.qualification,
    motherIncome: form.motherIncome ?? parents.mother?.income ?? form.mother?.income,
    guardianName: form.guardianName ?? parents.guardian?.name ?? form.guardian?.name,
    guardianRelationship: form.guardianRelationship ?? parents.guardian?.relationship ?? form.guardian?.relationship,
    guardianRelationshipOther: form.guardianRelationshipOther ?? parents.guardian?.relationshipOther ?? form.guardian?.relationshipOther,
    guardianMobile: form.guardianMobile ?? parents.guardian?.mobile ?? form.guardian?.mobile,
    guardianEmail: form.guardianEmail ?? parents.guardian?.email ?? form.guardian?.email,
    guardianOccupation: form.guardianOccupation ?? parents.guardian?.occupation ?? form.guardian?.occupation,
    guardianQualification: form.guardianQualification ?? parents.guardian?.qualification ?? form.guardian?.qualification,
    guardianIncome: form.guardianIncome ?? parents.guardian?.income ?? form.guardian?.income,
    primaryContact: form.primaryContact ?? parents.primaryContact,
    emergencyMobile: form.emergencyMobile ?? form.emergencyContact ?? parents.emergencyMobile,
    tenth: educationRecordPayload(form.tenth ?? previous.tenth),
    qualifyingEducation: educationRecordPayload(form.qualifyingEducation ?? form.intermediate ?? previous.intermediate),
    scholarship: form.scholarship ?? admission.scholarship,
    scholarshipType: form.scholarshipType ?? admission.scholarshipType,
    hostel: form.hostel ?? admission.hostel,
    hostelPreference: form.hostelPreference ?? admission.hostelPreference,
    hostelRoomType: form.hostelRoomType ?? admission.hostelRoomType,
    transport: form.transport ?? admission.transport,
    transportRoute: form.transportRoute ?? admission.transportRoute,
    feeStructureId,
    feePlanChangeReason,
    tuitionFee: form.tuitionFee ?? fees.tuitionFee,
    admissionFee: form.admissionFee ?? fees.admissionFee,
    scholarshipAmount: form.scholarshipAmount ?? fees.scholarshipAmount,
    hostelFee: form.hostelFee ?? fees.hostelFee,
    transportFee: form.transportFee ?? fees.transportFee,
    totalFee: form.totalFee ?? fees.totalFee,
    paymentPlan: form.paymentPlan ?? fees.paymentPlan,
    paymentStatus: form.paymentStatus ?? fees.paymentStatus,
    documentStatuses: form.documentStatuses ?? (form.documents ? Object.fromEntries(Object.entries(form.documents).filter(([, value]) => value && !Array.isArray(value)).map(([key, value]) => [key, typeof value === 'object' ? value.status ?? '' : value])) : undefined),
    formData,
  })
}

const academicDetailsPayload = (form = {}) => compact({
  collegeId: nullableNumericId(form.admission?.collegeId ?? form.academic?.collegeId ?? form.collegeId),
  academicYearId: nullableNumericId(form.academic?.academicYearId ?? form.academicYearId),
  departmentId: nullableNumericId(form.academic?.departmentId ?? form.departmentId),
  courseId: nullableNumericId(form.academic?.courseId ?? form.courseId),
  branchId: nullableNumericId(form.academic?.branchId ?? form.branchId),
  semesterId: nullableNumericId(form.academic?.semesterId ?? form.semesterId),
  sectionId: nullableNumericId(form.academic?.sectionId ?? form.sectionId),
  admissionType: form.academic?.admissionType ?? form.admissionType,
  quota: form.academic?.quota ?? form.quota,
  quotaOther: form.academic?.quotaOther ?? form.quotaOther,
  courseCode: form.courseCode ?? form.academic?.courseCode,
  branchCode: form.branchCode ?? form.academic?.branchCode,
  entryType: form.entryType ?? form.academic?.entryType,
  regulation: form.regulation ?? form.academic?.regulation,
  studentCategory: form.studentCategory ?? form.academic?.studentCategory,
  batch: form.batch ?? form.academic?.batch ?? form.admission?.batch,
})

const educationRecordPayload = (record) => {
  if (!record || typeof record !== 'object') return record
  const score = record.score
  // ASP.NET nullable Decimal fields accept null, but cannot deserialize an
  // empty form-control string (e.g. an optional SSC percentage).
  return {
    ...record,
    score: score === undefined || score === null || String(score).trim() === '' ? null : Number(score),
  }
}

const previousEducationPayload = (form = {}) => compact({
  tenth: educationRecordPayload(form.tenth ?? form.previousEducation?.tenth),
  qualifyingEducation: educationRecordPayload(form.qualifyingEducation ?? form.intermediate ?? form.previousEducation?.intermediate),
  intermediate: educationRecordPayload(form.intermediate ?? form.qualifyingEducation ?? form.previousEducation?.intermediate),
})

const parentPayload = (form = {}) => compact({
  fatherName: form.fatherName ?? form.father?.name ?? form.parents?.father?.name,
  motherName: form.motherName ?? form.mother?.name ?? form.parents?.mother?.name,
  guardianName: form.guardianName ?? form.guardian?.name ?? form.parents?.guardian?.name,
  guardianRelationship: form.guardianRelationship ?? form.guardian?.relationship ?? form.parents?.guardian?.relationship,
  guardianRelationshipOther: form.guardianRelationshipOther ?? form.guardian?.relationshipOther ?? form.parents?.guardian?.relationshipOther,
  primaryContact: form.primaryContact ?? form.parents?.primaryContact,
  emergencyMobile: form.emergencyMobile ?? form.emergencyContact ?? form.parents?.emergencyMobile,
  parentMobile: form.parentMobile ?? form.fatherMobile ?? form.father?.mobile ?? form.parents?.father?.mobile,
  fatherMobile: form.fatherMobile ?? form.parentMobile ?? form.father?.mobile ?? form.parents?.father?.mobile,
  email: form.email ?? form.fatherEmail ?? form.father?.email ?? form.parents?.father?.email,
  fatherEmail: form.fatherEmail ?? form.email ?? form.father?.email ?? form.parents?.father?.email,
  fatherOccupation: form.fatherOccupation ?? form.occupation ?? form.father?.occupation ?? form.parents?.father?.occupation,
  fatherQualification: form.fatherQualification ?? form.father?.qualification ?? form.parents?.father?.qualification,
  fatherIncome: form.fatherIncome ?? form.annualIncome ?? form.father?.income ?? form.parents?.father?.income,
  motherMobile: form.motherMobile ?? form.mother?.mobile ?? form.parents?.mother?.mobile,
  motherEmail: form.motherEmail ?? form.mother?.email ?? form.parents?.mother?.email,
  motherOccupation: form.motherOccupation ?? form.mother?.occupation ?? form.parents?.mother?.occupation,
  motherQualification: form.motherQualification ?? form.mother?.qualification ?? form.parents?.mother?.qualification,
  motherIncome: form.motherIncome ?? form.mother?.income ?? form.parents?.mother?.income,
  guardianMobile: form.guardianMobile ?? form.guardian?.mobile ?? form.parents?.guardian?.mobile,
  guardianEmail: form.guardianEmail ?? form.guardian?.email ?? form.parents?.guardian?.email,
  guardianOccupation: form.guardianOccupation ?? form.guardian?.occupation ?? form.parents?.guardian?.occupation,
  guardianQualification: form.guardianQualification ?? form.guardian?.qualification ?? form.parents?.guardian?.qualification,
  guardianIncome: form.guardianIncome ?? form.guardian?.income ?? form.parents?.guardian?.income,
  address: form.address ?? form.parents?.address,
})

export const studentAdmissionApi = {
  getAll: async (params) => markApiResult((listData(await request(withQuery(API_ENDPOINTS.studentAdmissions.list, params))) || []).map(normalizeAdmission)),
  getById: async (id) => normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.detail(requiredId(id, 'Admission ID')))),
  create: async (form) => normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(studentAdmissionPayload(form)) })),
  update: async (id, form, { preserveAcademicMapping = false, feePlanChangeReason } = {}) => {
    const admissionId = requiredId(id, 'Admission ID')
    if (preserveAcademicMapping) {
      // Personal/contact saves must not reassign enrollment from a browser draft.
      // Read failures stop the save instead of falling back to potentially stale IDs.
      const saved = normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.detail(admissionId)))
      const snapshot = typeof saved.formData === 'string' ? JSON.parse(saved.formData) : saved.formData
      const academic = { ...form.academic, ...snapshot?.academic }
      for (const key of ['academicYearId', 'departmentId', 'courseId', 'branchId', 'semesterId', 'sectionId', 'admissionType', 'entryType', 'regulation']) {
        if (Object.hasOwn(saved, key)) academic[key] = saved[key] ?? ''
      }
      for (const [label, key] of [['academicYear', 'academicYearName'], ['course', 'courseName'], ['branch', 'branchName'], ['semester', 'semesterName'], ['section', 'sectionName']]) {
        if (Object.hasOwn(saved, key)) academic[label] = saved[key] ?? ''
      }
      form = { ...form, academic, admission: { ...form.admission, collegeId: saved.collegeId ?? form.admission?.collegeId } }
    }
    return normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.update(admissionId), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(studentAdmissionPayload(form, { feePlanChangeReason })) }))
  },
  submit: async (id) => normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.submit(requiredId(id, 'Admission ID')), { method: 'POST' })),
}
export const studentAcademicDetailsApi = {
  get: async (id) => normalizeAcademicDetails(await request(API_ENDPOINTS.studentAdmissions.academicDetails(requiredId(id, 'Admission ID')))),
  update: async (id, form) => {
    const admissionId = requiredId(id, 'Admission ID')
    const payload = academicDetailsPayload(form)
    return normalizeAcademicDetails(await request(API_ENDPOINTS.studentAdmissions.academicDetails(admissionId), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }))
  },
}
export const studentAcademicInformationApi = {
  getById: async (id) => normalizeAcademicDetails(await request(API_ENDPOINTS.studentAcademicInformation.detail(requiredId(id, 'Academic ID')))),
  update: async (id, payload) => normalizeAcademicDetails(await request(API_ENDPOINTS.studentAcademicInformation.update(requiredId(id, 'Academic ID')), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
}
export const canonicalAdmissionStatus = (status) => {
  const s = String(status || '').trim().toLowerCase().replaceAll('_', ' ')
  if (s === 'draft') return 'Draft'
  if (s === 'pending' || s === 'submitted' || s === 'application submitted') return 'Application Submitted'
  if (s === 'under review' || s === 'in review' || s === 'under_review') return 'Under Review'
  if (s === 'verified' || s === 'document verification') return 'Document Verification'
  if (s === 'correction required' || s === 'correction_required') return 'Correction Required'
  if (s === 'approved' || s === 'enrolled' || s === 'admitted') return 'Approved'
  if (s === 'rejected') return 'Rejected'
  return String(status || '').trim() || 'Approved'
}
export const studentAdmissionStatusApi = {
  get: async (id) => {
    const reqId = requiredId(id, 'Admission ID')
    return normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.status(reqId), { cache: 'no-store' }))
  },
  update: async (id, payload) => {
    const reqId = requiredId(id, 'Admission ID')
    const rawTarget = payload.newStatus ?? payload.status ?? ''
    const targetStatus = canonicalAdmissionStatus(rawTarget)
    const normTarget = String(targetStatus).trim().replaceAll(' ', '_').toUpperCase()

    // 1. Check current status if approving, to auto-advance Draft applications according to backend transition rules
    let currentStatusRaw = ''
    try {
      const current = await studentAdmissionStatusApi.get(reqId)
      currentStatusRaw = current?.status || current?.currentStatus || ''
    } catch {
      // Continue if initial status read is not available
    }

    const normCurrent = String(currentStatusRaw).trim().replaceAll(' ', '_').toUpperCase()

    // Backend rule: Draft cannot transition directly to Approved.
    // Allowed flow: Draft -> Application Submitted -> Approved
    if (normCurrent === 'DRAFT' && normTarget === 'APPROVED') {
      try {
        await request(API_ENDPOINTS.studentAdmissions.status(reqId), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            newStatus: 'Application Submitted',
            remarks: 'Submitted for approval workflow'
          })
        })
      } catch {
        // If promotion fails, proceed to attempt direct status transition
      }
    }

    // 2. Post canonical status transition (executes EnsureApprovedStudentAsync and saves to DB)
    const body = {
      newStatus: targetStatus,
      remarks: payload.remarks || (targetStatus === 'Approved' ? 'Approved by Admission Officer' : ''),
      rejectionReason: payload.rejectionReason ?? (targetStatus === 'Rejected' ? (payload.remarks || 'Application rejected') : undefined)
    }

    let res
    try {
      res = normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.status(reqId), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }))
    } catch (error) {
      const msg = String(error?.message || '')
      // If status is already updated in backend (409 Conflict), proceed to verify
      if (!msg.toLowerCase().includes('already')) {
        // Fallback for legacy approve endpoint if 404
        if (normTarget === 'APPROVED' && error?.status === 404) {
          try {
            res = normalizeAdmission(await request(API_ENDPOINTS.studentAdmissions.approve(reqId), {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ remarks: payload.remarks })
            }))
          } catch {
            throw error
          }
        } else {
          if (error.status >= 500) {
            error.message = typeof GENERIC_ERROR_MESSAGE !== 'undefined' ? GENERIC_ERROR_MESSAGE : 'Something went wrong. Please try again.'
          }
          throw error
        }
      }
    }

    // 3. Confirm latest status from backend
    let latest
    try {
      latest = await studentAdmissionApi.getById(reqId).catch(() => studentAdmissionStatusApi.get(reqId))
    } catch {
      try {
        latest = await studentAdmissionStatusApi.get(reqId)
      } catch {
        latest = res || {}
      }
    }

    const normActual = String(latest?.status || latest?.currentStatus || latest?.admissionStatus || '').trim().replaceAll(' ', '_').toUpperCase()
    const isApprovedMatch = normTarget === 'APPROVED' && (normActual === 'APPROVED' || latest?.isApproved === true)
    const isRejectedMatch = normTarget === 'REJECTED' && (normActual === 'REJECTED' || latest?.isRejected === true)
    const isMatch = normActual === normTarget || isApprovedMatch || isRejectedMatch

    if (!isMatch && normActual && normActual !== 'UNKNOWN') {
      throw new Error(`Admission status was not confirmed as ${targetStatus}. Current backend status: ${latest?.status || latest?.currentStatus || 'unknown'}. Refresh and try again.`)
    }

    return normalizeRecord({ ...res, ...latest, status: latest?.status || targetStatus })
  },
}
export const studentPreviousEducationApi = {
  get: async (id) => normalizePreviousEducation(await request(API_ENDPOINTS.studentAdmissions.previousEducation(requiredId(id, 'Admission ID')))),
  update: async (id, form) => normalizePreviousEducation(await request(API_ENDPOINTS.studentAdmissions.previousEducation(requiredId(id, 'Admission ID')), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(previousEducationPayload(form)) })),
}
export const studentFeeApi = {
  getSummary: async (id) => normalizeRecord(await request(API_ENDPOINTS.studentAdmissions.feeSummary(requiredId(id, 'Admission ID')))),
  getStructure: async (id) => normalizeRecord(await request(API_ENDPOINTS.studentAdmissions.feeStructure(requiredId(id, 'Admission ID')))),
}
export const admissionFeePlanApi = {
  getMatching: async scope => listData(await request(withQuery(API_ENDPOINTS.studentAdmissions.matchingFeePlans, scope))),
}

export const academicFeePlanApi = {
  update: async (id,body) => dataResponse(await jsonRequest(API_ENDPOINTS.academicFeePlans.create + '/' + encodeURIComponent(requiredId(id,'Fee plan ID')), 'PUT', body)),
  get: async (id, collegeId) => dataResponse(await request(withQuery(endpoint(`/api/v1/academic-fee-plans/${encodeURIComponent(id)}`), { collegeId }))),
  transition: async (id, collegeId, action, expectedRevision) => {
    if (!['submit', 'approve', 'publish', 'return-to-draft', 'archive'].includes(action)) throw new Error('Unsupported fee plan action.')
    return dataResponse(await request(withQuery(endpoint(`/api/v1/academic-fee-plans/${encodeURIComponent(id)}/${action}`), { collegeId }), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expectedRevision, ...(action === 'return-to-draft' ? { reason: 'Returned to draft from Fee Management.' } : {}) }) }))
  },
  list: async (collegeId, params = {}) => listData(await request(withQuery(API_ENDPOINTS.academicFeePlans.list, { collegeId, page: 1, pageSize: 100, ...params }))),
  create: async body => dataResponse(await request(API_ENDPOINTS.academicFeePlans.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })),
  submit: async (id, collegeId, expectedRevision) => dataResponse(await request(API_ENDPOINTS.academicFeePlans.submit(id, collegeId), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expectedRevision }) })),
}

export const feeConfigurationApi = {
  categories: async () => listData(await request(API_ENDPOINTS.feeConfiguration.categories)),
}

// Contracts: Backend/DTOs/Fees/FeeCollectionDtos.cs. Reuse authentication,
// refresh, error handling and request deduplication from the shared client.
function financialData(response, amounts = [], lists = []) {
  const data = response?.data
  if (!data || typeof data !== 'object' || amounts.some(key => typeof data[key] !== 'number' || !Number.isFinite(data[key])) || lists.some(key => !Array.isArray(data[key]))) {
    throw new Error('Financial response is incomplete. Refresh before using these balances.')
  }
  return data
}
function financialPage(response, amounts) {
  const data = financialData(response, ['totalCount', 'totalPages', 'page', 'pageSize'], ['items'])
  const expectedItems = Math.max(0, Math.min(data.pageSize, data.totalCount - (data.page - 1) * data.pageSize))
  if (['totalCount', 'totalPages', 'page', 'pageSize'].some(key => !Number.isSafeInteger(data[key])) || data.totalCount < 0 || data.page < 1 || data.pageSize < 1 || data.totalPages !== Math.ceil(data.totalCount / data.pageSize) || data.items.length !== expectedItems || data.items.some(row => !row || amounts.some(key => typeof row[key] !== 'number' || !Number.isFinite(row[key]) || (key.endsWith('Id') && (!Number.isSafeInteger(row[key]) || row[key] <= 0))))) {
    throw new Error('Financial records are incomplete. Refresh before using these balances.')
  }
  return data
}
async function allFinancialPages(load, params, idKey) {
  const rows = []
  const seen = new Set()
  let expectedCount
  for (let page = 1; ; page += 1) {
    const result = await load({ ...params, page, pageSize: 100 })
    if (!result || !Array.isArray(result.items) || result.page !== page || result.pageSize !== 100 || !Number.isInteger(result.totalCount) || !Number.isInteger(result.totalPages)) {
      throw new Error('Financial response is incomplete. Refresh before using these balances.')
    }
    if (expectedCount !== undefined && expectedCount !== result.totalCount) throw new Error('Financial records changed while loading. Refresh to get a consistent view.')
    expectedCount = result.totalCount
    for (const row of result.items) {
      if (seen.has(row[idKey])) throw new Error('Financial records repeated while loading. Refresh to get a consistent view.')
      seen.add(row[idKey])
    }
    rows.push(...result.items)
    if (page >= result.totalPages) {
      if (rows.length !== expectedCount) throw new Error('Not all financial records were returned. Refresh before using these balances.')
      return rows
    }
    if (!result.items.length) throw new Error('Financial pagination is incomplete. Refresh to retry.')
  }
}
export const feeCollectionApi = {
  dashboard: async params => {
    const data = financialData(await request(withQuery(endpoint('/api/v1/fee-collection/dashboard'), params)), ['totalAssigned', 'totalConcession', 'totalPayable', 'totalCollected', 'totalPending', 'totalOverdue', 'totalFineAssessed', 'totalFineCollected', 'totalFinePending', 'studentsWithPending', 'studentsOverdue', 'paymentsCount', 'receiptsCount'], ['collectionTrend', 'byCategory', 'byPaymentMode'])
    for (const [key, amounts] of [['collectionTrend', ['amount', 'paymentCount']], ['byCategory', ['assigned', 'collected', 'pending']], ['byPaymentMode', ['amount', 'paymentCount']]]) {
      data[key].forEach(row => financialData({ data: row }, amounts))
    }
    if (data.collectionTrend.some(row => typeof row.date !== 'string' || Number.isNaN(Date.parse(row.date))) || data.byCategory.some(row => typeof row.categoryName !== 'string' || !row.categoryName.trim()) || data.byPaymentMode.some(row => typeof row.paymentMode !== 'string' || !row.paymentMode.trim())) throw new Error('Financial summary labels or dates are incomplete. Refresh before using this report.')
    return data
  },
  pending: async params => financialPage(await request(withQuery(endpoint('/api/v1/fee-collection/pending'), params)), ['studentFeeId', 'studentId', 'payableAmount', 'paidAmount', 'balanceAmount', 'finePending', 'concessionAmount']),
  history: async params => financialPage(await request(withQuery(endpoint('/api/v1/fee-collection/history'), params)), ['paymentId', 'studentId', 'receiptId', 'feeAmount', 'fineAmount', 'totalAmount']),
  fines: async params => financialPage(await request(withQuery(endpoint('/api/v1/fee-collection/fines'), params)), ['fineId', 'amount', 'waivedAmount', 'pendingAmount']),
  collect: async payload => (await request(endpoint('/api/v1/fee-collection/payments'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }))?.data,
  receipt: async id => {
    const data = financialData(await request(endpoint(`/api/v1/fee-collection/receipts/${requiredId(id, 'Receipt ID')}`)), ['receiptId', 'paymentId', 'studentId', 'feeAmount', 'fineAmount', 'totalAmount'])
    if (['receiptId', 'paymentId', 'studentId'].some(key => !Number.isSafeInteger(data[key]) || data[key] <= 0) || String(data.receiptId) !== String(id) || typeof data.receiptNumber !== 'string' || !data.receiptNumber.trim() || ['feeAmount', 'fineAmount', 'totalAmount'].some(key => data[key] < 0 || !Number.isSafeInteger(Math.round(data[key] * 100)) || data[key] !== Math.round(data[key] * 100) / 100) || Math.round(data.totalAmount * 100) !== Math.round(data.feeAmount * 100) + Math.round(data.fineAmount * 100)) throw new Error('Receipt is incomplete or inconsistent. Check confirmed payments before printing.')
    return data
  },
  createFine: async payload => (await request(endpoint('/api/v1/fee-collection/fines'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }))?.data,
  waiveFine: async (id, payload) => (await request(endpoint(`/api/v1/fee-collection/fines/${requiredId(id, 'Fine ID')}/waive`), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }))?.data,
  allPending: params => allFinancialPages(feeCollectionApi.pending, params, 'studentFeeId'),
  allHistory: params => allFinancialPages(feeCollectionApi.history, params, 'paymentId'),
  allFines: params => allFinancialPages(feeCollectionApi.fines, params, 'fineId'),
}
export const studentApi = {
  getAll: async (params) => listData(await request(withQuery(API_ENDPOINTS.students.list, params))), search: async (params) => listData(await request(withQuery(API_ENDPOINTS.students.search, params))),
  getById: async (id) => normalizeStudent(await request(API_ENDPOINTS.students.detail(requiredId(id, 'Student ID')))),
  create: async (payload) => normalizeStudent(await request(API_ENDPOINTS.students.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  update: async (id, payload) => normalizeStudent(await request(API_ENDPOINTS.students.update(requiredId(id, 'Student ID')), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  updateStatus: async (id, status) => normalizeStudent(await request(API_ENDPOINTS.students.status(requiredId(id, 'Student ID')), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(typeof status === 'object' ? status : { status }) })),
}
export const studentParentApi = { get: async (id) => normalizeParent(await request(API_ENDPOINTS.students.parent(requiredId(id, 'Student ID')))), update: async (id, form) => normalizeParent(await request(API_ENDPOINTS.students.parent(requiredId(id, 'Student ID')), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(parentPayload(form)) })) }
export const studentDocumentApi = {
  getAll: async (id) => listData(await request(API_ENDPOINTS.students.documents(requiredId(id, 'Student ID')))),
  upload: async (id, file, metadata = {}) => { if (!(file instanceof File)) throw new Error('Choose a document to upload.'); const form = new FormData(); form.append('file', file); Object.entries(metadata).filter(([, value]) => value !== undefined && value !== null && value !== '').forEach(([key, value]) => form.append(key, String(value))); return normalizeDocument(await request(API_ENDPOINTS.students.documents(requiredId(id, 'Student ID')), { method: 'POST', body: form })) },
  get: async (studentId, documentId) => normalizeDocument(await request(API_ENDPOINTS.students.document(requiredId(studentId, 'Student ID'), requiredId(documentId, 'Document ID')))),
  remove: async (studentId, documentId) => request(API_ENDPOINTS.students.document(requiredId(studentId, 'Student ID'), requiredId(documentId, 'Document ID')), { method: 'DELETE' }),
  download: async (studentId, documentId) => blobRequest(API_ENDPOINTS.students.downloadDocument(requiredId(studentId, 'Student ID'), requiredId(documentId, 'Document ID'))),
}
export const studentProfileApi = {
  getPersonalInformation: async (id) => normalizeStudentProfile(await request(API_ENDPOINTS.students.personalInformation(requiredId(id, 'Student ID')))),
  updatePersonalInformation: async (id, payload) => normalizeStudentProfile(await request(API_ENDPOINTS.students.personalInformation(requiredId(id, 'Student ID')), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  getExamResults: async (id) => listData(await request(API_ENDPOINTS.students.examResults(requiredId(id, 'Student ID')))), getMyProfile: async () => normalizeStudentProfile(await request(API_ENDPOINTS.studentProfiles.myProfile)),
}

export const studentProfilesApi = {
  getAll: async (params) => markApiResult((listData(await request(withQuery(API_ENDPOINTS.studentProfiles.list, params))) || []).map(normalizeStudentProfile)),
  preview: async (id) => markApiResult(normalizeStudentProfile(await request(API_ENDPOINTS.studentProfiles.preview(requiredId(id, 'Student ID'))))),
  update: async (id, payload) => normalizeStudentProfile(await request(API_ENDPOINTS.studentProfiles.update(requiredId(id, 'Student ID')), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
}
export const studentPromotionApi = {
  getDashboard: async () => normalizePromotion(await request(API_ENDPOINTS.promotions.dashboard)), getDirectory: async (params) => listData(await request(withQuery(API_ENDPOINTS.promotions.directory, params))), getHistory: async (params) => listData(await request(withQuery(API_ENDPOINTS.promotions.history, params))),
  getEligibleStudents: async (params) => listData(await request(withQuery(API_ENDPOINTS.promotions.eligibleStudents, params))), getEligibility: async (id) => normalizePromotion(await request(API_ENDPOINTS.promotions.eligibility(requiredId(id, 'Student ID')))),
  updateEligibilityStatus: async (id, eligibilityStatus) => normalizePromotion(await request(withQuery(API_ENDPOINTS.promotions.eligibilityStatus(requiredId(id, 'Student ID')), { eligibilityStatus }), { method: 'PUT' })),
  promote: async (payload) => normalizePromotion(await request(API_ENDPOINTS.promotions.promote, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  promoteBulk: async (payload) => normalizePromotion(await request(API_ENDPOINTS.promotions.promoteBulk, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  promoteBulkAtomic: async (payload) => normalizePromotion(await request(API_ENDPOINTS.promotions.promoteBulkAtomic, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  getPromotedStudents: async (params) => listData(await request(withQuery(API_ENDPOINTS.promotions.promotedStudents, params))), getStudentHistory: async (id) => listData(await request(API_ENDPOINTS.promotions.studentHistory(requiredId(id, 'Student ID')))), getHistoryByStudent: async (id) => listData(await request(API_ENDPOINTS.promotions.historyByStudent(requiredId(id, 'Student ID')))),
}
export const studentAttendanceApi = {
  list: async (params) => listData(await request(withQuery(API_ENDPOINTS.studentAttendance.list, params))),
  create: async (payload) => normalizeRecord(await request(API_ENDPOINTS.studentAttendance.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  getById: async (sessionId, params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.detail(requiredId(sessionId, 'Session ID')), params))),
  getStudents: async (sessionId, params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.students(requiredId(sessionId, 'Session ID')), params))),
  mark: async (sessionId, payload, params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.mark(requiredId(sessionId, 'Session ID')), params), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  updateStatus: async (sessionId, payload, params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.status(requiredId(sessionId, 'Session ID')), params), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  getDailyReport: async (params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.daily, params))),
  getSubjectReport: async (params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.subjectReport, params))),
  getMonthlyReport: async (params) => normalizeRecord(await request(withQuery(API_ENDPOINTS.studentAttendance.monthly, params))),
}
export const creditManagementApi = {
  getDashboard: async params => normalizeRecord(await request(withQuery(API_ENDPOINTS.credits.dashboard, params))),
  getConfigurations: async params => listData(await request(withQuery(API_ENDPOINTS.credits.configurations, params))),
  createConfiguration: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.credits.configurations, 'POST', payload)),
  updateConfiguration: async (id, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.credits.configuration(requiredId(id, 'Configuration ID')), 'PUT', payload)),
  getRegistrations: async params => listData(await request(withQuery(API_ENDPOINTS.credits.registrations, params))),
  getRegistration: async id => normalizeRecord(await request(API_ENDPOINTS.credits.registration(requiredId(id, 'Registration ID')))),
  createRegistration: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.credits.registrations, 'POST', payload)),
  updateRegistration: async (id, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.credits.registration(requiredId(id, 'Registration ID')), 'PUT', payload)),
  getSummary: async params => normalizeRecord(await request(withQuery(API_ENDPOINTS.credits.summary, params))),
}
export const electiveManagementApi = {
  getGroups: async params => listData(await request(withQuery(API_ENDPOINTS.electives.groups, params))),
  createGroup: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.electives.groups, 'POST', payload)),
  updateGroup: async (id, payload) => normalizeRecord(await jsonRequest(`${API_ENDPOINTS.electives.groups}/${requiredId(id, 'Elective group ID')}`, 'PUT', payload)),
  deleteGroup: async id => request(`${API_ENDPOINTS.electives.groups}/${requiredId(id, 'Elective group ID')}`, { method: 'DELETE' }),
  getGroupSubjects: async id => listData(await request(API_ENDPOINTS.electives.groupSubjects(requiredId(id, 'Elective group ID')))),
  addGroupSubjects: async (id, subjectIds) => normalizeRecord(await jsonRequest(API_ENDPOINTS.electives.groupSubjects(requiredId(id, 'Elective group ID')), 'POST', { subjectIds })),
  getStudentSelections: async id => listData(await request(API_ENDPOINTS.electives.studentSelections(requiredId(id, 'Student ID')))),
  createStudentSelection: async (id, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.electives.studentSelections(requiredId(id, 'Student ID')), 'POST', payload)),
  getApprovals: async params => listData(await request(withQuery(API_ENDPOINTS.electives.approvals, params))),
  updateApproval: async (id, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.electives.approval(requiredId(id, 'Selection ID')), 'PUT', payload)),
  getAllocations: async params => listData(await request(withQuery(API_ENDPOINTS.electives.allocations, params))),
  createAllocation: async (id, payload = {}) => normalizeRecord(await jsonRequest(API_ENDPOINTS.electives.allocation(requiredId(id, 'Selection ID')), 'POST', payload)),
}
export const resultsApi = {
  list: async (params) => listData(await request(withQuery(API_ENDPOINTS.results.list, params))),
  create: async (payload) => normalizeRecord(await request(API_ENDPOINTS.results.create, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })),
  getTranscript: async (studentId) => normalizeRecord(await request(API_ENDPOINTS.results.transcript(requiredId(studentId, 'Student ID')))),
}

export async function lookupIndianPincode(pincode) {
  const digits = String(pincode || '').replace(/\D/g, '').trim()
  if (!/^\d{6}$/.test(digits)) throw new Error('Enter a valid 6-digit PIN code.')

  // Last-resort values for PINs which have previously been returned empty by
  // the upstream providers. The all-India postal directory below is primary.
  const knownLocations = {
    '500072': { town: 'Kukatpally', city: 'Hyderabad', district: 'Medchal Malkajgiri', state: 'Telangana', country: 'India' },
    '500073': { town: 'Srinagar Colony', city: 'Hyderabad', district: 'Hyderabad', state: 'Telangana', country: 'India' },
  }

  const urls = [
    `/postal-lookup/pincode/${digits}`,
    `https://www.pincodesinfo.in/api/pincode/${digits}`,
    `https://akshaysanmukhani.github.io/india-pincode-api/pincodes/${digits}.json`,
  ]

  // Postal providers don't all use the same casing or wrapper. Normalize
  // their common response shapes instead of treating a successful lookup as
  // a miss just because it uses `postOffice`, `data`, or `results`.
  const read = (record, ...names) => {
    if (!record || typeof record !== 'object') return ''
    const wanted = new Set(names.map(name => name.toLowerCase()))
    const key = Object.keys(record).find(name => wanted.has(name.toLowerCase()))
    const value = key ? record[key] : ''
    return value == null ? '' : String(value).trim()
  }
  const findLocations = payload => {
    const pending = [payload]
    const seen = new Set()
    while (pending.length) {
      const current = pending.shift()
      if (!current || typeof current !== 'object' || seen.has(current)) continue
      seen.add(current)
      if (Array.isArray(current)) {
        const locationRows = current.filter(row => row && typeof row === 'object' &&
          (read(row, 'Name', 'officeName', 'office_name', 'postOfficeName', 'post_office_name', 'place name', 'town', 'locality') ||
            read(row, 'District', 'district', 'districtName', 'district_name', 'State', 'state', 'stateName', 'state_name')))
        if (locationRows.length) return locationRows
        pending.push(...current)
        continue
      }
      if (read(current, 'Name', 'officeName', 'office_name', 'postOfficeName', 'post_office_name', 'place name', 'town', 'locality') ||
        read(current, 'District', 'district', 'districtName', 'district_name', 'State', 'state', 'stateName', 'state_name')) return [current]
      for (const key of ['PostOffice', 'postOffice', 'postOffices', 'post_offices', 'places', 'locations', 'offices', 'results', 'result', 'data', 'records', 'items', 'value']) {
        if (current[key] != null) pending.push(current[key])
      }
    }
    return []
  }

  for (const url of urls) {
    try {
      const response = await fetch(url, { headers: { Accept: 'application/json' }, cache: 'no-store' })
      if (!response.ok) continue
      const data = await response.json()
      const locations = findLocations(data)
      const primary = locations.find(location => read(location, 'deliveryStatus', 'delivery_status').toLowerCase() === 'delivery') || locations[0]
      if (!primary) continue
      const metadata = Array.isArray(data) ? data.find(item => item && typeof item === 'object') || {} : (data?.data && typeof data.data === 'object' ? data.data : data)
      const town = read(primary, 'Name', 'officeName', 'office_name', 'postOfficeName', 'post_office_name', 'place name', 'town', 'locality')
      const district = read(primary, 'District', 'district', 'districtName', 'district_name') || read(metadata, 'District', 'district', 'districtName', 'district_name')
      const block = read(primary, 'Block', 'block', 'Taluk', 'taluk', 'subDistrict', 'sub_district', 'city', 'place name') || read(metadata, 'Block', 'block', 'Taluk', 'taluk', 'subDistrict', 'sub_district', 'city')
      const state = read(primary, 'State', 'state', 'stateName', 'state_name') || read(metadata, 'State', 'state', 'stateName', 'state_name')
      if (!town && !district && !state) continue
      return {
        town: town.replace(/\s+(?:G\.?P\.?O\.?|H\.?O\.?|S\.?O\.?|B\.?O\.?)$/i, '') || block || district,
        city: block && block.toUpperCase() !== 'NA' ? block : (district || town),
        district,
        state,
        country: read(primary, 'Country', 'country') || 'India',
      }
    } catch {
      // try next url
    }
  }

  if (knownLocations[digits]) return knownLocations[digits]

  // Providers can be temporarily unavailable or omit a valid PIN. Don't
  // claim that the PIN is invalid; let the admission form be completed by hand.
  throw new Error('Could not retrieve location details for this PIN code. Please enter the address manually.')
}

export default API_ENDPOINTS

// Leave endpoints may wrap their collection by resource name. Do not turn
// an unrecognized response (including an HTML tunnel page) into "no records".
const leaveList = async (url, params, keys, requestOptions) => {
  let current = await request(withQuery(url, params), requestOptions)
  const collectionKeys = new Set([...keys, 'items', 'content', 'results', 'records', 'rows', 'data', 'value', '$values'].map(key => key.toLowerCase()))
  for (let depth = 0; depth < 6; depth += 1) {
    if (Array.isArray(current)) return current
    if (!current || typeof current !== 'object') break
    const entry = Object.entries(current).find(([name, value]) => collectionKeys.has(name.toLowerCase()) && value != null)
    if (!entry) break
    current = entry[1]
  }
  if (Array.isArray(current)) return current
  throw new Error('The leave service returned an unexpected response.')
}

export const facultyLeaveApi = {
  getRequests: async (params, requestOptions) => leaveList(API_ENDPOINTS.facultyLeave.requests, params, ['requests', 'leaveRequests'], requestOptions),
  createRequest: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyLeave.requests, 'POST', payload)),
  getRequest: async id => normalizeRecord(await request(API_ENDPOINTS.facultyLeave.request(requiredId(id, 'Request ID')))),
  approve: async id => request(API_ENDPOINTS.facultyLeave.approve(requiredId(id, 'Request ID')), { method: 'PUT' }),
  reject: async (id, rejectionReason) => jsonRequest(API_ENDPOINTS.facultyLeave.reject(requiredId(id, 'Request ID')), 'PUT', { rejectionReason }),
  getHistory: async (params, requestOptions) => leaveList(API_ENDPOINTS.facultyLeave.history, params, ['history', 'leaveHistory', 'requests', 'leaveRequests'], requestOptions),
  getBalances: async (params, requestOptions) => leaveList(API_ENDPOINTS.facultyLeave.balances, params, ['balances', 'leaveBalances'], requestOptions),
  getTypes: async (params, requestOptions) => leaveList(API_ENDPOINTS.facultyLeave.types, params, ['types', 'leaveTypes'], requestOptions),
  createType: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyLeave.types, 'POST', payload)),
  updateType: async (id, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyLeave.type(requiredId(id, 'Leave type ID')), 'PUT', payload)),
  getPolicies: async (params, requestOptions) => leaveList(API_ENDPOINTS.facultyLeave.policies, params, ['policies', 'leavePolicies'], requestOptions),
  getPolicy: async id => normalizeRecord(await request(API_ENDPOINTS.facultyLeave.policy(requiredId(id, 'Policy ID')))),
  createPolicy: async payload => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyLeave.policies, 'POST', payload)),
  updatePolicy: async (id, payload) => normalizeRecord(await jsonRequest(API_ENDPOINTS.facultyLeave.policy(requiredId(id, 'Policy ID')), 'PUT', payload)),
  activatePolicy: async id => request(API_ENDPOINTS.facultyLeave.activate(requiredId(id, 'Policy ID')), { method: 'POST' }),
  deactivatePolicy: async id => request(API_ENDPOINTS.facultyLeave.deactivate(requiredId(id, 'Policy ID')), { method: 'POST' }),
}
export const facultyPayrollApi = {
  getAll: async (params, requestOptions) => listData(await request(withQuery(API_ENDPOINTS.facultyPayroll.list, params), requestOptions)),
  getById: async id => normalizeRecord(await request(API_ENDPOINTS.facultyPayroll.detail(requiredId(id, 'Payroll ID')))),
  getSalaryRecords: async params => listData(await request(withQuery(API_ENDPOINTS.facultyPayroll.salaries, params))),
  getPayslips: async params => listData(await request(withQuery(API_ENDPOINTS.facultyPayroll.payslips, params))),
  hold: async (id, reason) => jsonRequest(API_ENDPOINTS.facultyPayroll.hold(requiredId(id, 'Payroll ID')), 'PUT', { reason }),
  export: async params => blobRequest(withQuery(API_ENDPOINTS.facultyPayroll.export, params)),
}

export const facultyMasterApi = {
  getSemesters: async () => listData(await request(endpoint('/api/semester'))),
  getColleges: async () => listData(await request(endpoint('/api/v1/colleges'))),
  getSubjects: async params => listData(await request(withQuery(endpoint('/api/v1/subjects'), params))),
}

// Subject CRUD routes are implemented by Backend/Controllers/V1/FacultyManagement/SubjectsController.cs.
export const subjectApi = {
  list: async params => {
    try {
      return await readSubjectPages(page => request(withQuery(API_ENDPOINTS.subjectManagementSubjects.list, { ...params, ...page })))
    } catch (error) {
      if (error.backendMessage) error.message = userErrorMessage(error.backendMessage, error.status)
      throw error
    }
  },
  search: async params => listData(await request(withQuery(API_ENDPOINTS.subjectManagementSubjects.search, params))),
  getById: async id => dataResponse(await request(API_ENDPOINTS.subjectManagementSubjects.detail(requiredId(id, 'Subject ID')))),
  create: async payload => dataResponse(await jsonRequest(API_ENDPOINTS.subjectManagementSubjects.list, 'POST', payload)),
  update: async (id, payload) => dataResponse(await jsonRequest(API_ENDPOINTS.subjectManagementSubjects.detail(requiredId(id, 'Subject ID')), 'PUT', payload)),
  remove: async id => request(API_ENDPOINTS.subjectManagementSubjects.detail(requiredId(id, 'Subject ID')), { method: 'DELETE' }),
  updateStatus: async (id, status) => dataResponse(await jsonRequest(API_ENDPOINTS.subjectManagementSubjects.status(requiredId(id, 'Subject ID')), 'PATCH', { status: status === 'Inactive' ? 0 : 1 })),
  dependencies: async id => dataResponse(await request(API_ENDPOINTS.subjectManagementSubjects.dependencies(requiredId(id, 'Subject ID')))),
  lookups: async () => dataResponse(await request(API_ENDPOINTS.subjectManagementSubjects.lookups)),
  summary: async params => dataResponse(await request(withQuery(API_ENDPOINTS.subjectManagementSubjects.summary, params))),
  export: params => blobRequest(withQuery(API_ENDPOINTS.subjectManagementSubjects.export, params)),
  download: params => blobRequest(withQuery(API_ENDPOINTS.subjectManagementSubjects.download, params)),
}

// Verified against the deployed Swagger TimetableEntries contract (2026-09-23).
// Timetable/slot setup and publication routes are not exposed by this contract.
export const timetableEntryApi = {
  list: async () => {
    const response = await request(endpoint('/api/v1/timetable-entries'))
    const rows = response?.data ?? response
    if (!Array.isArray(rows) || (response?.count != null && Number(response.count) !== rows.length)) throw new Error('The timetable service returned an incomplete or invalid schedule. Conflict validation requires the complete list.')
    return rows
  },
  create: payload => jsonRequest(endpoint('/api/v1/timetable-entries'), 'POST', payload),
  update: (id, payload) => jsonRequest(endpoint(`/api/v1/timetable-entries/${requiredId(id, 'Timetable entry ID')}`), 'PUT', payload),
  remove: id => request(endpoint(`/api/v1/timetable-entries/${requiredId(id, 'Timetable entry ID')}`), { method: 'DELETE' }),
}

// Phase 5 API: all calls use the shared bearer-token, refresh and error handling.
const timetableManagementUrl = (path = '') => endpoint(`/api/v1/timetable-management${path}`)
export const timetableManagementApi = {
  get: async (path, query) => dataResponse(await request(withQuery(timetableManagementUrl(path), query))),
  post: async (path, payload) => dataResponse(await jsonRequest(timetableManagementUrl(path), 'POST', payload)),
  put: async (path, payload) => dataResponse(await jsonRequest(timetableManagementUrl(path), 'PUT', payload)),
  remove: async path => dataResponse(await request(timetableManagementUrl(path), { method: 'DELETE' })),
}

const isNumericId = (val) => Number.isInteger(Number(val)) && Number(val) > 0

const rolePayload = (role) => {
  if (!role || typeof role !== 'object') return {}
  const isBoolStatus = role.status === 'Active' || role.status === true || role.status === 1 || role.isActive === true
  return {
    name: String(role.name || role.roleName || '').trim(),
    roleName: String(role.name || role.roleName || '').trim(),
    code: String(role.code || role.roleCode || '').trim().toUpperCase(),
    roleCode: String(role.code || role.roleCode || '').trim().toUpperCase(),
    category: role.category || 'Academic',
    level: role.level || 'Level 4 (Academic Staff)',
    description: String(role.description || '').trim(),
    status: isBoolStatus,
    isActive: isBoolStatus,
    permissions: typeof role.permissions === 'object' ? JSON.stringify(role.permissions) : role.permissions || '{}',
  }
}

export const roleApi = {
  getAll: async (params) => listData(await request(withQuery(API_ENDPOINTS.roles.list, params))),
  getById: async (id) => isNumericId(id) ? (await request(API_ENDPOINTS.roles.detail(id)))?.data : null,
  create: async (payload) => (await jsonRequest(API_ENDPOINTS.roles.create, 'POST', rolePayload(payload)))?.data,
  update: async (id, payload) => {
    if (isNumericId(id)) {
      return (await jsonRequest(API_ENDPOINTS.roles.update(id), 'PUT', rolePayload(payload)))?.data
    }
    return (await jsonRequest(API_ENDPOINTS.roles.create, 'POST', rolePayload(payload)))?.data
  },
  delete: async (id) => {
    if (isNumericId(id)) {
      return request(API_ENDPOINTS.roles.delete(id), { method: 'DELETE' })
    }
    return true
  },
}
export const rolesApi = roleApi

export const userRoleMappingApi = {
  getAll: async () => listData(await request(endpoint('/api/UserRoleMapping'))),
  create: payload => jsonRequest(endpoint('/api/UserRoleMapping'), 'POST', payload),
  update: (id, payload) => jsonRequest(endpoint(`/api/UserRoleMapping/${requiredId(id, 'User role mapping ID')}`), 'PUT', payload),
}

export const roomApi = {
  getAll: async (params) => listData(await request(withQuery(API_ENDPOINTS.rooms.list, params))),
  getOptions: async () => (await request(API_ENDPOINTS.rooms.options))?.data,
  getById: async (classroomId) => (await request(API_ENDPOINTS.rooms.detail(requiredId(classroomId, 'Room ID'))))?.data,
  create: async (payload) => (await jsonRequest(API_ENDPOINTS.rooms.create, 'POST', payload))?.data,
  update: async (classroomId, payload) => (await jsonRequest(API_ENDPOINTS.rooms.update(requiredId(classroomId, 'Room ID')), 'PUT', payload))?.data,
  allocate: async (classroomId, payload) => {
    let body = {}
    if (typeof payload === 'number') {
      body = { sectionId: Number(payload) }
    } else if (typeof payload === 'object' && payload !== null) {
      const secId = Number(payload.sectionId ?? payload.id)
      body = {
        sectionId: Number.isInteger(secId) && secId > 0 ? secId : Number(payload.sectionId),
        ...(payload.sectionName ? { sectionName: payload.sectionName } : {}),
      }
    } else if (typeof payload === 'string' && !isNaN(Number(payload)) && Number(payload) > 0) {
      body = { sectionId: Number(payload) }
    } else {
      body = payload
    }
    return (await jsonRequest(API_ENDPOINTS.rooms.allocation(requiredId(classroomId, 'Room ID')), 'PUT', body))?.data
  },
  deallocate: async (classroomId) => request(API_ENDPOINTS.rooms.allocation(requiredId(classroomId, 'Room ID')), { method: 'DELETE' }),
}
export const roomsApi = roomApi

// MarksController / DTOs/Marks/MarksManagementDtos.cs. No local success fallback.
export const marksApi = {
  list: async params => listData(await request(withQuery(API_ENDPOINTS.marks.list, params))),
  get: async id => dataResponse(await request(API_ENDPOINTS.marks.detail(requiredId(id, 'Mark ID')))),
  create: async payload => { const data = dataResponse(await jsonRequest(API_ENDPOINTS.marks.list, 'POST', payload)); return data?.mark ?? data },
  update: async (id, payload) => dataResponse(await jsonRequest(API_ENDPOINTS.marks.detail(requiredId(id, 'Mark ID')), 'PUT', payload)),
  bulkPreview: async payload => dataResponse(await jsonRequest(API_ENDPOINTS.marks.bulkPreview, 'POST', payload)),
  bulkFilePreview: async (file, scope) => {
    const form = new FormData()
    form.append('file', file)
    if (scope?.examId) form.append('examId', String(scope.examId))
    if (scope?.sectionId) form.append('sectionId', String(scope.sectionId))
    return dataResponse(await multipartRequest(API_ENDPOINTS.marks.bulkFilePreview, form))
  },
  bulkUpload: async (file, scope) => {
    const form = new FormData()
    form.append('file', file)
    if (scope?.examId) form.append('examId', String(scope.examId))
    if (scope?.sectionId) form.append('sectionId', String(scope.sectionId))
    form.append('upsertDrafts', String(Boolean(scope.upsertDrafts)))
    return dataResponse(await multipartRequest(API_ENDPOINTS.marks.bulkUpload, form))
  },
  summaryReport: async params => dataResponse(await request(withQuery(API_ENDPOINTS.marks.summaryReport, params))),
  pendingApprovals: async params => listData(await request(withQuery(API_ENDPOINTS.marks.pendingApprovals, params))),
  workflow: async (action, payload) => {
    if (!['submit', 'approve', 'reject'].includes(action)) throw new Error('Invalid marks workflow action.')
    return dataResponse(await jsonRequest(API_ENDPOINTS.marks.workflow(action), 'POST', payload))
  },
  updateApproval: async (id, payload) => dataResponse(await jsonRequest(API_ENDPOINTS.marks.updateApproval(requiredId(id, 'Approval ID')), 'PATCH', payload)),
  approvalHistory: async id => listData(await request(API_ENDPOINTS.marks.approvalHistory(requiredId(id, 'Mark ID')))),
  studentReport: async params => dataResponse(await request(withQuery(API_ENDPOINTS.marks.studentReport, params))),
  subjectReport: async params => listData(await request(withQuery(API_ENDPOINTS.marks.subjectReport, params))),
  download: async params => readExportFile(withQuery(API_ENDPOINTS.marks.download, params)),
  export: async params => readExportFile(withQuery(API_ENDPOINTS.marks.export, params)),
  upload: async (file, scope, preview = true) => {
    if (!(file instanceof File) || !/\.xlsx$/i.test(file.name)) throw new Error('Choose an XLSX workbook.')
    if (!file.size || file.size > 10 * 1024 * 1024) throw new Error('Workbook must be nonempty and at most 10 MB.')
    return preview ? marksApi.bulkFilePreview(file, scope) : marksApi.bulkUpload(file, scope)
  },
}
