import { Component, Suspense, lazy, useEffect } from 'react'
import { MeetingsEventsWorkspace, LibraryWorkspace, PlacementWorkspace } from './pages/campus/CampusWorkspace'
import { Dashboard, LandingPage, Login, ActivateAccount, Register, Unauthorized } from './pages/Pages'
import { Course, CourseStructure, Branch } from './pages/courseManagement/Course'
import { CollegeInstitutionManagement, AddCollege, AcademicYearManagement, DepartmentManagement, RolesAndDesignations, RoomsManagement } from './pages/admin-management/AdminManagement'
import { MyProfile, Settings } from './pages/profile/MyProfile'
import { Attendance, AttendanceSessionDetails } from './pages/attendance/Attendance'
import { FacultyManagement, FacultyLeaveManagement, Payroll } from './pages/faculty/FacultyManagement'
import { ExaminationSetup, ExaminationList, CreateExamination, ExamType } from './pages/examinations/examination-setup/ExaminationSetup'
import { ExamTimetable, ExamScheduleList, DepartmentExamSchedule, StudentExamSchedule, HallAllocation, ExamConfiguration, CompletedExams } from './pages/examinations/exam-timetable/ExamModule'
import { MarksManagement, MarksEntry, BulkMarksUpload, EditMarks, StudentMarks, SubjectMarksReport, MarksApproval } from './pages/examinations/marks-management/MarksManagement'
import { Navigate, Route, Routes } from 'react-router-dom'
import ProtectedRoute from './components/ProtectedRoute'
import ScreenPermissionBoundary from './auth/ScreenPermissionBoundary.jsx'
import PortalRoute, { RoleDashboard, RoleAlias } from './components/portals/PortalRoute.jsx'
import { facultyRouteByPath } from './features/faculty/routeConfig.js'
const AcademicPortal = lazy(() => import('./pages/portals/AcademicPortal.jsx'))
const StaffPortal = lazy(() => import('./pages/staff-portal/StaffPortal.jsx'))
const UserAccessManagement = lazy(() => import('./pages/admin-management/UserAccessManagement.jsx'))
const PortalPreview = lazy(() => import('./pages/portals/PortalPreview.jsx'))
const FacultyDashboardPage = lazy(() => import('./features/faculty/dashboard/pages/FacultyDashboardPage.jsx'))
const FacultyWorkspacePage = lazy(() => import('./features/faculty/FacultyWorkspacePage.jsx'))
const FacultyRouteErrorBoundary = lazy(() => import('./features/faculty/FacultyRouteErrorBoundary.jsx'))
const FacultySessionExpiredPage = lazy(() => import('./features/faculty/FacultySessionExpiredPage.jsx'))



import { ROLES } from './auth/roles'

import AcademicStructure from './pages/academic-structure/AcademicStructure'
import SemesterManagement from './pages/semester-management/SemesterManagement'
import SectionManagement from './pages/section-management/SectionManagement'
import StudentAdmission from './pages/student-management/StudentAdmission/StudentAdmission'
import StudentProfile from './pages/student-management/StudentProfile/StudentProfile'
import StudentPromotion from './pages/student-management/StudentPromotion/StudentPromotion'
import Fees from './pages/fees/FeeManagement'
import SubjectManagement, { SubjectDetailsPage } from './pages/subject-management/SubjectManagement'
import CreditsManagement from './pages/credits-management/CreditsManagement'
import TimetableManagement from './pages/timetable/TimetableManagement'
import ElectiveManagement from './pages/elective-management/ElectiveManagement'
import { AcademicProvider } from './context/AcademicContext'
import './styles/erp-theme.css'
import {
  GradeResultManagement,
  GradeConfiguration,
  CGPACalculatorPage,
  ResultGeneration,
  SemesterResult,
  DepartmentResult,
  ConsolidatedMarksMemo,
  BacklogReport,
  StudentResult
} from './pages/examinations/grade-result-management/GradeResultManagement'
import './App.css'
import './styles/details-layout.css'
import './styles/view-cards.css'

class AppErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null, info: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }

  componentDidCatch(error, info) {
    console.error('App crashed:', error, info)
    this.setState({ error, info })
  }

  render() {
    if (this.state.hasError) {
      return (
        <main style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: '24px', fontFamily: 'system-ui, sans-serif' }}>
          <div style={{ maxWidth: '700px', width: '100%', textAlign: 'center', background: '#fff', borderRadius: '16px', padding: '32px 24px', boxShadow: '0 12px 32px rgba(15, 23, 42, 0.12)' }}>
            <h1 style={{ margin: '0 0 12px', color: '#0f172a' }}>Something went wrong</h1>
            <p style={{ margin: '0 0 12px', color: '#475569' }}>The app hit an unexpected error. Please reload the page or return home.</p>
            <p style={{ margin: '0 0 20px', color: '#64748b', fontSize: '13px' }}>Please retry. If the problem continues, contact your administrator. Technical details were saved for support.</p>
            {this.state.error && (
              <details open style={{ textAlign: 'left', margin: '0 0 20px', background: '#fef2f2', padding: '12px', borderRadius: '8px', border: '1px solid #fecaca', fontSize: '12px' }}>
                <summary style={{ cursor: 'pointer', fontWeight: 700, color: '#b91c1c' }}>Error: {String(this.state.error?.message || this.state.error)}</summary>
                <pre style={{ marginTop: '8px', whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: '#7f1d1d', maxHeight: '200px', overflowY: 'auto' }}>{String(this.state.error?.stack || '')}{'\n'}{String(this.state.info?.componentStack || '')}</pre>
              </details>
            )}
            <button type="button" onClick={() => window.location.reload()} style={{ border: 'none', background: '#1769C2', color: '#fff', borderRadius: '10px', padding: '10px 16px', cursor: 'pointer', fontWeight: 700, marginRight: '8px' }}>
              Try again
            </button>
            <button type="button" onClick={() => window.location.href = '/'} style={{ border: 'none', background: '#475569', color: '#fff', borderRadius: '10px', padding: '10px 16px', cursor: 'pointer', fontWeight: 700 }}>
              Go to home
            </button>
          </div>
        </main>
      )
    }

    return this.props.children
  }
}

function TableOverflowTitles() {
  useEffect(() => {
    const actionSelector = '.erp-row-actions,.row-actions,.cm-actions,.cm-row-actions,.semester-row-actions,.section-actions,.course-actions,.branch-actions,.sa-icon-actions,.sa-row-actions'
    const showFullValue = (event) => {
      const target = event.target.closest('td, th, .cm-info-val, .sa-kv-val, .sa-kv-value, .erp-view-value, .kv-val, .sp-panel-val, .meta-val, .cm-info-row, .sa-kv-cell, .preview-kv-item, .table-cell-truncate, .rbac-profile-subtitle, .detail-item strong')
      if (!target) return
      if (target.hasAttribute('data-no-overflow-tooltip')) {
        target.title = ''
        return
      }
      if (target.querySelector(actionSelector)) return

      const isTruncated = target.scrollWidth > target.clientWidth || (target.children.length > 0 && Array.from(target.children).some((child) => child.scrollWidth > child.clientWidth))
      if (isTruncated && !target.title) {
        target.title = target.innerText.replace(/\s+/g, ' ').trim()
      }
    }
    document.addEventListener('mouseover', showFullValue)
    return () => document.removeEventListener('mouseover', showFullValue)
  }, [])

  return null
}

/* Enforce consistent client-side checks even on older forms that use noValidate.
   Server validation remains authoritative; this prevents avoidable bad submits. */
function FormValidationGuard() {
  useEffect(() => {
    const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/
    const validate = (event) => {
      const form = event.target
      if (!(form instanceof HTMLFormElement) || form.noValidate === false && !form.querySelector('[required]')) return
      const controls = Array.from(form.querySelectorAll('input, select, textarea')).filter((control) => !control.disabled && control.type !== 'hidden' && control.type !== 'button' && control.type !== 'submit')
      let firstInvalid = null
      for (const control of controls) {
        control.setCustomValidity('')
        const value = String(control.value || '').trim()
        const label = control.closest('label')?.innerText || control.labels?.[0]?.innerText || ''
        const required = control.required || /\*/.test(label)
        const isIdentifier = /identifier|username|login|mobile.*id|id.*mobile|email.*mobile/i.test(`${control.name} ${control.id} ${label}`)
        const isEmail = !isIdentifier && (control.type === 'email' || (/\bemail\b/i.test(`${control.name} ${control.id} ${label}`) && !/mobile|id|identifier|username/i.test(`${control.name} ${control.id} ${label}`)))
        const mobilePattern = /^[6-9]\d{9}$/
        const idPattern = /^[A-Za-z0-9][A-Za-z0-9._/-]{1,}$/
        const message = required && !value
          ? 'This field is required.'
          : value && isEmail && !emailPattern.test(value)
            ? 'Enter a valid email address.'
            : value && isIdentifier && !(emailPattern.test(value) || mobilePattern.test(value) || idPattern.test(value))
              ? 'Enter a valid email, mobile number or ID.'
              : ''
        if (message) {
          control.setCustomValidity(message)
          firstInvalid ||= control
        }
      }
      const requiredSelect = Array.from(form.querySelectorAll('.searchable-select[data-required="true"][data-empty="true"]')).find((node) => !node.classList.contains('is-disabled'))
      if (requiredSelect) firstInvalid ||= requiredSelect.querySelector('button')
      if (!firstInvalid) return
      event.preventDefault()
      event.stopPropagation()
      if (firstInvalid instanceof HTMLInputElement || firstInvalid instanceof HTMLSelectElement || firstInvalid instanceof HTMLTextAreaElement) firstInvalid.reportValidity()
      else {
        firstInvalid.setAttribute('aria-invalid', 'true')
        firstInvalid.focus()
      }
    }
    document.addEventListener('submit', validate, true)
    return () => document.removeEventListener('submit', validate, true)
  }, [])
  return null
}

export default function App() {
  return (
    <AppErrorBoundary>
      <TableOverflowTitles />
      <FormValidationGuard />
      <Suspense fallback={<p role="status">Loading workspace...</p>}>
      <Routes>
          {/* Public */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/activate-account" element={<ActivateAccount />} />
          <Route path="/register" element={<Register />} />

          <Route path="/portal-preview" element={<PortalPreview />} />
          <Route path="/dashboard" element={<RoleDashboard><AcademicProvider><ScreenPermissionBoundary><Dashboard /></ScreenPermissionBoundary></AcademicProvider></RoleDashboard>} />
          <Route path="/faculty-portal/session-expired" element={<FacultyRouteErrorBoundary><FacultySessionExpiredPage /></FacultyRouteErrorBoundary>} />
          <Route element={<PortalRoute roles={[ROLES.FACULTY]} />}>
            <Route path="/faculty-portal" element={<Navigate to="/faculty-portal/dashboard" replace />} />
            <Route path={facultyRouteByPath['/faculty-portal/dashboard'].path} element={<FacultyRouteErrorBoundary><FacultyDashboardPage /></FacultyRouteErrorBoundary>} />
            <Route path="/faculty-portal/:screen?" element={<FacultyRouteErrorBoundary><FacultyWorkspacePage /></FacultyRouteErrorBoundary>} />
          </Route>
          <Route element={<PortalRoute roles={[ROLES.STUDENT]} />}>
            <Route path="/student-portal/:screen?" element={<AcademicPortal role="student" />} />
          </Route>
          <Route element={<PortalRoute roles={[ROLES.STAFF]} />}>
            <Route path="/staff-portal/:screen?" element={<StaffPortal />} />
          </Route>
          <Route element={<AcademicProvider><PortalRoute roles={[ROLES.ADMIN]} /></AcademicProvider>}>
            <Route path="/user-access" element={<UserAccessManagement />} />
          </Route>
          {/* Existing administrator screens retain their URLs and components. */}
          <Route element={<PortalRoute roles={[ROLES.ADMIN]} permissionCheckedByChild />}>
          <Route
            element={
              <AcademicProvider>
                <ProtectedRoute
                  allowedRoles={[
                    ROLES.ADMIN,
                  ]}
                />
              </AcademicProvider>
            }
          >
              <Route path="/library" element={<LibraryWorkspace />} />
              <Route path="/meetings-events" element={<MeetingsEventsWorkspace />} />
              <Route path="/placement" element={<PlacementWorkspace />} />
              <Route path="/results" element={<ResultGeneration />} />
              <Route path="/results/semester-result" element={<SemesterResult />} />
              <Route path="/results/department-result" element={<DepartmentResult />} />
              <Route path="/results/consolidated-marks-memo" element={<ConsolidatedMarksMemo />} />
              <Route path="/results/backlog-report" element={<BacklogReport />} />
              <Route path="/results/student-result" element={<StudentResult />} />
              <Route path="/my-profile" element={<MyProfile />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/global-settings" element={<Settings />} />
              <Route path="/settings/academic-context" element={<Settings />} />

              {/* Faculty demo module */}
              <Route path="/faculty/*" element={<FacultyManagement />} />
              <Route path="/faculty/leave-management" element={<FacultyLeaveManagement />} />
              <Route path="/faculty/payroll" element={<Payroll />} />

              {/* Faculty / Operations backed modules */}
              {/* Retain the former URL as a safe bookmark redirect. */}
              <Route path="/attendance/*" element={<Navigate to="/student-management/attendance" replace />} />

              <Route element={<ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.STUDENT]} />}>
                <Route path="/exam/student-schedule" element={<StudentExamSchedule />} />
              </Route>

              <Route element={<ProtectedRoute allowedRoles={[ROLES.ADMIN]} />}>
              <Route path="/exam/create" element={<Navigate to="/exam/timetable" replace />} />
              <Route path="/exam/department-schedule" element={<DepartmentExamSchedule />} />
              <Route path="/exam/schedules" element={<ExamScheduleList />} />
              <Route path="/exam/timetable" element={<ExamTimetable />} />
              <Route path="/exam/hall-allocation" element={<HallAllocation />} />
              <Route path="/exam/configuration" element={<ExamConfiguration />} />
              <Route path="/examination/completed-exams" element={<CompletedExams />} />
              <Route path="/examination/completed-exams/:examId" element={<CompletedExams />} />
              <Route path="/examination-setup/*" element={<ExaminationSetup />} />
              <Route path="/examination-setup/examination-list" element={<ExaminationList />} />
              <Route path="/examination-setup/create-examination" element={<CreateExamination />} />
              <Route path="/examination-setup/exam-type" element={<ExamType />} />
              <Route path="/examination-setup/exam-schedule" element={<Navigate to="/examination-setup/examination-list" replace />} />
              <Route path="/examination-setup/exam-rules" element={<Navigate to="/examination-setup/examination-list" replace />} />
              <Route path="/exam-timetable/*" element={<ExamTimetable />} />
              <Route path="/exam-timetable/create-exam-timetable" element={<Navigate to="/exam/timetable" replace />} />
              <Route path="/exam-timetable/exam-schedule-list" element={<ExamScheduleList />} />
              <Route path="/exam-timetable/department-exam-schedule" element={<DepartmentExamSchedule />} />
              <Route path="/exam-timetable/student-exam-schedule" element={<StudentExamSchedule />} />
              <Route path="/exam-timetable/hall-allocation" element={<HallAllocation />} />
              <Route path="/marks-management" element={<Navigate to="/marks-management/marks-entry" replace />} />
              <Route path="/marks-management/*" element={<MarksManagement />} />
              <Route path="/marks-management/marks-entry" element={<MarksEntry />} />
              <Route path="/marks-management/bulk-marks-upload" element={<BulkMarksUpload />} />
              <Route path="/marks-management/edit-marks" element={<EditMarks />} />
              <Route path="/marks-management/student-marks" element={<StudentMarks />} />
              <Route path="/marks-management/subject-marks-report" element={<SubjectMarksReport />} />
              <Route path="/marks-management/marks-approval" element={<MarksApproval />} />
              <Route path="/grade-result-management" element={<GradeResultManagement />} />
              <Route path="/grade-result-management/grade-configuration" element={<GradeConfiguration />} />
              <Route path="/grade-result-management/cgpa-calculator" element={<CGPACalculatorPage />} />
              <Route path="/grade-result-management/result-generation" element={<Navigate to="/results" replace />} />
              <Route path="/grade-result-management/semester-result" element={<Navigate to="/results/semester-result" replace />} />
              <Route path="/grade-result-management/department-result" element={<Navigate to="/results/department-result" replace />} />
              <Route path="/grade-result-management/consolidated-marks-memo" element={<Navigate to="/results/consolidated-marks-memo" replace />} />
              <Route path="/grade-result-management/backlog-report" element={<Navigate to="/results/backlog-report" replace />} />
              <Route path="/grade-result-management/student-result" element={<Navigate to="/results/student-result" replace />} />
              <Route path="/grade-result-management/*" element={<GradeResultManagement />} />
              </Route>

              {/* Administration - Admin Only */}
              <Route path="/college-institution-management" element={<CollegeInstitutionManagement />} />
              <Route path="/college-institution-management/add" element={<AddCollege />} />
              <Route path="/academic-year-management" element={<AcademicProvider><AcademicYearManagement /></AcademicProvider>} />
              <Route path="/academic-year-management/:id" element={<AcademicProvider><AcademicYearManagement /></AcademicProvider>} />
              {/* Unified Academic Structure Single Page */}
              <Route path="/academic-structure" element={<AcademicStructure />} />

              {/* Backwards-compatible route redirects to the unified Academic Structure page */}
              <Route path="/department-management/*" element={<Navigate to="/academic-structure?step=departments" replace />} />
              <Route path="/department-management" element={<Navigate to="/academic-structure?step=departments" replace />} />
              <Route path="/courses/*" element={<Navigate to="/academic-structure?step=courses" replace />} />
              <Route path="/courses" element={<Navigate to="/academic-structure?step=courses" replace />} />
              <Route path="/branches/*" element={<Navigate to="/academic-structure?step=branches" replace />} />
              <Route path="/branches" element={<Navigate to="/academic-structure?step=branches" replace />} />
              <Route path="/semester-management/*" element={<Navigate to="/academic-structure?step=semesters" replace />} />
              <Route path="/semester-management" element={<Navigate to="/academic-structure?step=semesters" replace />} />
              <Route path="/section-management" element={<SectionManagement />} />
              <Route path="/section-management/add" element={<SectionManagement mode="form" />} />
              <Route path="/section-management/:id/edit" element={<SectionManagement mode="edit" />} />
              <Route path="/section-management/:id" element={<SectionManagement mode="details" />} />
              <Route path="/rooms-management" element={<RoomsManagement />} />
              <Route path="/rooms-management/add" element={<RoomsManagement key="room-add" formMode />} />
              <Route path="/rooms-management/:roomId/edit" element={<RoomsManagement key="room-edit" formMode />} />
              <Route path="/rooms-management/:roomId" element={<RoomsManagement key="room-view" viewMode />} />
              <Route path="/rooms" element={<RoomsManagement />} />
              <Route path="/rooms/:roomId" element={<RoomsManagement key="room-view-alias" viewMode />} />
              <Route path="/subject-management" element={<SubjectManagement />} />
              <Route path="/subject-management/:id" element={<SubjectDetailsPage />} />
              <Route path="/credits-management" element={<CreditsManagement />} />
              <Route element={<ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.FACULTY]} />}><Route path="/timetable" element={<TimetableManagement />} /></Route>
              <Route path="/elective-management" element={<ElectiveManagement />} />
              <Route path="/student-management/admissions" element={<StudentAdmission />} />
              <Route path="/student-management/admissions/new" element={<StudentAdmission />} />
              <Route path="/student-management/admissions/add" element={<StudentAdmission />} />
              <Route path="/student-management/admissions/:id/edit" element={<StudentAdmission />} />
              <Route path="/student-management/admissions/:id/approval" element={<StudentAdmission />} />
              <Route path="/student-management/admissions/:id" element={<StudentAdmission />} />
              <Route path="/student-management/profiles" element={<StudentProfile />} />
              <Route path="/student-management/profiles/:id" element={<StudentProfile />} />
              <Route path="/student-management/attendance/sessions/:sessionId" element={<AttendanceSessionDetails />} />
              <Route path="/student-management/attendance/*" element={<Attendance />} />
              <Route path="/student-management/promotions" element={<StudentPromotion />} />
              <Route element={<ProtectedRoute allowedRoles={[ROLES.ADMIN]} />}><Route path="/fees/*" element={<Fees />} /></Route>
              <Route path="/roles-designations" element={<RolesAndDesignations />} />
              <Route path="/roles-permissions" element={<RolesAndDesignations />} />
          </Route>
          </Route>

          <Route element={<PortalRoute roles={[ROLES.FACULTY, ROLES.STUDENT]} />}>
            <Route path="/my-subjects" element={<RoleAlias screen="subjects" />} />
          </Route>

          {/* Unauthorized */}
          <Route path="/unauthorized" element={<Unauthorized />} />

          {/* Unknown route */}
          <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </Suspense>
    </AppErrorBoundary>
  )
}
