import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import './styles/tokens.css'
import './styles/components.css'
import './index.css'
import './App.css'
import './styles/global.css'
import App from './App.jsx'
import ToastProvider from './components/ToastProvider.jsx'
import './styles/dark-mode.css'
import './styles/dark-mode-contrast.css'
import './styles/view-status-colors.css'
import './styles/laptop-layout.css'
import './components/CompactSummary.css'


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ToastProvider><BrowserRouter><App /></BrowserRouter></ToastProvider>
  </StrictMode>,
)
