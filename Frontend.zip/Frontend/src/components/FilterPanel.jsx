import { Children, cloneElement, isValidElement, useId, useState } from 'react'
import { FiChevronDown, FiFilter, FiRotateCcw } from 'react-icons/fi'
import './FilterPanel.css'

export default function FilterPanel({
  children,
  search,
  filters,
  appliedFilters = [],
  active = false,
  activeCount,
  onClear,
  showClearWhenOpen = false,
  className = '',
  toggleClassName = '',
  actions = null,
  leadingActions = null,
  hideClear = false
}) {
  const [open, setOpen] = useState(false)
  const contentId = useId()
  const explicitSlots = search !== undefined || filters !== undefined
  const nodes = Children.toArray(children)
  const primary = nodes[0]
  const primaryChildren = isValidElement(primary) ? Children.toArray(primary.props.children) : []
  // A search label owns both its icon and input. Split only toolbar
  // containers, otherwise the input is incorrectly moved into Filters.
  const splitPrimary = isValidElement(primary) && primary.type !== 'label' && primaryChildren.length > 0
  const searchNode = explicitSlots ? search : splitPrimary
    ? cloneElement(primary, {}, primaryChildren[0])
    : primary
  const filterNodes = explicitSlots ? Children.toArray(filters) : [
    ...(splitPrimary && primaryChildren.length > 1
      ? [cloneElement(primary, {}, primaryChildren.slice(1))]
      : []),
    ...nodes.slice(1),
  ]
  const hasFilterFields = filterNodes.length > 0

  return (
    <section className={`filter-disclosure ${open ? 'open' : ''} ${className}`}>
      <div className="filter-disclosure__bar">
        <div className="filter-disclosure__search">{searchNode}</div>
        {leadingActions}
        {hasFilterFields && (
          <button
            type="button"
            className={`filter-disclosure__toggle ${toggleClassName}`.trim()}
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            aria-controls={contentId}
          >
            <FiFilter /> Filters{Number.isFinite(activeCount) ? activeCount > 0 && <span className="filter-disclosure__count" aria-label={`${activeCount} filters applied`}>{activeCount}</span> : active && <i aria-label="Filters applied" />}
            <FiChevronDown className="filter-disclosure__chevron" />
          </button>
        )}
        {actions}
        {appliedFilters.length > 0 && <span className="filter-disclosure__applied" role="status">Applied: {appliedFilters.join(', ')}</span>}
        {explicitSlots && !hideClear && onClear && active && <button type="button" className="filter-disclosure__clear-btn" onClick={onClear}><FiRotateCcw aria-hidden="true" /> Clear Filters</button>}
      </div>
      {open && hasFilterFields && (
        <div className="filter-disclosure__content" id={contentId}>
          <div className="filter-disclosure__content-inner">
            {filterNodes}
            {!explicitSlots && !hideClear && onClear && active && (
              <button
                type="button"
                className="filter-disclosure__clear-btn"
                onClick={onClear}
                title="Clear all filters"
              >
                <FiRotateCcw aria-hidden="true" /> Clear Filters
              </button>
            )}
          </div>
        </div>
      )}
    </section>
  )
}

