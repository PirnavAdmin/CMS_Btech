import { showSuccess, showError } from '../utils/toast'
import { useEffect, useId, useRef, useState } from 'react'
import { FiChevronDown, FiDownload, FiPrinter } from 'react-icons/fi'
import { exportToCsv, printEntityDetails, printResults, printSingleRecord } from '../utils/exportUtils'
import { cleanRecordSections, readVisibleRecordSections, singleRecordCsvOptions } from '../utils/singleRecordExport'
const columnsFromSections = (rows, sectionsForRecord) => {
  const definitions = new Map()
  rows.forEach(row => sectionsForRecord(row).forEach(section => section.rows.forEach(([label]) => {
    const key = `${section.title}\u0000${label}`
    if (!definitions.has(key)) definitions.set(key, { section: section.title, label })
  })))
  return [...definitions.values()].map(({ section, label }) => ({
    label: `${section} - ${label}`,
    value: row => sectionsForRecord(row)
      .find(item => item.title === section)?.rows
      .find(([field]) => field === label)?.[1]
  }))
}

export default function ExportMenu({ rows = [], columns, filename, title, loading = false, scope = 'Current filtered results', unavailable = '', mode = 'list', recordSections, reportType = '', onDownload, allowEmpty = false, directDownload = false, printLabel = 'Print / Save as PDF' }) {
  const [open, setOpen] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const single = mode === 'single'
  const exportColumns = !single && typeof recordSections === 'function'
    ? columnsFromSections(rows, recordSections)
    : columns
  const hasMappedRows = Boolean(rows.length && exportColumns?.length)
  const hasListDownload = Boolean(onDownload || hasMappedRows)
  const reportLabel = reportType ? `${reportType[0].toUpperCase()}${reportType.slice(1)} Sheet` : ''
  const root = useRef(null), trigger = useRef(null), id = useId()
  const disabled = busy || loading || (!single && !hasListDownload && !allowEmpty) || Boolean(unavailable)
  useEffect(() => {
    if (!open) return undefined
    const close = event => { if (!root.current?.contains(event.target)) setOpen(false) }
    document.addEventListener('pointerdown', close)
    return () => document.removeEventListener('pointerdown', close)
  }, [open])
  const run = async (action, message) => { setError(''); setOpen(false); setBusy(true); try { await action({ rows, columns: exportColumns, filename, title, scope }); showSuccess(message) } catch (reason) { setError(reason.message || 'Export failed. Please try again.'); showError(reason.message || 'Export failed. Please try again.') } finally { setBusy(false); trigger.current?.focus() } }
  const selectedSections = () => Array.isArray(recordSections) ? cleanRecordSections(recordSections) : readVisibleRecordSections(root.current?.closest('[data-export-record]'))
  const downloadRecord = () => exportToCsv(singleRecordCsvOptions(selectedSections(), filename))
  const printRecord = () => printSingleRecord({ title, sections: selectedSections() })
  const download = () => run(single ? downloadRecord : onDownload || exportToCsv, single ? 'Record downloaded successfully' : `${csvLabel} downloaded successfully`)
  const csvLabel = reportLabel || 'CSV'
  return <div className={`export-control${directDownload ? ' export-control--direct' : ''}`} ref={root} data-no-print onKeyDown={event => { if (event.key === 'Escape') { setOpen(false); trigger.current?.focus() } }}>
    <button className="export-button" type="button" ref={trigger} disabled={disabled} aria-expanded={directDownload ? undefined : open && !disabled} aria-controls={id} aria-label={`Export ${title}`} title={unavailable || (loading ? 'Loading records...' : rows.length ? scope : 'No records available to export.')} onClick={directDownload ? download : () => setOpen(value => !value)}><FiDownload aria-hidden="true" /> Export{!directDownload && <FiChevronDown aria-hidden="true" />}</button>
    {directDownload && <button className="export-button export-button--toggle" type="button" disabled={disabled} aria-expanded={open && !disabled} aria-controls={id} aria-label={`More export options for ${title}`} title="More export options" onClick={() => setOpen(value => !value)}><FiChevronDown aria-hidden="true" /></button>}
    {open && !disabled && <div className="export-options" id={id}><small>{single ? 'Current record only' : `${scope} (${rows.length})`}</small>{!directDownload && <button type="button" disabled={!single && !onDownload && !hasMappedRows} onClick={download}><FiDownload aria-hidden="true" /> {reportLabel ? `Download ${reportLabel}` : 'Download CSV'}</button>}<button type="button" disabled={!single && (!rows.length || !exportColumns?.length)} onClick={() => run(single ? printRecord : printResults, 'Print preview opened. Choose Print or Save as PDF in your browser.') }><FiPrinter aria-hidden="true" /> {printLabel}</button></div>}
    {busy && <span role="status">Preparing download...</span>}
    {error && <span className="export-error" role="alert">{error}</span>}
  </div>
}

export function PrintDetailsButton({ title, selector, loading = false }) {
  const [error, setError] = useState('')
  return <span className="print-control" data-no-print><button type="button" className="export-button" disabled={loading} onClick={event => { setError(''); try { const scope = event.currentTarget.closest('[data-print-scope]') || document.querySelector(selector); printEntityDetails({ title, element: scope }); showSuccess('Print preview opened. Choose Print or Save as PDF in your browser.') } catch (reason) { setError(reason.message); showError(reason.message) } }}><FiPrinter aria-hidden="true" /> Print / Save as PDF</button>{error && <span className="export-error" role="alert">{error}</span>}</span>
}
